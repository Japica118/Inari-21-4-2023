﻿
using UnityEngine;
using UnityEditor;
using GamingIsLove.Makinom;
using GamingIsLove.ORKFramework.Components;

[InitializeOnLoad]
public class ORKScriptExecutionOrderHelper : Editor
{
	static ORKScriptExecutionOrderHelper()
	{
		string gameStarter = typeof(ORKGameStarter).Name;

		MonoScript[] script = MonoImporter.GetAllRuntimeMonoScripts();

		//int count = 0;
		for(int i = 0; i < script.Length; i++)
		{
			/*if(count >= 1)
			{
				return;
			}*/
			if(script[i].name == gameStarter)
			{
				if(MonoImporter.GetExecutionOrder(script[i]) == 0)
				{
					MonoImporter.SetExecutionOrder(script[i], -1001);
				}
				//count++;
				return;
			}
		}
	}
}
