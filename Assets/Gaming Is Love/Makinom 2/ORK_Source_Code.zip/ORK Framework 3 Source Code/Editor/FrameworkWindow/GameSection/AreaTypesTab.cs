
using GamingIsLove.ORKFramework;
using UnityEditor;
using UnityEngine;
using System.Collections.Generic;
using GamingIsLove.Makinom;
using GamingIsLove.Makinom.Editor;

namespace GamingIsLove.ORKFramework.Editor
{
	public class AreaTypesTab : ORKGenericAssetListTab<AreaTypeAsset, AreaType>
	{
		public AreaTypesTab(MakinomEditorWindow parent) : base(parent)
		{
			ORK.AreaTypes.SetAssets(this.assetList.Assets);
		}

		public override void Reloaded()
		{
			base.Reloaded();
			ORK.AreaTypes.SetAssets(this.assetList.Assets);
		}


		/*
		============================================================================
		Properties
		============================================================================
		*/
		public override string Name
		{
			get { return "Area Settings & Types"; }
		}

		public override string HelpText
		{
			get
			{
				return "Set up basic area settings, e.g. notifications, and define area types.\n" +
					"Area types are used to separate areas, teleports and combatants in the bestiary, " +
					"and give additional information to areas (e.g. in notifications).";
			}
		}

		public override string HelpInfo
		{
			get { return "https://orkframework.com/guide/documentation/features/areas-teleports/"; }
		}

		public override bool HasGeneralSettings
		{
			get { return true; }
		}

		public override string GeneralSettingsHelpText
		{
			get
			{
				return "Set up general settings regarding areas.";
			}
		}

		protected override BaseSettings Settings
		{
			get { return ORK.AreaSettings; }
		}

		protected override IBaseData DisplayedSettings
		{
			get
			{
				if(this.index == -1)
				{
					return ORK.AreaSettings;
				}
				return base.DisplayedSettings;
			}
		}
	}
}

