
using GamingIsLove.ORKFramework;
using UnityEditor;
using UnityEngine;
using GamingIsLove.Makinom;
using GamingIsLove.Makinom.Editor;

namespace GamingIsLove.ORKFramework.Editor
{
	public sealed class TeleportsTab : ORKGenericAssetListTab<TeleportAsset, Teleport>
	{
		public TeleportsTab(MakinomEditorWindow parent) : base(parent)
		{
			ORK.Teleports.SetAssets(this.assetList.Assets);
		}

		public override void Reloaded()
		{
			base.Reloaded();
			ORK.Teleports.SetAssets(this.assetList.Assets);
		}


		/*
		============================================================================
		Properties
		============================================================================
		*/
		public override string Name
		{
			get { return "Teleports"; }
		}

		public override string HelpText
		{
			get
			{
				return "Teleports can be used by the player to change scenes and spawn at defined places.";
			}
		}

		public override string HelpInfo
		{
			get { return "https://orkframework.com/guide/documentation/features/areas-teleports/"; }
		}


		/*
		============================================================================
		Filter functions
		============================================================================
		*/
		protected override FilteredList Filter
		{
			get
			{
				if(this.filter == null)
				{
					this.filter = new FilteredList(this,
						new FilteredListAssetSelection<AreaTypeAsset, AreaType>(
							new string[] { "Area Type", "Filter the teleport list by area type.", "" }));
				}
				return this.filter;
			}
		}

		protected override bool CheckFilterCondition(int index)
		{
			return this.Filter.assetFilterSelection[0].Check(
				this.assetList.Assets[index].Settings.type.Source.EditorAsset);
		}
	}
}
