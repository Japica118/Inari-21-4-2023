
using UnityEditor;
using UnityEngine;
using GamingIsLove.Makinom;
using GamingIsLove.Makinom.Editor;

namespace GamingIsLove.ORKFramework.Editor
{
	public class DifficultiesTab : ORKGenericAssetListTab<DifficultyAsset, Difficulty>
	{
		public DifficultiesTab(MakinomEditorWindow parent) : base(parent)
		{
			ORK.Difficulties.SetAssets(this.assetList.Assets);
		}

		public override void Reloaded()
		{
			base.Reloaded();
			ORK.Difficulties.SetAssets(this.assetList.Assets);
		}


		/*
		============================================================================
		Properties
		============================================================================
		*/
		public override string Name
		{
			get { return "Difficulties"; }
		}

		public override string HelpText
		{
			get
			{
				return "Set up difficulties for your game.\n" +
					"Difficulties can change time factors and impact status values and attack/defence modifiers of factions.";
			}
		}

		public override string HelpInfo
		{
			get { return "https://orkframework.com/guide/documentation/features/difficulties/"; }
		}
	}
}

