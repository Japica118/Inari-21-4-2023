
using GamingIsLove.ORKFramework;
using UnityEditor;
using UnityEngine;
using System.Collections.Generic;
using GamingIsLove.Makinom;
using GamingIsLove.Makinom.Editor;

namespace GamingIsLove.ORKFramework.Editor
{
	public class LogTypesTab : ORKGenericAssetListTab<LogTypeAsset, LogType>
	{
		public LogTypesTab(MakinomEditorWindow parent) : base(parent)
		{
			ORK.LogTypes.SetAssets(this.assetList.Assets);
		}

		public override void Reloaded()
		{
			base.Reloaded();
			ORK.LogTypes.SetAssets(this.assetList.Assets);
		}


		/*
		============================================================================
		Properties
		============================================================================
		*/
		public override string Name
		{
			get { return "Log Settings & Types"; }
		}

		public override string HelpText
		{
			get
			{
				return "Set up basic log settings, e.g. notifications, " +
					"and define log types that are used to separate logs in menus.";
			}
		}

		public override string HelpInfo
		{
			get { return "https://orkframework.com/guide/documentation/features/logs/"; }
		}

		public override bool HasGeneralSettings
		{
			get { return true; }
		}

		public override string GeneralSettingsHelpText
		{
			get
			{
				return "Set up general settings regarding logs.";
			}
		}

		protected override BaseSettings Settings
		{
			get { return ORK.LogSettings; }
		}

		protected override IBaseData DisplayedSettings
		{
			get
			{
				if(this.index == -1)
				{
					return ORK.LogSettings;
				}
				return base.DisplayedSettings;
			}
		}
	}
}
