
using GamingIsLove.ORKFramework;
using UnityEditor;
using UnityEngine;
using GamingIsLove.Makinom;
using GamingIsLove.Makinom.Editor;
using System.Collections.Generic;

namespace GamingIsLove.ORKFramework.Editor
{
	public sealed class ClassesTab : ORKGenericAssetListTab<ClassAsset, Class>
	{
		public ClassesTab(MakinomEditorWindow parent) : base(parent)
		{
			ORK.Classes.SetAssets(this.assetList.Assets);
		}

		public override void Reloaded()
		{
			base.Reloaded();
			ORK.Classes.SetAssets(this.assetList.Assets);
		}


		/*
		============================================================================
		Properties
		============================================================================
		*/
		public override string Name
		{
			get { return "Classes"; }
		}

		public override string HelpText
		{
			get
			{
				return "Classes are used by combatants to influence their abilities and status.";
			}
		}

		public override string HelpInfo
		{
			get { return "https://orkframework.com/guide/documentation/features/classes/"; }
		}


		/*
		============================================================================
		Automation functions
		============================================================================
		*/
		public override void AutomationCallback(string info)
		{
			if(info == "textcodes:description" ||
				info == "textcodes:customcontent")
			{
				EditorGUILayout.HelpBox("<bonus> = bonuses", MessageType.Info, true);
			}
			else if(info == "button:attackmodifierstartvalues")
			{
				Class currentClass = this.CurrentSettings;
				if(currentClass != null)
				{
					EditorGUILayout.BeginHorizontal();
					if(EditorTool.ShowButton(new GUIContent("Set All", EditorContent.Instance.AddIcon),
						"Sets up all attack modifier attributes with their default start value.", "",
						EditorTool.WIDTH_150))
					{
						List<AttackModifierStartValue> startValues = new List<AttackModifierStartValue>();
						GenericAssetList<AttackModifierAsset> modifiers = EditorDataHandler.Instance.GetAssets<AttackModifierAsset>();
						for(int i = 0; i < modifiers.Count; i++)
						{
							for(int j = 0; j < modifiers.Assets[i].Settings.attribute.Length; j++)
							{
								AttackModifierStartValue newValue = new AttackModifierStartValue();
								newValue.modifier.modifier.Source.EditorAsset = modifiers.Assets[i];
								newValue.modifier.index = j;
								newValue.startValue = modifiers.Assets[i].Settings.attribute[j].startValue;
								startValues.Add(newValue);
							}
						}
						currentClass.attackModifierStart = startValues.ToArray();
					}
					if(EditorTool.ShowButton(new GUIContent("Clear", EditorContent.Instance.RemoveIcon),
						"Removes all attack modifier start values.", "",
						EditorTool.WIDTH_150))
					{
						currentClass.attackModifierStart = new AttackModifierStartValue[0];
					}
					GUILayout.FlexibleSpace();
					EditorGUILayout.EndHorizontal();
				}
			}
			else if(info == "button:defencemodifierstartvalues")
			{
				Class currentClass = this.CurrentSettings;
				if(currentClass != null)
				{
					EditorGUILayout.BeginHorizontal();
					if(EditorTool.ShowButton(new GUIContent("Set All", EditorContent.Instance.AddIcon),
						"Sets up all defence modifier attributes with their default start value.", "",
						EditorTool.WIDTH_150))
					{
						List<DefenceModifierStartValue> startValues = new List<DefenceModifierStartValue>();
						GenericAssetList<DefenceModifierAsset> modifiers = EditorDataHandler.Instance.GetAssets<DefenceModifierAsset>();
						for(int i = 0; i < modifiers.Count; i++)
						{
							for(int j = 0; j < modifiers.Assets[i].Settings.attribute.Length; j++)
							{
								DefenceModifierStartValue newValue = new DefenceModifierStartValue();
								newValue.modifier.modifier.Source.EditorAsset = modifiers.Assets[i];
								newValue.modifier.index = j;
								newValue.startValue = modifiers.Assets[i].Settings.attribute[j].startValue;
								startValues.Add(newValue);
							}
						}
						currentClass.defenceModifierStart = startValues.ToArray();
					}
					if(EditorTool.ShowButton(new GUIContent("Clear", EditorContent.Instance.RemoveIcon),
						"Removes all attack modifier start values.", "",
						EditorTool.WIDTH_150))
					{
						currentClass.defenceModifierStart = new DefenceModifierStartValue[0];
					}
					GUILayout.FlexibleSpace();
					EditorGUILayout.EndHorizontal();
				}
			}
			else
			{
				base.AutomationCallback(info);
			}
		}

		public override void InstanceCallback(string info, object instance)
		{
			if(info == "button:classequipableon")
			{
				ClassSlotEquipSettings setting = instance as ClassSlotEquipSettings;
				if(setting != null)
				{
					EditorGUILayout.BeginHorizontal();
					if(EditorTool.ShowButton(new GUIContent("Set All", EditorContent.Instance.AddIcon),
						"Sets up all class slots.", "",
						EditorTool.WIDTH_150))
					{
						List<AssetSelection<ClassSlotAsset>> list = new List<AssetSelection<ClassSlotAsset>>();
						GenericAssetList<ClassSlotAsset> classSlots = EditorDataHandler.Instance.GetAssets<ClassSlotAsset>();
						for(int i = 0; i < classSlots.Count; i++)
						{
							AssetSelection<ClassSlotAsset> newSlot = new AssetSelection<ClassSlotAsset>();
							newSlot.Source.EditorAsset = classSlots.Assets[i];
							list.Add(newSlot);
						}
						setting.classSlot = list.ToArray();
					}
					if(EditorTool.ShowButton(new GUIContent("Clear", EditorContent.Instance.RemoveIcon),
						"Removes all class slots.", "",
						EditorTool.WIDTH_150))
					{
						setting.classSlot = new AssetSelection<ClassSlotAsset>[0];
					}
					GUILayout.FlexibleSpace();
					EditorGUILayout.EndHorizontal();
				}
			}
			else
			{
				base.InstanceCallback(info, instance);
			}
		}
	}
}

