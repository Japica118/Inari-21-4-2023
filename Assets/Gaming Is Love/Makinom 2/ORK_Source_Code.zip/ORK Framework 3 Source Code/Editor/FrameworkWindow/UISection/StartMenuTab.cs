
using GamingIsLove.ORKFramework;
using UnityEngine;
using UnityEditor;
using GamingIsLove.Makinom;
using GamingIsLove.Makinom.Editor;

namespace GamingIsLove.ORKFramework.Editor
{
	public sealed class StartMenuTab : ORKBaseEditorTab
	{
		public StartMenuTab(MakinomEditorWindow parent)
		{
			this.parent = parent;

			this.DefaultSetup();
		}


		/*
		============================================================================
		Properties
		============================================================================
		*/
		public override string Name
		{
			get { return "Start Menu"; }
		}

		public override string HelpText
		{
			get { return "Set up ORK's start menu (to start the game) and how starting a new game is handled."; }
		}

		public override string HelpInfo
		{
			get { return "https://orkframework.com/guide/documentation/ui-system/start-menu/"; }
		}

		protected override BaseSettings Settings
		{
			get { return ORK.StartMenu; }
		}

		protected override IBaseData DisplayedSettings
		{
			get { return ORK.StartMenu; }
		}
	}
}

