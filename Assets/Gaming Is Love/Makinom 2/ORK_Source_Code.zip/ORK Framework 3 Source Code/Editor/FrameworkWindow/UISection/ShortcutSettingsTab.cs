﻿
using GamingIsLove.ORKFramework;
using UnityEngine;
using UnityEditor;
using GamingIsLove.Makinom;
using GamingIsLove.Makinom.Editor;

namespace GamingIsLove.ORKFramework.Editor
{
	public sealed class ShortcutSettingsTab : ORKBaseEditorTab
	{
		public ShortcutSettingsTab(MakinomEditorWindow parent)
		{
			this.parent = parent;

			this.DefaultSetup();
		}


		/*
		============================================================================
		Properties
		============================================================================
		*/
		public override string Name
		{
			get { return "Shortcut Settings"; }
		}

		public override string HelpText
		{
			get
			{
				return "Set up default shortcut assignments and UI layouts.\n" +
					"A shortcut is e.g. an ability or item assigned to a shortcut slot.";
			}
		}

		public override string HelpInfo
		{
			get { return "https://orkframework.com/guide/documentation/features/shortcut-slots/"; }
		}

		protected override BaseSettings Settings
		{
			get { return ORK.ShortcutSettings; }
		}

		protected override IBaseData DisplayedSettings
		{
			get { return ORK.ShortcutSettings; }
		}
	}
}
