
using UnityEditor;
using UnityEngine;
using GamingIsLove.Makinom;
using GamingIsLove.Makinom.Editor;
using GamingIsLove.ORKFramework.UI;

namespace GamingIsLove.ORKFramework.Editor
{
	public sealed class QuantitySelectionsTab : ORKGenericAssetListTab<QuantitySelectionAsset, QuantitySelection>
	{
		public QuantitySelectionsTab(MakinomEditorWindow parent) : base(parent)
		{

		}

		public override void DefaultSetup()
		{
			base.DefaultSetup();
			if(Maki.Data.ProjectAsset.IsEmpty &&
				this.assetList.AssetExists(0))
			{
				ORK.QuantitySelections.quantityRemove.quantitySelection.Source.EditorAsset = this.assetList.Assets[0];
				ORK.QuantitySelections.quantityDrop.quantitySelection.Source.EditorAsset = this.assetList.Assets[0];
				ORK.QuantitySelections.quantityGive.quantitySelection.Source.EditorAsset = this.assetList.Assets[0];
				ORK.QuantitySelections.quantityBuy.quantitySelection.Source.EditorAsset = this.assetList.Assets[0];
				ORK.QuantitySelections.quantitySell.quantitySelection.Source.EditorAsset = this.assetList.Assets[0];
			}
		}


		/*
		============================================================================
		Properties
		============================================================================
		*/
		public override string Name
		{
			get { return "Quantity Selections"; }
		}

		public override string HelpText
		{
			get
			{
				return "Quantity selections are used by menu screens and shops to select item quantities.";
			}
		}

		public override string HelpInfo
		{
			get { return "https://orkframework.com/guide/documentation/ui-system/quantity-selections/"; }
		}

		public override bool HasGeneralSettings
		{
			get { return true; }
		}

		public override string GeneralSettingsHelpText
		{
			get
			{
				return "Set up the default quantity selections.";
			}
		}

		protected override BaseSettings Settings
		{
			get { return ORK.QuantitySelections; }
		}

		protected override IBaseData DisplayedSettings
		{
			get
			{
				if(this.index == -1)
				{
					return ORK.QuantitySelections;
				}
				return base.DisplayedSettings;
			}
		}
	}
}
