
using UnityEditor;
using UnityEngine;
using GamingIsLove.Makinom;
using GamingIsLove.Makinom.Editor;

namespace GamingIsLove.ORKFramework.Editor
{
	public class ControlMapsTab : ORKGenericAssetListTab<ControlMapAsset, ControlMap>
	{
		public ControlMapsTab(MakinomEditorWindow parent) : base(parent)
		{
			ORK.ControlMaps.SetAssets(this.assetList.Assets);
		}

		public override void Reloaded()
		{
			base.Reloaded();
			ORK.ControlMaps.SetAssets(this.assetList.Assets);
		}


		/*
		============================================================================
		Properties
		============================================================================
		*/
		public override string Name
		{
			get { return "Control Maps"; }
		}

		public override string HelpText
		{
			get
			{
				return "Control maps are used to call actions via input keys.\n" +
					"A combatant needs to have the control map added to it's settings to be able to use it.";
			}
		}

		public override string HelpInfo
		{
			get { return "https://orkframework.com/guide/documentation/features/control-maps/"; }
		}
	}
}
