
using GamingIsLove.ORKFramework;
using UnityEditor;
using UnityEngine;
using GamingIsLove.Makinom;
using GamingIsLove.Makinom.Editor;

namespace GamingIsLove.ORKFramework.Editor
{
	public class MenuRequirementsTab : ORKGenericAssetListTab<MenuRequirementAsset, MenuRequirement>
	{
		public MenuRequirementsTab(MakinomEditorWindow parent) : base(parent)
		{

		}


		/*
		============================================================================
		Properties
		============================================================================
		*/
		public override string Name
		{
			get { return "Menu Requirements"; }
		}

		public override string HelpText
		{
			get
			{
				return "Menu requirements are used to define if a menu screen can be opened.\n" +
					"E.g. only have an inventory menu available when there are items in the inventory.";
			}
		}

		public override string HelpInfo
		{
			get { return "https://orkframework.com/guide/documentation/ui-system/menu-requirements/"; }
		}
	}
}

