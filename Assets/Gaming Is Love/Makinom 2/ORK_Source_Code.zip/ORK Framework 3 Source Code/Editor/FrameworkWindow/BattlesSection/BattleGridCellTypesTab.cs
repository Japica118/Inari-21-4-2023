﻿
using GamingIsLove.ORKFramework;
using UnityEditor;
using UnityEngine;
using GamingIsLove.Makinom;
using GamingIsLove.Makinom.Editor;

namespace GamingIsLove.ORKFramework.Editor
{
	public sealed class BattleGridCellTypesTab : ORKGenericAssetListTab<BattleGridCellTypeAsset, BattleGridCellType>
	{
		public BattleGridCellTypesTab(MakinomEditorWindow parent) : base(parent)
		{

		}


		/*
		============================================================================
		Properties
		============================================================================
		*/
		public override string Name
		{
			get { return "Battle Grid Cell Types"; }
		}

		public override string HelpText
		{
			get
			{
				return "Battle grid cell types are used by battle grids to define the individual cells of the grid.";
			}
		}

		public override string HelpInfo
		{
			get { return "https://orkframework.com/guide/documentation/battles/grid-battles/"; }
		}


		/*
		============================================================================
		Name/description help labels
		============================================================================
		*/
		public override void AutomationCallback(string info)
		{
			if(info == "textcodes:name" ||
				info == "textcodes:shortname" ||
				info == "textcodes:description" ||
				info == "textcodes:customcontent")
			{
				EditorGUILayout.HelpBox("<movecost> = move cost (0), <movecost1> = move cost (0.0), <movecost2> = move cost (0.00)",
					MessageType.Info, true);
			}
			else if(info == "label:totalchance")
			{
				BattleGridCellType cellType = this.CurrentSettings;
				if(cellType != null &&
					cellType.isRandomCellType)
				{
					float chance = 0;
					for(int i = 0; i < cellType.randomCellType.randomCellType.Length; i++)
					{
						chance += cellType.randomCellType.randomCellType[i].chance;
					}
					EditorGUILayout.LabelField("Total Chance", chance.ToString("0.0") + " of " + Maki.GameSettings.maxRandomRange.ToString("0.0"));
				}
			}
			else
			{
				base.AutomationCallback(info);
			}
		}
	}
}

