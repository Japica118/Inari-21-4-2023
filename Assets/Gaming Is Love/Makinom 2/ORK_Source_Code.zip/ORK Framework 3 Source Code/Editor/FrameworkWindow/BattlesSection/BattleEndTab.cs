
using GamingIsLove.ORKFramework;
using UnityEngine;
using UnityEditor;
using GamingIsLove.Makinom;
using GamingIsLove.Makinom.Editor;

namespace GamingIsLove.ORKFramework.Editor
{
	public sealed class BattleEndTab : ORKBaseEditorTab
	{
		public BattleEndTab(MakinomEditorWindow parent)
		{
			this.parent = parent;

			this.DefaultSetup();
		}


		/*
		============================================================================
		Properties
		============================================================================
		*/
		public override string Name
		{
			get { return "Battle End"; }
		}

		public override string HelpText
		{
			get { return "Change how battle gains are displayed and distributed at the end of a battle."; }
		}

		public override string HelpInfo
		{
			get { return "https://orkframework.com/guide/documentation/battles/battle-end/"; }
		}

		protected override BaseSettings Settings
		{
			get { return ORK.BattleEnd; }
		}

		protected override IBaseData DisplayedSettings
		{
			get { return ORK.BattleEnd; }
		}
	}
}
