
using GamingIsLove.Makinom;
using GamingIsLove.Makinom.Editor;
using GamingIsLove.ORKFramework;
using GamingIsLove.ORKFramework.Editor;
using GamingIsLove.ORKFramework.Components;
using UnityEditor;
using UnityEngine;

[CustomEditor(typeof(BattleComponent))]
public class BattleComponentInspector : BaseInspector
{
	public override void OnInspectorGUI()
	{
		this.ComponentSetup(target as BattleComponent);
	}

	protected virtual void ComponentSetup(BattleComponent target)
	{
		Undo.RecordObject(target, "Change to 'Battle' on " + target.name);
		this.BaseInit(true);

		// scene ID
		this.ShowSceneID<BaseBattleComponent>(target,
			"The scene ID is used to keep track of finished battles. " +
			"If battles share the same ID (in a scene), their finished state will be shared.\n" +
			"The scene ID is used scene-wide, i.e. not in different scenes.");

		if(!target.settings.allGroups &&
			target.settings.useChanceSelection)
		{
			float totalChance = 0;
			for(int i = 0; i < target.settings.combatant.Length; i++)
			{
				totalChance += target.settings.combatant[i].chance;
			}
			EditorGUILayout.LabelField("Total Chance", totalChance.ToString("0.0") + " of " + Maki.GameSettings.maxRandomRange.ToString("0.0"));
		}

		EditorAutomation.Automate(target.settings, this.baseEditor);


		// battle spots
		if(this.baseEditor.BeginFoldout("Battle Spots",
			"Optionally use different battle spots in this battle.", "", false))
		{
			if(GUILayout.Button(new GUIContent("Create Battle Spots",
				"Create empty game objects for the battle spots defined in 'Battles > Battle Spots'.")))
			{
				target.CreateDefaultSpotGameObjects();
			}

			target.settings.useCombatantPositionSpots = EditorGUILayout.Toggle(
				new GUIContent("Combatant Position Spots", "Use the combatant's current position as battle spot."),
				target.settings.useCombatantPositionSpots);

			// player spots
			EditorGUILayout.Separator();
			target.settings.ownPlayerSpots = EditorGUILayout.Toggle(
				new GUIContent("Own Player Spots", "Define custom battle spots for the player group using game objects in the scene."),
				target.settings.ownPlayerSpots);
			if(target.settings.ownPlayerSpots)
			{
				EditorGUI.indentLevel++;
				this.ShowSerializedProperty("playerSpot");
				this.ShowSerializedProperty("playerSpotPlayerAdvantage");
				this.ShowSerializedProperty("playerSpotEnemyAdvantage");
				EditorGUI.indentLevel--;
			}

			// ally spots
			EditorGUILayout.Separator();
			target.settings.ownAllySpots = EditorGUILayout.Toggle(
				new GUIContent("Own Ally Spots", "Define custom battle spots for allies of the player using game objects in the scene."),
				target.settings.ownAllySpots);
			if(target.settings.ownAllySpots)
			{
				EditorGUI.indentLevel++;
				this.ShowSerializedProperty("allySpot");
				this.ShowSerializedProperty("allySpotPlayerAdvantage");
				this.ShowSerializedProperty("allySpotEnemyAdvantage");
				EditorGUI.indentLevel--;
			}

			// enemy spots
			EditorGUILayout.Separator();
			target.settings.ownEnemySpots = EditorGUILayout.Toggle(
				new GUIContent("Own Enemy Spots", "Define custom battle spots for enemies of the player using game objects in the scene."),
				target.settings.ownEnemySpots);
			if(target.settings.ownEnemySpots)
			{
				EditorGUI.indentLevel++;
				this.ShowSerializedProperty("enemySpot");
				this.ShowSerializedProperty("enemySpotPlayerAdvantage");
				this.ShowSerializedProperty("enemySpotEnemyAdvantage");
				EditorGUI.indentLevel--;
			}
			EditorGUILayout.Separator();
		}
		this.baseEditor.EndFoldout();


		// start settings
		this.ShowBaseInteraction(target);

		this.EndSetup();
	}
}
