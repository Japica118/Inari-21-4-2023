
using GamingIsLove.Makinom;
using GamingIsLove.Makinom.Editor;
using GamingIsLove.ORKFramework;
using GamingIsLove.ORKFramework.Editor;
using GamingIsLove.ORKFramework.Components;
using UnityEditor;
using UnityEngine;

[CustomEditor(typeof(RandomBattleArea))]
public class RandomBattleAreaInspector : BaseInspector
{
	public override void OnInspectorGUI()
	{
		this.ComponentSetup(target as RandomBattleArea);
	}

	protected virtual void ComponentSetup(RandomBattleArea target)
	{
		Undo.RecordObject(target, "Change to 'Random Battle Area' on " + target.name);
		this.BaseInit(true);

		float totalChance = 0;
		for(int i = 0; i < target.settings.combatant.Length; i++)
		{
			totalChance += target.settings.combatant[i].chance;
		}
		EditorGUILayout.LabelField("Total Chance", totalChance.ToString("0.0") + " of " + Maki.GameSettings.maxRandomRange.ToString("0.0"));

		if(totalChance > Maki.GameSettings.maxRandomRange)
		{
			EditorTool.BoldLabel("Warning!");
			EditorGUILayout.HelpBox("Total chance is above the maximum random value!\n" +
				"This can result in some combatants/groups never being used.",
				MessageType.Info);
		}
		else if(totalChance < Maki.GameSettings.maxRandomRange)
		{
			EditorTool.BoldLabel("Warning!");
			EditorGUILayout.HelpBox("Total chance is below the maximum random value!\n" +
				"This can result in battles not taking place.",
				MessageType.Info);
		}

		EditorAutomation.Automate(target.settings, this.baseEditor);


		// start settings
		this.ShowBaseCondition(target);

		this.EndSetup();
	}
}
