
using GamingIsLove.Makinom.Editor;
using GamingIsLove.ORKFramework;
using GamingIsLove.ORKFramework.Editor;
using GamingIsLove.ORKFramework.Components;
using GamingIsLove.Makinom;
using UnityEditor;
using UnityEngine;
using System.Collections.Generic;

[CustomEditor(typeof(CombatantComponent))]
public class CombatantComponentInspector : BaseInspector
{
	protected StatusValueTool statusValue = new StatusValueTool();

	protected StatusEffectTool statusEffect = new StatusEffectTool();

	protected Combatant combatant;

	public override void OnInspectorGUI()
	{
		this.ComponentSetup(target as CombatantComponent);
	}

	private void ComponentSetup(CombatantComponent target)
	{
		this.BaseInit(true);

		this.combatant = target.Combatant;

		if(combatant != null)
		{
			// basic info
			if(this.baseEditor.BeginFoldout("Basic Information", "", "", true))
			{
				if(ORK.Game.ActiveGroup.Leader == combatant)
				{
					EditorTool.BoldLabel("Player");
				}
				EditorGUILayout.LabelField("Name", combatant.GetName());
				EditorGUILayout.LabelField("Faction", combatant.Group.Faction != null ? combatant.Group.Faction.GetName() : "-");
				EditorGUILayout.LabelField("Level", combatant.Status.Level.ToString());
				EditorGUILayout.LabelField("Class", combatant.Class.Current != null ? combatant.Class.Current.GetName() : "-");
				EditorGUILayout.LabelField("Class Level", combatant.Class.Level.ToString());
				EditorGUILayout.LabelField("Is Dead", combatant.Status.IsDead.ToString());
				EditorGUILayout.LabelField("Is Passive", combatant.IsPassive.ToString());
				EditorGUILayout.LabelField("Speed", target.HorizontalSpeed.ToString("0.0"));
				EditorGUILayout.LabelField("Inventory Space", combatant.Inventory.Space + "/" + combatant.Inventory.TotalSpace);
				if(combatant.Inventory.HasContainers)
				{
					for(int i = 0; i < combatant.Inventory.Container.Length; i++)
					{
						EditorGUILayout.LabelField("Inventory Container " + i, combatant.Inventory.Container[i].OccupiedSlots + "/" + combatant.Inventory.Container[i].TotalSlots);
					}
				}

				EditorGUILayout.Separator();
			}
			this.baseEditor.EndFoldout();


			// status values
			if(this.baseEditor.BeginFoldout("Status Values", "", "", true))
			{
				EditorAutomation.Automate(this.statusValue, this.baseEditor);
				EditorGUI.BeginDisabledGroup(this.statusValue.statusValue.StoredAsset == null);
				if(GUILayout.Button(new GUIContent(
					"Change Status Value", EditorContent.Instance.AddIcon,
					"Change the selected status value on the combatant.")))
				{
					this.statusValue.Use(combatant);
				}
				EditorGUI.EndDisabledGroup();

				EditorGUILayout.Separator();
				for(int i = 0; i < ORK.StatusValues.Count; i++)
				{
					StatusValue value = combatant.Status[i];
					EditorGUILayout.LabelField(value.Setting.GetName(), value.GetValue().ToString());
				}

				EditorGUILayout.Separator();
			}
			this.baseEditor.EndFoldout();


			// status effects
			if(this.baseEditor.BeginFoldout("Status Effects", "", "", false))
			{
				EditorAutomation.Automate(this.statusEffect, this.baseEditor);
				EditorGUI.BeginDisabledGroup(this.statusEffect.effect.StoredAsset == null);
				if(GUILayout.Button(new GUIContent(
					"Add Status Effect", EditorContent.Instance.AddIcon,
					"Add the selected status effect to the combatant.")))
				{
					this.statusEffect.Use(combatant);
				}
				EditorGUI.EndDisabledGroup();

				EditorGUILayout.Separator();
				List<StatusEffect> effects = combatant.Status.Effects.GetEffects();
				for(int i = 0; i < effects.Count; i++)
				{
					EditorGUILayout.BeginHorizontal();
					if(GUILayout.Button(new GUIContent(EditorContent.Instance.RemoveIcon, "Remove this status effect"), EditorTool.WIDTH_30))
					{
						combatant.Status.Effects.Remove(effects[i].Setting, false, true, 1, null);
						return;
					}
					EditorGUILayout.LabelField(effects[i].GetName(), effects[i].RemainingTimeHUD(1, "-"));
					EditorGUILayout.EndHorizontal();
				}

				EditorGUILayout.Separator();
			}
			this.baseEditor.EndFoldout();


			// attack modifiers
			if(this.baseEditor.BeginFoldout("Attack Modifiers", "", "", false))
			{
				for(int i = 0; i < ORK.AttackModifiers.Count; i++)
				{
					AttackModifierSetting attribute = ORK.AttackModifiers.Get(i);
					EditorTool.BoldLabel(attribute.GetName());
					for(int j = 0; j < attribute.attribute.Length; j++)
					{
						EditorGUILayout.LabelField(attribute.attribute[j].GetName(),
							combatant.Status.GetAttackModifier(attribute).GetValue(j).ToString());
					}
				}
				EditorGUILayout.Separator();
			}
			this.baseEditor.EndFoldout();


			// defence modifiers
			if(this.baseEditor.BeginFoldout("Defence Modifiers", "", "", false))
			{
				EditorTool.BoldLabel("Defence Modifier IDs");
				int[] modifierID = combatant.Status.GetDefenceModifierIDs();
				for(int i = 0; i < modifierID.Length; i++)
				{
					DefenceModifierSetting modifier = ORK.DefenceModifiers.Get(i);
					EditorGUILayout.LabelField(modifier.GetName(), modifier.attribute[modifierID[i]].GetName());
				}
				EditorGUILayout.Separator();

				for(int i = 0; i < ORK.DefenceModifiers.Count; i++)
				{
					DefenceModifierSetting modifier = ORK.DefenceModifiers.Get(i);
					EditorTool.BoldLabel(modifier.GetName());
					for(int j = 0; j < modifier.attribute.Length; j++)
					{
						EditorGUILayout.LabelField(modifier.attribute[j].GetName(),
							combatant.Status.GetDefenceModifier(modifier).GetValue(j).ToString());
					}
				}
				EditorGUILayout.Separator();
			}
			this.baseEditor.EndFoldout();


			// equipment
			if(this.baseEditor.BeginFoldout("Equipment, Class Slots & AI Slots", "", "", false))
			{
				EditorTool.BoldLabel("Equipment Slots");
				for(int i = 0; i < ORK.EquipmentSlots.Count; i++)
				{
					if(combatant.Equipment[i].Available)
					{
						EditorGUILayout.LabelField(combatant.Equipment[i].Settings.GetName(),
							(combatant.Equipment[i].Equipped ?
								combatant.Equipment[i].Equipment.GetName() :
								"Empty"));
					}
				}
				EditorGUILayout.Separator();

				EditorTool.BoldLabel("Class Slots");
				for(int i = 0; i < ORK.ClassSlots.Count; i++)
				{
					if(combatant.Class[i].Available)
					{
						EditorGUILayout.LabelField(combatant.Class[i].Settings.GetName(),
							(combatant.Class[i].Equipped ?
								combatant.Class[i].Class.GetName() :
								"Empty"));
					}
				}
				EditorGUILayout.Separator();

				if(combatant.AI.AIBehaviourSlot.Length > 0)
				{
					EditorTool.BoldLabel("AI Behaviour Slots");
					for(int i = 0; i < combatant.AI.AIBehaviourSlot.Length; i++)
					{
						if(combatant.AI.AIBehaviourSlot[i].Equipped)
						{
							EditorGUILayout.LabelField("Behaviour Slot " + i,
								combatant.AI.AIBehaviourSlot[i].AIBehaviour.GetName());
						}
						else
						{
							EditorGUILayout.LabelField("Behaviour Slot " + i, "Empty");
						}
					}

					EditorGUILayout.Separator();
				}

				if(combatant.AI.AIRulesetSlot.Length > 0)
				{
					EditorTool.BoldLabel("AI Ruleset Slots");
					for(int i = 0; i < combatant.AI.AIRulesetSlot.Length; i++)
					{
						if(combatant.AI.AIRulesetSlot[i].Equipped)
						{
							EditorGUILayout.LabelField("Ruleset Slot " + i,
								combatant.AI.AIRulesetSlot[i].AIRuleset.GetName());
						}
						else
						{
							EditorGUILayout.LabelField("Ruleset Slot " + i, "Empty");
						}
					}

					EditorGUILayout.Separator();
				}
			}
			this.baseEditor.EndFoldout();


			// battle infos
			if(this.baseEditor.BeginFoldout("Battle Information", "", "", false))
			{
				EditorGUILayout.LabelField("In Battle", combatant.Battle.InBattle.ToString());
				EditorGUILayout.LabelField("Turn", combatant.Battle.Turn.ToString());
				EditorGUILayout.LabelField("Turn Value", combatant.Battle.TurnValue.ToString());
				EditorGUILayout.LabelField("Turn State", combatant.Battle.TurnState.ToString());
				EditorGUILayout.LabelField("Finished Choosing", combatant.Actions.FinishedChoosing.ToString());
				EditorGUILayout.LabelField("Attack Index", combatant.Abilities.AttackIndex.ToString());
				EditorGUILayout.LabelField("Defending", combatant.Battle.Defending.ToString());
				EditorGUILayout.LabelField("Is Aggressive", combatant.IsAggressive.ToString());
				EditorGUILayout.LabelField("Is Leader", combatant.IsLeader.ToString());
				EditorGUILayout.LabelField("Item Stolen", combatant.Battle.ItemStolen.ToString());
				EditorGUILayout.LabelField("Currency Stolen", combatant.Battle.CurrencyStolen.ToString());
				EditorGUILayout.Separator();

				EditorTool.BoldLabel("Battle Actions");
				EditorGUILayout.LabelField("Can Choose", combatant.Actions.CanChoose.ToString());
				EditorGUILayout.LabelField("Is Choosing", combatant.Actions.IsChoosing.ToString());
				EditorGUILayout.LabelField("Action Fired", combatant.Actions.Fired.ToString());
				EditorGUILayout.LabelField("Action State", combatant.Actions.ActionState.ToString());
				EditorGUILayout.LabelField("Waiting for Action", combatant.Actions.IsWaiting.ToString());
				EditorGUILayout.LabelField("Auto Attacking", combatant.Actions.AutoAttacking.ToString());
				EditorGUILayout.LabelField("Current Action", combatant.Actions.Current != null ? combatant.Actions.Current.GetName() : "-");

				if(ORK.Battle.IsActiveTime())
				{
					EditorGUILayout.LabelField("Time Bar", combatant.Battle.ActionBar.ToString());
					EditorGUILayout.LabelField("Used Time Bar", combatant.Battle.UsedActionBar.ToString());
				}
				else if(ORK.Battle.IsTurnBased() ||
					ORK.Battle.IsPhase())
				{
					EditorGUILayout.LabelField("Receive Actions Per Turn", combatant.Battle.ReceiveActionsPerTurn.ToString());
					EditorGUILayout.LabelField("Action Bar", combatant.Battle.ActionBar.ToString());
					EditorGUILayout.LabelField("Used Action Bar", combatant.Battle.UsedActionBar.ToString());
					EditorGUILayout.LabelField("Action Time", combatant.Battle.ActionTime.ToString("0.0") +
						"/" + combatant.Battle.ActionTimeMax.ToString("0.0"));
				}

				if(ORK.Battle.Grid != null)
				{
					EditorGUILayout.LabelField("Move Range", combatant.Battle.GridMoveRange.ToString());
				}

				EditorGUILayout.Separator();

				// AI action queue
				if(combatant.AI.ActionQueue.Count > 0)
				{
					EditorTool.BoldLabel("AI Action Queue");
					for(int i = 0; i < combatant.AI.ActionQueue.Count; i++)
					{
						EditorGUILayout.LabelField("Action " + i, combatant.AI.ActionQueue[i].GetName());
					}

					EditorGUILayout.Separator();
				}
			}
			this.baseEditor.EndFoldout();
		}
	}


	/*
	============================================================================
	Tool classes
	============================================================================
	*/
	protected class StatusValueTool : BaseData
	{
		[EditorHelp("Status Value", "Select a status value that will be changed on the combatant.")]
		public AssetSelection<StatusValueAsset> statusValue = new AssetSelection<StatusValueAsset>();

		[EditorHelp("Change Value", "The value by which the status value will be changed.")]
		public int changeValue = 0;

		[EditorHelp("Operator", "Either 'Add' or subtract ('Sub') the value, or 'Set' the status value to the change value.", "")]
		public SimpleOperator simpleOperator = SimpleOperator.Add;

		public StatusValueTool()
		{

		}

		public void Use(Combatant combatant)
		{
			if(this.statusValue.StoredAsset != null)
			{
				StatusValue status = combatant.Status.Get(this.statusValue.StoredAsset.Settings);
				if(SimpleOperator.Add == this.simpleOperator)
				{
					status.AddValueAccess(this.changeValue,
						false, false, false, false, false, true, true, null);
				}
				else if(SimpleOperator.Sub == this.simpleOperator)
				{
					status.AddValueAccess(-this.changeValue,
						false, false, false, false, false, true, true, null);
				}
				else if(SimpleOperator.Set == this.simpleOperator)
				{
					status.SetValueAccess(this.changeValue,
						false, false, false, true, true, null);
				}
			}
		}
	}

	protected class StatusEffectTool : BaseData
	{
		[EditorHelp("Status Effect", "Select a status effect that will be added to the combatant.")]
		public AssetSelection<StatusEffectAsset> effect = new AssetSelection<StatusEffectAsset>();

		public StatusEffectTool()
		{

		}

		public void Use(Combatant combatant)
		{
			combatant.Status.Effects.Add(this.effect.StoredAsset.Settings,
				combatant, null, false, false, null, null, null);
		}
	}
}
