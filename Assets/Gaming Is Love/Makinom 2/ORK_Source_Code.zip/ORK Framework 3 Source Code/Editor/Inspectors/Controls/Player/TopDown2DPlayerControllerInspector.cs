﻿
using GamingIsLove.Makinom.Editor;
using GamingIsLove.ORKFramework;
using GamingIsLove.ORKFramework.Editor;
using GamingIsLove.ORKFramework.Components;
using UnityEditor;
using UnityEngine;
using GamingIsLove.Makinom;

[CustomEditor(typeof(TopDown2DPlayerController))]
public class TopDown2DPlayerControllerInspector : BaseInspector
{
	public override void OnInspectorGUI()
	{
		this.ComponentSetup(target as TopDown2DPlayerController);
	}

	protected virtual void ComponentSetup(TopDown2DPlayerController target)
	{
		Undo.RecordObject(target, "Change to 'Top Down 2D Player Controller' on " + target.name);
		this.BaseInit(false);

		EditorAutomation.Automate(target.settings, this.baseEditor);

		this.EndSetup();
	}
}