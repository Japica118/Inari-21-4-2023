
using GamingIsLove.ORKFramework;
using GamingIsLove.ORKFramework.UI;
using System.Collections;
using UnityEngine;
using GamingIsLove.Makinom;
using GamingIsLove.Makinom.Components;

namespace GamingIsLove.ORKFramework.Components
{
	[AddComponentMenu("ORK Framework/Interaction/Shop Interaction")]
	public class ShopInteraction : BaseInteractionComponent, ISceneGUID, ISerializationCallbackReceiver
	{
		[System.NonSerialized]
		public Settings settings = new Settings();

		[SerializeField]
		[HideInInspector]
		protected ComponentDataFile serialize_setting;

		protected virtual void Reset()
		{
			this.startSettings.interactStartSetting.isInteract = true;
		}

		public override void StartInteraction(GameObject startingObject)
		{
			if(!this.isStarted &&
				this.settings.shop.StoredAsset != null)
			{
				this.DoTurns(startingObject);
				this.CancelAutoDestroy();
				this.isStarted = true;

				ORK.Access.Inventory.OpenShop(this.gameObject, this.ShopClosed,
					this.settings.shop.StoredAsset.Settings, 
					this.settings.useShopID ? this.settings.shopID : "",
					this.settings.useFaction && this.settings.faction.StoredAsset != null ?
						this.settings.faction.StoredAsset.Settings : null);
			}
		}

		public virtual void ShopClosed(bool transactionHappened)
		{
			this.isStarted = false;
			this.EndCheck();
		}

		protected virtual void OnDrawGizmos()
		{
			Gizmos.DrawIcon(transform.position, "/GamingIsLove/ORKFramework/Components/ShopInteraction Icon.png");
		}

		public virtual bool UseSceneGUID
		{
			get { return this.settings.useShopID; }
			set { this.settings.useShopID = value; }
		}

		public virtual string SceneGUID
		{
			get { return this.settings.shopID; }
			set { this.settings.shopID = value; }
		}


		/*
		============================================================================
		Serialization functions
		============================================================================
		*/
		public override void OnBeforeSerialize()
		{
			base.OnBeforeSerialize();
			this.serialize_setting = this.settings.GetData().GetComponentDataFile("settings", false);
		}

		public override void OnAfterDeserialize()
		{
			base.OnAfterDeserialize();
			if(this.serialize_setting != null)
			{
				this.settings.SetData(this.serialize_setting.ToDataObject());
				this.serialize_setting = null;
			}
		}


		/*
		============================================================================
		Settings class
		============================================================================
		*/
		public class Settings : BaseData
		{
			// shop ID
			[EditorHide]
			public bool useShopID = true;

			[EditorHide]
			public string shopID = "";

			[EditorHelp("Shop", "Select the shop that will be opened.", "")]
			public AssetSelection<ShopAsset> shop = new AssetSelection<ShopAsset>();


			// faction settings
			[EditorHelp("Use Faction", "This shop belongs to a faction and uses the faction's buy/sell price modifiers.\n" +
				"If disabled, the shop won't belong to a faction and no price modifiers are used.", "")]
			public bool useFaction = false;

			[EditorHelp("Faction", "Select the faction the shop will belong to.", "")]
			[EditorCondition("useFaction", true)]
			[EditorEndCondition]
			public AssetSelection<FactionAsset> faction = new AssetSelection<FactionAsset>();

			public Settings()
			{

			}
		}
	}
}
