
using UnityEngine;
using System.Collections;
using GamingIsLove.Makinom;

namespace GamingIsLove.ORKFramework.Components
{
	[AddComponentMenu("ORK Framework/Camera Control/No Camera Control")]
	public class NoCameraControl : MonoBehaviour
	{
	
	}
}
