
using GamingIsLove.ORKFramework;
using UnityEngine;
using GamingIsLove.Makinom;

namespace GamingIsLove.ORKFramework.Components
{
	[AddComponentMenu("ORK Framework/Camera Control/First Person Camera")]
	public class FirstPersonCamera : BaseCameraControl, ISerializationCallbackReceiver
	{
		[System.NonSerialized]
		public FirstPersonCameraSettings settings = new FirstPersonCameraSettings();

		[SerializeField]
		[HideInInspector]
		protected ComponentDataFile serialize_setting;

		public override bool UseUnscaledTime
		{
			get { return this.settings.useUnscaledTime; }
		}

		protected virtual void LateUpdate()
		{
			GameObject targetObject = this.CameraTarget;
			if(targetObject != null)
			{
				DataCall call = this.settings.horizontalSensitivity.NeedsCall ||
						this.settings.horizontalInvert.NeedsCall ||
						this.settings.verticalSensitivity.NeedsCall ||
						this.settings.verticalInvert.NeedsCall ? 
					new DataCall(ORK.Game.ActiveGroup.Leader, this.gameObject) : null;
				Transform target = targetObject.transform;

				if(this.settings.lockCursor)
				{
					Cursor.lockState = CursorLockMode.Locked;
					Cursor.visible = false;
				}

				// horizontal
				float rotX = InputKey.GetAxis(this.settings.horizontalAxis) *
					this.settings.horizontalSensitivity.GetValue(call);
				if(this.settings.horizontalInvert.GetValue(call))
				{
					rotX *= -1;
				}
				// vertical
				float rotY = InputKey.GetAxis(this.settings.verticalAxis) *
					this.settings.verticalSensitivity.GetValue(call);
				if(this.settings.verticalInvert.GetValue(call))
				{
					rotY *= -1;
				}

				// X on player
				target.Rotate(0, rotX, 0);

				//  Y on camera
				Vector3 tmp = this.transform.eulerAngles;
				tmp.y = target.eulerAngles.y;
				tmp.z = 0;
				tmp.x -= rotY;

				target = TransformHelper.GetChild(this.settings.onChild, target);

				this.UpdatePosition(
					target.position + target.TransformDirection(this.settings.offset),
					Quaternion.Euler(tmp));
			}
		}

		protected virtual void OnDisable()
		{
			if(this.settings.lockCursor)
			{
				Cursor.lockState = CursorLockMode.None;
				Cursor.visible = true;
			}
		}


		/*
		============================================================================
		Serialization functions
		============================================================================
		*/
		public virtual void OnBeforeSerialize()
		{
			this.serialize_setting = this.settings.GetData().GetComponentDataFile("settings", false);
		}

		public virtual void OnAfterDeserialize()
		{
			if(this.serialize_setting != null)
			{
				this.settings.SetData(this.serialize_setting.ToDataObject());
				this.serialize_setting = null;
			}
		}
	}
}
