
using UnityEngine;
using GamingIsLove.ORKFramework;
using GamingIsLove.Makinom;
using GamingIsLove.Makinom.Components;

namespace GamingIsLove.ORKFramework.Components
{
	[AddComponentMenu("ORK Framework/Combatant/Equipment Viewer")]
	public class EquipmentViewer : SerializedBehaviour<EquipmentViewer.Settings>
	{
		// ingame
		protected bool displayed = false;

		protected EquipShortcut currentEquipment;

		protected DataCall visibleCall;

		protected SelectedDataHandler currentSelectedData;

		protected bool prefabChangeRegistered = false;

		protected int prefabIndex = -1;

		protected Equipment lastEquip;

		protected int lastLevel = -1;

		protected EquipmentPrefab lastPrefabSettings;

		protected GameObject prefabInstance;

		protected EquipShortcutLinkerComponent linkComponent;

		protected Combatant combatant = null;

		protected bool combatantChecked = false;

		protected bool isPrefabViewPortrait = false;

		protected bool ignoreConditions = false;


		// child link
		protected Transform[] equipChild = new Transform[0];

		protected Transform[] combatantChild = new Transform[0];

		protected Transform setRoot;


		// materials
		protected Renderer usedRenderer;

		protected Material baseMaterial;

		protected Material currentMaterial;

		protected virtual void Start()
		{
			this.FindCombatant();
		}

		public virtual void FindCombatant()
		{
			if(this.combatant == null)
			{
				this.Combatant = ORKComponentHelper.GetCombatant(this.gameObject);
			}
		}

		public virtual bool IsPrefabViewPortrait
		{
			get { return this.isPrefabViewPortrait; }
			set { this.isPrefabViewPortrait = value; }
		}

		public virtual bool IgnoreConditions
		{
			get { return this.ignoreConditions; }
			set
			{
				if(this.ignoreConditions != value)
				{
					this.ignoreConditions = value;
					this.CheckVisible();
				}
			}
		}

		public virtual Transform Root
		{
			get
			{
				if(this.setRoot != null)
				{
					return this.setRoot;
				}
				else if(this.combatant != null &&
					this.combatant.GameObject != null)
				{
					return this.combatant.GameObject.transform;
				}
				else
				{
					return this.transform.root;
				}
			}
			set { this.setRoot = value; }
		}

		public virtual Combatant Combatant
		{
			get { return this.combatant; }
			set
			{
				if(this.combatant != value)
				{
					if(this.combatant != null)
					{
						this.combatant.Equipment.Changed -= this.EquipmentChanged;
					}

					this.combatant = value;

					if(this.combatant != null)
					{
						this.combatantChecked = true;

						if(this.settings.useChildRenderer)
						{
							Transform tmp = this.Root.Find(this.settings.childRenderer);
							if(tmp == null)
							{
								tmp = this.Root;
							}
							this.usedRenderer = tmp.GetComponent<Renderer>();
						}
						else
						{
							this.usedRenderer = this.GetComponent<Renderer>();
						}

						if(this.usedRenderer != null)
						{
							if(this.settings.useMaterialIndex &&
								this.settings.materialIndex < this.usedRenderer.materials.Length)
							{
								this.baseMaterial = this.usedRenderer.materials[this.settings.materialIndex];
							}
							else
							{
								this.baseMaterial = this.usedRenderer.material;
							}
						}

						this.combatant.Equipment.Changed += this.EquipmentChanged;
						this.CheckEquipment();
					}
				}
			}
		}

		protected virtual void OnDestroy()
		{
			if(this.combatant != null)
			{
				this.combatant.Equipment.Changed -= this.EquipmentChanged;
			}
			if(this.currentEquipment != null &&
				!this.isPrefabViewPortrait)
			{
				this.currentEquipment.ViewerPrefabInstance = null;
			}
			this.UnregisterPrefabCheck();
		}

		protected virtual void Update()
		{
			if(!this.combatantChecked)
			{
				this.CheckEquipment();
			}
			this.CheckVisible();
		}

		public virtual void EquipmentChanged(Combatant c)
		{
			if(this.combatant == c)
			{
				this.CheckEquipment();
			}
		}

		public virtual void CheckEquipment()
		{
			if(this.combatant != null &&
				this.settings.equipmentSlot.StoredAsset != null)
			{
				EquipmentSlot equipSlot = this.combatant.Equipment.GetSlot(this.settings.equipmentSlot.StoredAsset.Settings);
				if(equipSlot.Available &&
					equipSlot.DisplayViewer &&
					(equipSlot.Equipped ||
						equipSlot.IsLinked))
				{
					EquipShortcut equip = equipSlot.GetRealSlot(this.combatant).Equipment;

					bool prefabChanged = this.CheckPrefabIndexChanged(equip);
					if(prefabChanged ||
						this.currentEquipment != equip ||
						this.lastEquip != equip.Setting ||
						this.lastLevel != equip.Level)
					{
						if(this.currentEquipment != null &&
							!this.isPrefabViewPortrait)
						{
							this.currentEquipment.ViewerPrefabInstance = null;
						}
						this.UnregisterPrefabCheck();
						this.currentEquipment = equip;
						this.currentSelectedData = this.currentEquipment != null ?
							this.currentEquipment.GetSelectedData() : null;
						this.visibleCall = new DataCall(this.combatant, this.gameObject,
							this.currentEquipment != null && this.currentEquipment.HasVariables ?
								this.currentEquipment.Variables : null, this.currentSelectedData);

						Transform tmpRoot = this.Root;
						if(this.lastPrefabSettings != null)
						{
							this.lastPrefabSettings.UseChildObjects(tmpRoot, false);
							this.lastPrefabSettings = null;
						}
						if(this.prefabInstance)
						{
							if(this.linkComponent != null)
							{
								this.linkComponent.Equipment = null;
								this.linkComponent = null;
							}
							UnityWrapper.Destroy(this.prefabInstance);
							this.prefabInstance = null;
						}
						if(this.usedRenderer != null)
						{
							this.SetMaterial(this.baseMaterial);
							this.currentMaterial = null;
						}

						this.lastEquip = this.currentEquipment.Setting;
						this.lastLevel = this.currentEquipment.Level;

						if(this.currentEquipment.Setting != null)
						{
							EquipmentPrefabSettings prefabSettings = this.currentEquipment.GetPrefabSettings();
							if(prefabSettings.HasConditions)
							{
								this.prefabChangeRegistered = true;
								Maki.Game.Variables.Changed += this.CheckEquipment;
								if(this.currentEquipment.HasVariables)
								{
									this.currentEquipment.Variables.Changed += this.CheckEquipment;
								}
							}

							this.displayed = true;

							this.lastPrefabSettings = prefabSettings.Get(this.prefabIndex);
							Material viewerMaterial = this.lastPrefabSettings.GetViewerMaterial(this.isPrefabViewPortrait);
							if(viewerMaterial != null &&
								this.usedRenderer != null)
							{
								this.currentMaterial = viewerMaterial;
								this.SetMaterial(viewerMaterial);
							}

							this.prefabInstance = this.lastPrefabSettings.CreateViewerPrefab(this.transform, this.isPrefabViewPortrait);
							this.lastPrefabSettings.UseChildObjects(tmpRoot, true);
							if(this.prefabInstance != null)
							{
								if(!this.isPrefabViewPortrait)
								{
									this.currentEquipment.ViewerPrefabInstance = this.prefabInstance;
								}
								this.linkComponent = ComponentHelper.Get<EquipShortcutLinkerComponent>(this.prefabInstance);
								if(this.linkComponent != null)
								{
									this.linkComponent.Equipment = this.currentEquipment;
								}
								if(this.settings.setScale)
								{
									this.prefabInstance.transform.localScale = this.settings.scale;
								}

								if(this.settings.childLink.Length > 0)
								{
									this.equipChild = new Transform[this.settings.childLink.Length];
									this.combatantChild = new Transform[this.settings.childLink.Length];

									for(int i = 0; i < this.settings.childLink.Length; i++)
									{
										this.equipChild[i] = this.prefabInstance.transform.Find(this.settings.childLink[i].equipmentChildObject);
										this.combatantChild[i] = tmpRoot.Find(this.settings.childLink[i].combatantChildObject);
									}
								}

								if(this.isPrefabViewPortrait)
								{
									ORK.UISettings.prefabView.prefab.SetPrefabInstanceComponents(this.prefabInstance);
								}

								this.CheckVisible();
							}
						}
					}
				}
				else if(this.lastEquip != null)
				{
					if(this.currentEquipment != null &&
						!this.isPrefabViewPortrait)
					{
						this.currentEquipment.ViewerPrefabInstance = null;
					}
					if(this.prefabInstance)
					{
						UnityWrapper.Destroy(this.prefabInstance);
					}
					if(this.usedRenderer != null)
					{
						this.SetMaterial(this.baseMaterial);
					}

					this.lastEquip = null;
					this.lastLevel = -1;
				}
			}
			else if(!this.combatantChecked)
			{
				this.combatantChecked = true;
				this.FindCombatant();

				if(this.combatant == null)
				{
					GameObject.Destroy(this);
				}
			}
		}

		protected virtual bool CheckPrefabIndexChanged(EquipShortcut equip)
		{
			if(equip != null)
			{
				EquipmentPrefabSettings prefabSettings = equip.GetPrefabSettings();
				if(prefabSettings != null)
				{
					int tmp = prefabSettings.GetPrefabIndex(equip);
					if(this.prefabIndex != tmp)
					{
						this.prefabIndex = tmp;
						return true;
					}
				}
			}
			return false;
		}

		protected virtual void UnregisterPrefabCheck()
		{
			if(this.prefabChangeRegistered &&
				ORK.Initialized)
			{
				this.prefabChangeRegistered = false;
				Maki.Game.Variables.Changed -= this.CheckEquipment;
				if(this.currentEquipment != null &&
					this.currentEquipment.HasVariables)
				{
					this.currentEquipment.Variables.Changed -= this.CheckEquipment;
				}
			}
		}

		public virtual void CheckVisible()
		{
			if(this.prefabInstance != null || this.currentMaterial != null)
			{
				bool visible = this.ignoreConditions ||
					(this.settings.condition.Check(this.visibleCall) &&
						(!this.settings.onlyCombatantBattle ||
							this.combatant.Battle.InBattle));

				if(!this.displayed && visible)
				{
					if(this.prefabInstance != null)
					{
						this.prefabInstance.SetActive(true);
					}

					if(this.usedRenderer != null && this.currentMaterial != null)
					{
						this.SetMaterial(this.currentMaterial);
					}
				}
				else if(this.displayed && !visible)
				{
					if(this.prefabInstance != null)
					{
						this.prefabInstance.SetActive(false);
					}

					if(this.usedRenderer != null && this.currentMaterial != null)
					{
						this.SetMaterial(this.baseMaterial);
					}
				}

				this.displayed = visible;
			}
		}

		protected virtual void LateUpdate()
		{
			if(this.prefabInstance != null && this.equipChild.Length > 0)
			{
				for(int i = 0; i < this.equipChild.Length; i++)
				{
					if(this.equipChild[i] != null && this.combatantChild[i] != null)
					{
						this.equipChild[i].SetPositionAndRotation(this.combatantChild[i].position, this.combatantChild[i].rotation);
					}
				}
			}
		}

		protected virtual void SetMaterial(Material mat)
		{
			if(this.usedRenderer != null)
			{
				if(this.settings.useMaterialIndex &&
					this.settings.materialIndex < this.usedRenderer.materials.Length)
				{
					Material[] mats = this.usedRenderer.materials;
					mats[this.settings.materialIndex] = mat;
					this.usedRenderer.materials = mats;
				}
				else
				{
					this.usedRenderer.material = mat;
				}
			}
		}

		protected virtual void OnDrawGizmos()
		{
			Gizmos.DrawIcon(transform.position, "/GamingIsLove/ORKFramework/Components/EquipmentViewer Icon.png");
		}


		/*
		============================================================================
		Settings
		============================================================================
		*/
		public class Settings : BaseData
		{
			// viewer settings
			[EditorHelp("Equipment Slot", "Select the equipment slot this viewer will display.")]
			[EditorFoldout("Equipment Viewer Settings", "Define the settings of this equipment viewer.")]
			public AssetSelection<EquipmentSlotAsset> equipmentSlot = new AssetSelection<EquipmentSlotAsset>();

			[EditorHelp("Set Scale", "Set the scale of the spawned equipment prefab.")]
			public bool setScale = false;

			[EditorHelp("Scale", "Define the scale that will be used.")]
			[EditorIndent]
			[EditorCondition("setScale", true)]
			[EditorEndCondition]
			public Vector3 scale = Vector3.one;

			// renderer settings
			[EditorHelp("Use Child Renderer", "Use a render on a child object of the combatant.\n" +
				"If disabled, uses a render on this game object.\n" +
				"The renderer is used by material changes of the equipment.")]
			[EditorSeparator]
			[EditorTitleLabel("Material/Renderer Settings")]
			public bool useChildRenderer = false;

			[EditorHelp("Child Renderer", "Define the path to the game object with the child renderer that should be used.\n" +
				"Paths in game object hierarchies are defined like this: 'path/to/child'")]
			[EditorIndent]
			[EditorWidth(true)]
			[EditorCondition("useChildRenderer", true)]
			[EditorEndCondition]
			public string childRenderer = "";

			[EditorHelp("Use Material Index", "Change the material at a defined material index.")]
			public bool useMaterialIndex = false;

			[EditorHelp("Material Index", "Define the index of the material.")]
			[EditorIndent]
			[EditorEndFoldout]
			[EditorCondition("useMaterialIndex", true)]
			[EditorEndCondition]
			[EditorLimit(0, false)]
			public int materialIndex = 0;


			// display conditions
			[EditorHelp("Only In Battle", "Only display the equipment when the combatant is in battle.")]
			[EditorFoldout("Display Conditions", "Define the conditions to display the equipment.")]
			public bool onlyCombatantBattle = false;

			[EditorLabel("If available, uses the current equipment's variables as local variables and " +
				"the equipment as selected data via the selected key 'action'.")]
			[EditorEndFoldout]
			public GeneralConditionSetting<GameObjectSelection> condition = new GeneralConditionSetting<GameObjectSelection>();


			// child linking
			[EditorFoldout("Child Linking", "Link child objects of the equipment's prefab to child objects of the combatant's game object.\n" +
				"E.g. use this to have sleeves of an equipment move with the combatant's arms.")]
			[EditorEndFoldout]
			[EditorArray("Add Child Link", "Adds a child object link.", "",
				"Remove", "Removes this chilc link.", "",
				isCopy = true, isMove = true,
				foldout = true, foldoutText = new string[] {
					"Child Link", "Define the path to the equipment's child object " +
					"and which child object on the combatant it should link to.", ""
				})]
			public ChildLink[] childLink = new ChildLink[0];

			public Settings()
			{

			}
		}

		public class ChildLink : BaseData
		{
			[EditorHelp("Equipment Child Object", "The path to the equipment prefab's child object.\n" +
				"Paths in game object hierarchies are defined like this: 'path/to/child'")]
			[EditorWidth(true)]
			public string equipmentChildObject = "";

			[EditorHelp("Combatant Child Object (Root)", "The path to the combatant's child object (from the root of the combatant).\n" +
				"Paths in game object hierarchies are defined like this: 'path/to/child'")]
			[EditorWidth(true)]
			public string combatantChildObject = "";

			public ChildLink()
			{

			}
		}
	}
}
