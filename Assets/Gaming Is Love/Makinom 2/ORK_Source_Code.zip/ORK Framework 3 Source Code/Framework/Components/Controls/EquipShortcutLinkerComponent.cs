﻿
using UnityEngine;
using System.Collections.Generic;
using GamingIsLove.Makinom;

namespace GamingIsLove.ORKFramework.Components
{
	public class EquipShortcutLinkerComponent : MonoBehaviour
	{
		protected EquipShortcut equipment;

		public EquipShortcut Equipment
		{
			get { return this.equipment; }
			set { this.equipment = value; }
		}
	}
}
