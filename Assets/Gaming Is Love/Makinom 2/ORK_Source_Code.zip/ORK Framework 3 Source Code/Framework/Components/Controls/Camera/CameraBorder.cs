
using UnityEngine;
using GamingIsLove.ORKFramework;
using System.Collections.Generic;
using GamingIsLove.Makinom;
using GamingIsLove.Makinom.Components;

namespace GamingIsLove.ORKFramework.Components
{
	[AddComponentMenu("ORK Framework/Camera Control/Camera Border")]
	public class CameraBorder : SerializedBehaviour<CameraBorder.Settings>
	{
		// collider
		protected Collider colliderComponent;

		protected Collider2D collider2DComponent;

		protected virtual void Start()
		{
			this.colliderComponent = this.GetComponent<Collider>();
			this.collider2DComponent = this.GetComponent<Collider2D>();
		}

		protected virtual void OnEnable()
		{
			TopDownBorderCamera.CameraBorders.Add(this);
		}

		protected virtual void OnDisable()
		{
			TopDownBorderCamera.CameraBorders.Remove(this);
		}

		public virtual float DistanceToCameraTarget(Vector3 position)
		{
			if(this.colliderComponent != null)
			{
				return Vector3.Distance(position,
					this.colliderComponent.ClosestPointOnBounds(position));
			}
			else if(this.collider2DComponent != null)
			{
				return Vector3.Distance(position,
					this.collider2DComponent.bounds.ClosestPoint(position));
			}
			return Mathf.Infinity;
		}

		public virtual void UpdatePosition(Camera camera, ref Vector3 position, Vector4 padding, HorizontalPlaneType horizontalPlane)
		{
			if(this.colliderComponent != null ||
				this.collider2DComponent != null)
			{
				Bounds bounds;
				if(this.colliderComponent != null)
				{
					bounds = this.colliderComponent.bounds;
				}
				else if(this.collider2DComponent != null)
				{
					bounds = this.collider2DComponent.bounds;
				}
				else
				{
					bounds = new Bounds();
				}
				if(this.settings.setPadding)
				{
					padding = this.settings.positionPadding;
				}

				// clamp to border
				// edges
				if(camera != null)
				{
					Vector3 center = camera.ViewportToWorldPoint(new Vector3(0.5f, 0.5f, 0));
					Vector3 change = center - position;
					center -= change;

					Vector3 left = camera.ViewportToWorldPoint(new Vector3(0, 0.5f, 0)) - change;
					Vector3 right = camera.ViewportToWorldPoint(new Vector3(1, 0.5f, 0)) - change;
					Vector3 top = camera.ViewportToWorldPoint(new Vector3(0.5f, 1, 0)) - change;
					Vector3 bottom = camera.ViewportToWorldPoint(new Vector3(0.5f, 0, 0)) - change;

					// x-axis
					if(left.x < bounds.min.x + padding.x)
					{
						position.x = bounds.min.x + padding.x + Mathf.Abs(left.x - center.x);
					}
					else if(right.x > bounds.max.x - padding.z)
					{
						position.x = bounds.max.x - padding.z - Mathf.Abs(right.x - center.x);
					}
					if(HorizontalPlaneType.XZ == horizontalPlane)
					{
						// z-axis
						if(top.z > bounds.max.z - padding.y)
						{
							position.z = bounds.max.z - padding.y - Mathf.Abs(top.z - center.z);
						}
						else if(bottom.z < bounds.min.z + padding.w)
						{
							position.z = bounds.min.z + padding.w + Mathf.Abs(bottom.z - center.z);
						}
					}
					else if(HorizontalPlaneType.XY == horizontalPlane)
					{
						// y-axis
						if(top.y > bounds.max.y - padding.y)
						{
							position.y = bounds.max.y - padding.y - Mathf.Abs(top.y - center.y);
						}
						else if(bottom.y < bounds.min.y + padding.w)
						{
							position.y = bounds.min.y + padding.w + Mathf.Abs(bottom.y - center.y);
						}
					}
				}
				// center
				else
				{
					// x-axis
					if(position.x < bounds.min.x + padding.x)
					{
						position.x = bounds.min.x + padding.x;
					}
					else if(position.x > bounds.max.x - padding.z)
					{
						position.x = bounds.max.x - padding.z;
					}
					if(HorizontalPlaneType.XZ == horizontalPlane)
					{
						// z-axis
						if(position.z > bounds.max.z - padding.y)
						{
							position.z = bounds.max.z - padding.y;
						}
						else if(position.z < bounds.min.z + padding.w)
						{
							position.z = bounds.min.z + padding.w;
						}
					}
					else if(HorizontalPlaneType.XY == horizontalPlane)
					{
						// y-axis
						if(position.y > bounds.max.y - padding.y)
						{
							position.y = bounds.max.y - padding.y;
						}
						else if(position.y < bounds.min.y + padding.w)
						{
							position.y = bounds.min.y + padding.w;
						}
					}
				}
			}
		}

		public virtual void UpdateCameraHeight(ref Vector3 position, HorizontalPlaneType horizontalPlane, bool useZooming)
		{
			if(this.colliderComponent != null && this.settings.useBorderHeight)
			{
				if(HorizontalPlaneType.XZ == horizontalPlane)
				{
					if(!useZooming || position.y > this.colliderComponent.bounds.max.y)
					{
						position.y = this.colliderComponent.bounds.max.y;
					}
				}
				else if(HorizontalPlaneType.XY == horizontalPlane)
				{
					if(!useZooming || position.z < this.colliderComponent.bounds.min.z)
					{
						position.z = this.colliderComponent.bounds.min.z;
					}
				}
			}
		}


		/*
		============================================================================
		Gizmo functions
		============================================================================
		*/
		protected virtual void OnDrawGizmos()
		{
			Gizmos.DrawIcon(transform.position, "/GamingIsLove/ORKFramework/Components/CameraBorder Icon.png");
		}


		/*
		============================================================================
		Settings
		============================================================================
		*/
		public class Settings : BaseData
		{
			// set height to upper border
			[EditorHelp("Use Border Height", "Use the camera border's collider to set the camera height.")]
			public bool useBorderHeight = false;


			// set start rotation
			[EditorHelp("Set Rotation", "Set the rotation of the camera.")]
			[EditorSeparator]
			public bool setRotation = false;

			[EditorHelp("Rotation", "The rotation that will be used.")]
			[EditorIndent]
			[EditorCondition("setRotation", true)]
			public float rotation = 0;

			[EditorHelp("Block Rotation Input", "Block the rotation input of the 'Top Down Border' camera control.")]
			[EditorElseCondition]
			[EditorEndCondition]
			[EditorDefaultValue(false)]
			public bool blockRotationInput = false;

			[EditorHelp("Block Panning", "Block panning of the 'Top Down Border' camera control.")]
			public bool blockPanning = false;

			[EditorHelp("Block Zooming", "Block zooming of the 'Top Down Border' camera control.")]
			public bool blockZooming = false;


			// set padding
			[EditorHelp("Set Padding", "Set the padding of the 'Top Down Border' camera control.")]
			[EditorSeparator]
			public bool setPadding = false;

			[EditorHelp("Padding", "Define the padding that will be used.")]
			[EditorCondition("setPadding", true)]
			[EditorEndCondition]
			public Vector4 positionPadding = new Vector4(0, 0, 0, 0);

			public Settings()
			{

			}
		}
	}
}
