﻿
using UnityEngine;
using System.Collections.Generic;
using GamingIsLove.Makinom;
using GamingIsLove.Makinom.Components;

namespace GamingIsLove.ORKFramework.Components
{
	[AddComponentMenu("")]
	public class BasePlayerControl : MonoBehaviour, IMoveToInteraction
	{
		protected virtual void OnDestroy()
		{
			Maki.Control.RemovePlayerControl(this);
		}

		public virtual void MoveToInteractionStarted(IInteractionBehaviour interaction)
		{

		}
	}
}
