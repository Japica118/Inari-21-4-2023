﻿
using UnityEngine;
using GamingIsLove.Makinom;
using System.Collections.Generic;

namespace GamingIsLove.ORKFramework.Components
{
	public class RaycastColliderZone : BaseColliderZone, ISerializationCallbackReceiver
	{
		[System.NonSerialized]
		public Settings settings = new Settings();

		[SerializeField]
		[HideInInspector]
		protected ComponentDataFile serialize_setting;

		public bool IsHit(GameObject original)
		{
			if(this.settings.usedByRaycasts)
			{
				return this.settings.inChildObjects ? true : this.gameObject == original;
			}
			return false;
		}

		public static bool CheckHit<T>(GameObject gameObject) where T : RaycastColliderZone
		{
			T zone = gameObject.GetComponentInParent<T>();
			return zone != null && zone.IsHit(gameObject);
		}


		/*
		============================================================================
		Serialization functions
		============================================================================
		*/
		public virtual void OnBeforeSerialize()
		{
			this.serialize_setting = this.settings.GetData().GetComponentDataFile("settings", false);
		}

		public virtual void OnAfterDeserialize()
		{
			if(this.serialize_setting != null)
			{
				this.settings.SetData(this.serialize_setting.ToDataObject());
				this.serialize_setting = null;
			}
		}


		/*
		============================================================================
		Settings class
		============================================================================
		*/
		public class Settings : BaseData
		{
			[EditorLabel("Registers positions within colliders attached to this game object as positions within the zone/area.\n" +
				"Optionally also use raycasts hitting this game object (or child objects) as positions within the zone/area.")]
			[EditorHelp("Used By Raycasts", "If the game object was hit by the raycast it'll be registered as a position within the zone/area.")]
			public bool usedByRaycasts = true;

			[EditorHelp("In Child Objects", "Child objects being hit by the raycast will also be registered as a position within the zone/area.")]
			[EditorCondition("usedByRaycasts", true)]
			[EditorEndCondition]
			public bool inChildObjects = true;

			public Settings()
			{

			}
		}
	}
}
