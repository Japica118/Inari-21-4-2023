﻿
using UnityEngine;
using GamingIsLove.ORKFramework;
using System.Collections.Generic;
using GamingIsLove.Makinom;
using GamingIsLove.Makinom.Components;

namespace GamingIsLove.ORKFramework.Components
{
	[AddComponentMenu("")]
	public class BattleGridCellComponent : SerializedBehaviour<BattleGridCellComponent.Settings>
	{
		// grid info
		public BattleGridComponent parentGrid = null;

		public BattleGridCellComponent[] connections = null;

		public int row = 0;

		public int column = 0;


		// in-game
		protected BattleGridCellType cellTypeSettings;

		protected BattleGridCellType cellTypeOverride;

		[SerializeField]
		protected GameObject prefabInstance;

		protected CubeCoord cubeCoord;

		protected bool isPositionOffset = false;

		protected Vector3 originalPosition = Vector3.zero;

		protected Dictionary<string, TemporaryGridCellEvent> temporaryCellEvents;

		protected ObjectVariablesComponent objectVariables;


		// occupant
		protected Combatant combatant;

		protected bool isSizeCombatant = false;

		protected Combatant markedForCombatant;

		protected Combatant markedForAI;

		protected List<Combatant> guestCombatants;


		// highlighting
		protected GridCellHighlight currentHighlight = GridCellHighlight.None;

		protected GridCellHighlight priorityHighlight = GridCellHighlight.None;

		protected List<GridCellHighlight> highlightStack;

		protected Dictionary<GridCellHighlight, GameObject> highlight;

		public virtual void Init(BattleGridComponent parentGrid, int row, int column)
		{
			this.parentGrid = parentGrid;
			this.row = row;
			this.column = column;
		}

		protected virtual void Start()
		{
			if(this.CellTypeSingle != null &&
				this.CellTypeSingle.useObjectVariables)
			{
				this.CellTypeSingle.objectVariables.AddComponent(this.gameObject);
			}
			this.objectVariables = this.GetComponent<ObjectVariablesComponent>();
		}

		public virtual ObjectVariablesComponent ObjectVariables
		{
			get { return this.objectVariables; }
		}

		public virtual BattleGridCellType CellType
		{
			get
			{
				if(this.cellTypeSettings == null &&
					ORK.Initialized)
				{
					if(this.isPositionOffset)
					{
						this.transform.position = this.originalPosition;
						this.isPositionOffset = false;
					}
					if(Application.isEditor &&
						!Application.isPlaying)
					{
						this.cellTypeSettings = this.settings.cellType.StoredAsset != null ?
							this.settings.cellType.StoredAsset.Settings :
							null;
					}
					else
					{
						if(this.cellTypeOverride != null)
						{
							this.cellTypeSettings = this.cellTypeOverride;
						}
						else
						{
							this.cellTypeSettings = this.settings.cellType.StoredAsset != null ?
								this.settings.cellType.StoredAsset.Settings.GetCellType() :
								null;
						}
						if(this.cellTypeSettings.singleCellType.usePositionOffset)
						{
							this.isPositionOffset = true;
							this.originalPosition = this.transform.position;
							this.transform.position = this.cellTypeSettings.singleCellType.localPosition.GetOffsetPosition(
								this.transform, this.cellTypeSettings.singleCellType.positionOffset);
						}
					}
				}
				return this.cellTypeSettings;
			}
		}

		public virtual BattleGridCellType CellTypeOverride
		{
			get
			{
				return this.cellTypeOverride;
			}
			set
			{
				if(this.cellTypeOverride != value)
				{
					this.cellTypeOverride = value;
					this.cellTypeSettings = null;
					if(this.CellType == null)
					{
						this.cellTypeOverride = null;
					}
					if(this.prefabInstance != null)
					{
						this.DestroyPrefab();
						this.prefabInstance = null;
						this.ShowPrefab();
					}
					this.parentGrid.MarkFireChanged();
				}
			}
		}

		public virtual BattleGridCellTypeSingle CellTypeSingle
		{
			get
			{
				return this.CellType.singleCellType;
			}
		}

		public virtual bool IsPositionOffset
		{
			get { return this.isPositionOffset; }
		}

		public virtual float SpawnRotation
		{
			get { return this.transform.eulerAngles.y + this.settings.spawnRotation; }
		}

		public virtual void ClearSettings()
		{
			this.cellTypeSettings = null;
		}

		public virtual CubeCoord CubeCoord
		{
			get
			{
				if(this.cubeCoord == null)
				{
					this.cubeCoord = CubeCoord.FromOffset(this.row, this.column);
				}
				return this.cubeCoord;
			}
		}

		public virtual bool IsBlocked
		{
			get
			{
				if(this.settings.ownBlockedSettings)
				{
					return this.settings.blocked;
				}
				return this.CellTypeSingle.blocked;
			}
		}

		public virtual bool IsPassable
		{
			get
			{
				if(this.settings.ownBlockedSettings)
				{
					return !this.settings.blocked || this.settings.passable;
				}
				return !this.CellTypeSingle.blocked || this.CellTypeSingle.passable;
			}
		}

		public virtual bool BlockDiagonalMove
		{
			get
			{
				if(this.settings.ownBlockedSettings)
				{
					return this.settings.blocked && this.settings.blockDiagonalMove;
				}
				return this.CellTypeSingle.blocked && this.CellTypeSingle.blockDiagonalMove;
			}
		}


		/*
		============================================================================
		Connection functions
		============================================================================
		*/
		public virtual void InitConnections()
		{
			if(ORK.BattleGridSettings.IsSquare)
			{
				this.InitConnectionsSquare();
			}
			else
			{
				this.InitConnectionsHexagonal();
			}
		}

		public virtual void InitConnectionsSquare()
		{
			this.parentGrid.CreateLookup();
			this.connections = new BattleGridCellComponent[BattleGridHelper.SquareDirectionsDiagonal.Length];

			if(!this.parentGrid.settings.noBlockedConnections ||
				!this.IsBlocked)
			{
				CubeCoord coord = new CubeCoord();
				for(int i = 0; i < this.connections.Length; i++)
				{
					coord.SetAdd(this.CubeCoord, BattleGridHelper.SquareDirectionsDiagonal[i]);
					this.connections[i] = this.parentGrid.GetCell(coord);
					if(this.parentGrid.settings.noBlockedConnections &&
						this.connections[i] != null &&
						this.connections[i].IsBlocked)
					{
						this.connections[i] = null;
					}
				}
			}
		}

		public virtual void InitConnectionsHexagonal()
		{
			this.parentGrid.CreateLookup();
			this.connections = new BattleGridCellComponent[BattleGridHelper.HexagonalDirections.Length];

			if(!this.parentGrid.settings.noBlockedConnections ||
				!this.IsBlocked)
			{
				CubeCoord coord = new CubeCoord();
				for(int i = 0; i < this.connections.Length; i++)
				{
					coord.SetAdd(this.CubeCoord, BattleGridHelper.HexagonalDirections[i]);
					this.connections[i] = this.parentGrid.GetCell(coord);
					if(this.parentGrid.settings.noBlockedConnections &&
						this.connections[i] != null &&
						this.connections[i].IsBlocked)
					{
						this.connections[i] = null;
					}
				}
			}
		}

		public virtual void RemoveBlockedConnections()
		{
			if(this.connections != null)
			{
				if(this.IsBlocked)
				{
					for(int i = 0; i < this.connections.Length; i++)
					{
						this.connections[i] = null;
					}
				}
				else
				{
					for(int i = 0; i < this.connections.Length; i++)
					{
						if(this.connections[i] != null &&
							this.connections[i].IsBlocked)
						{
							this.connections[i] = null;
						}
					}
				}
			}
		}


		/*
		============================================================================
		Combatant functions
		============================================================================
		*/
		public virtual bool CanDeploy(Combatant combatant)
		{
			return !this.IsBlocked &&
				this.combatant == null &&
				(this.settings.ownDeployment ?
					this.settings.deployment.CanDeploy(combatant) :
					this.CellTypeSingle.deployment.CanDeploy(combatant)) &&
				combatant.Grid.CanPlaceOn(this, -1);
		}

		public virtual bool IsDeployment
		{
			get
			{
				return this.settings.ownDeployment ?
					GridDeploymentType.None != this.settings.deployment.type :
					GridDeploymentType.None != this.CellTypeSingle.deployment.type;
			}
		}

		public virtual GridDeploymentCell Deployment
		{
			get { return this.settings.ownDeployment ? this.settings.deployment : this.CellTypeSingle.deployment; }
		}

		public virtual bool IsEmpty
		{
			get
			{
				return this.combatant == null &&
					this.markedForCombatant == null &&
					!this.HasGuests;
			}
		}

		public Combatant Combatant
		{
			get { return this.combatant; }
		}

		public virtual void SetCombatant(Combatant value, bool isSizeCombatant)
		{
			if(this.combatant != value ||
				this.isSizeCombatant != isSizeCombatant)
			{
				// reset current combatant's grid cell
				if(this.combatant != null &&
					!this.isSizeCombatant &&
					this.combatant.Grid.Cell == this)
				{
					Combatant tmpCombatant = this.combatant;
					this.combatant = null;
					tmpCombatant.Grid.Cell = null;
				}

				this.combatant = value;
				this.isSizeCombatant = isSizeCombatant;
				this.MarkedForAI = null;
				if(this.markedForCombatant != null)
				{
					this.markedForCombatant = null;
					if(ORK.BattleGridHighlights.markedCellHighlight.enable)
					{
						BattleGridHelper.StopHighlight(this, GridCellHighlight.MarkedCell);
					}
				}
				if(this.HasGuests)
				{
					this.guestCombatants.Remove(this.combatant);
				}

				// set new combatant's grid cell
				if(this.combatant != null &&
					!this.isSizeCombatant)
				{
					this.combatant.Grid.Cell = this;
				}
				this.parentGrid.MarkFireChanged();
			}
		}

		public virtual Combatant MarkedForCombatant
		{
			get { return this.markedForCombatant; }
			set
			{
				if(this.markedForCombatant != value)
				{
					this.markedForCombatant = value;
					this.parentGrid.MarkFireChanged();

					if(ORK.BattleGridHighlights.markedCellHighlight.enable)
					{
						if(this.markedForCombatant != null)
						{
							BattleGridHelper.Highlight(this, GridCellHighlight.MarkedCell);
						}
						else
						{
							BattleGridHelper.StopHighlight(this, GridCellHighlight.MarkedCell);
						}
					}
				}
			}
		}

		public virtual Combatant MarkedForAI
		{
			get { return this.markedForAI; }
			set
			{
				if(this.markedForAI != value)
				{
					// reset current combatant's grid cell
					if(this.markedForAI != null &&
						this.markedForAI.Grid.CellMarkedForAI == this)
					{
						Combatant tmpCombatant = this.markedForAI;
						this.markedForAI = null;
						tmpCombatant.Grid.CellMarkedForAI = null;
					}

					this.markedForAI = value;

					// set new combatant's grid cell
					if(this.markedForAI != null)
					{
						this.markedForAI.Grid.CellMarkedForAI = this;
					}
					this.parentGrid.MarkFireChanged();
				}
			}
		}

		public virtual bool HasGuests
		{
			get
			{
				return this.guestCombatants != null &&
					this.guestCombatants.Count > 0;
			}
		}

		public virtual List<Combatant> GetGuests()
		{
			return this.guestCombatants;
		}

		public virtual bool IsGuest(Combatant combatant)
		{
			return this.HasGuests &&
				this.guestCombatants.Contains(combatant);
		}

		public virtual void AddGuest(Combatant combatant)
		{
			if(this.guestCombatants == null)
			{
				this.guestCombatants = new List<Combatant>();
			}
			if(!this.guestCombatants.Contains(combatant))
			{
				this.guestCombatants.Add(combatant);
				combatant.Grid.AddGuestCell(this);
				this.parentGrid.MarkFireChanged();
			}
		}

		public virtual void RemoveGuest(Combatant combatant)
		{
			if(this.guestCombatants != null &&
				this.guestCombatants.Contains(combatant))
			{
				this.guestCombatants.Remove(combatant);
				combatant.Grid.RemoveGuestCell(this);
				this.parentGrid.MarkFireChanged();
			}
		}

		public virtual void GetCombatants(ref List<Combatant> list, CheckCombatant check)
		{
			if(this.combatant != null &&
				!list.Contains(this.combatant) &&
				(check == null || check(this.combatant)))
			{
				list.Add(this.combatant);
			}
			if(this.HasGuests)
			{
				for(int i = 0; i < this.guestCombatants.Count; i++)
				{
					if(!list.Contains(this.guestCombatants[i]) &&
						(check == null || check(this.guestCombatants[i])))
					{
						list.Add(this.guestCombatants[i]);
					}
				}
			}
		}

		public virtual bool CheckOccupants(CheckCombatant check)
		{
			if(check != null)
			{
				if(check(this.combatant))
				{
					return true;
				}
				else if(this.HasGuests)
				{
					for(int i = 0; i < this.guestCombatants.Count; i++)
					{
						if(check(this.guestCombatants[i]))
						{
							return true;
						}
					}
				}
			}
			return false;
		}

		public virtual void SwapCombatants(BattleGridCellComponent other, bool placeAtCell)
		{
			if(!this.IsBlocked &&
				other != null &&
				!other.IsBlocked)
			{
				if(this.combatant != null)
				{
					this.combatant.Grid.StopHighlightCells(
						ORK.BattleGridHighlights.GetCombatantCellHighlight(this.combatant));
				}

				Combatant tmpCombatant = this.combatant;
				this.combatant = null;
				this.SetCombatant(other.combatant, false);

				other.combatant = null;
				other.SetCombatant(tmpCombatant, false);

				if(placeAtCell)
				{
					if(this.combatant != null)
					{
						this.combatant.GameObject.transform.position = this.transform.position;
					}
					if(other.combatant != null)
					{
						other.combatant.GameObject.transform.position = other.transform.position;
					}
				}
			}
		}

		public virtual void RemoveCombatant(Combatant combatant)
		{
			if(combatant != null)
			{
				if(this.combatant == combatant)
				{
					this.combatant.Grid.StopHighlightCells(
						ORK.BattleGridHighlights.GetCombatantCellHighlight(this.combatant));
					this.combatant = null;
					if(!this.isSizeCombatant)
					{
						combatant.Grid.Cell = null;
					}
				}
				if(this.markedForCombatant == combatant)
				{
					this.markedForCombatant = null;
					if(ORK.BattleGridHighlights.markedCellHighlight.enable)
					{
						BattleGridHelper.StopHighlight(this, GridCellHighlight.MarkedCell);
					}
				}
				if(this.guestCombatants != null &&
					this.guestCombatants.Contains(combatant))
				{
					this.guestCombatants.Remove(combatant);
					combatant.Grid.RemoveGuestCell(this);
				}
				this.parentGrid.MarkFireChanged();
			}
		}


		/*
		============================================================================
		Prefab functions
		============================================================================
		*/
		public virtual GameObject PrefabInstance
		{
			get { return this.prefabInstance; }
		}

		public virtual GameObject HighlightPrefabInstance
		{
			get
			{
				GameObject prefab;
				if(this.highlight != null &&
					this.highlight.TryGetValue(this.currentHighlight, out prefab))
				{
					return prefab;
				}
				return null;
			}
			set
			{
				if(this.highlight == null)
				{
					this.highlight = new Dictionary<GridCellHighlight, GameObject>();
				}
				if(this.highlight.ContainsKey(this.currentHighlight))
				{
					this.highlight[this.currentHighlight] = value;
				}
				else
				{
					this.highlight.Add(this.currentHighlight, value);
				}
			}
		}

		public virtual void ShowPrefab()
		{
			if(this.prefabInstance == null &&
				this.CellTypeSingle != null)
			{
				this.prefabInstance = this.CellTypeSingle.CreatePrefabInstance(this);
			}
		}

		public virtual void EditorShowPrefab()
		{
			if(this.prefabInstance == null &&
				this.CellType != null)
			{
				this.prefabInstance = this.CellType.CreatePrefabInstance(this, true);
			}
		}

		public virtual void HidePrefab()
		{
			if(this.prefabInstance != null)
			{
				this.prefabInstance.SetActive(false);
			}
			if(this.highlight != null)
			{
				foreach(KeyValuePair<GridCellHighlight, GameObject> pair in this.highlight)
				{
					if(pair.Value != null)
					{
						pair.Value.SetActive(false);
					}
				}
			}
		}

		public virtual void DestroyPrefab()
		{
			if(this.prefabInstance != null)
			{
				UnityWrapper.Destroy(this.prefabInstance);
			}
			if(this.highlight != null)
			{
				foreach(KeyValuePair<GridCellHighlight, GameObject> pair in this.highlight)
				{
					if(pair.Value != null)
					{
						UnityWrapper.Destroy(pair.Value);
					}
				}
			}
		}


		/*
		============================================================================
		Highlight functions
		============================================================================
		*/
		public virtual void HideHighlights(bool hiddenByUI, bool systemHideState)
		{
			if(hiddenByUI || systemHideState ?
				GridCellHighlight.None != this.currentHighlight :
				(this.highlightStack != null && this.highlightStack.Count > 0))
			{
				if(systemHideState ||
					!hiddenByUI ||
					ORK.BattleGridHighlights.IsHidden(this.currentHighlight))
				{
					this.DoStopHighlight(this.currentHighlight);
					this.currentHighlight = this.GetLastHighlightType();
					if(GridCellHighlight.None != this.currentHighlight)
					{
						this.DoHighlight(this.currentHighlight);
					}
				}
			}
		}

		public virtual void Highlight(GridCellHighlight highlightType)
		{
			if(this.currentHighlight != highlightType)
			{
				if(this.highlightStack == null)
				{
					this.highlightStack = new List<GridCellHighlight>();
				}
				if(GridCellHighlight.None != this.currentHighlight)
				{
					this.DoStopHighlight(this.currentHighlight);
				}

				// set priority highlight
				if(GridCellHighlight.SelectingPlayer == highlightType ||
					GridCellHighlight.SelectingAlly == highlightType ||
					GridCellHighlight.SelectingEnemy == highlightType ||
					GridCellHighlight.MarkedCell == highlightType ||
					// player selection
					GridCellHighlight.PlacementSelectionPlayer == highlightType ||
					GridCellHighlight.MoveSelectionPlayer == highlightType ||
					GridCellHighlight.OrientationSelectionPlayer == highlightType ||
					GridCellHighlight.TargetCellSelectionPlayer == highlightType ||
					GridCellHighlight.ExamineSelectionPlayer == highlightType ||
					GridCellHighlight.SelectedTargetPlayer == highlightType ||
					// ally selection
					GridCellHighlight.PlacementSelectionAlly == highlightType ||
					GridCellHighlight.MoveSelectionAlly == highlightType ||
					GridCellHighlight.OrientationSelectionAlly == highlightType ||
					GridCellHighlight.TargetCellSelectionAlly == highlightType ||
					GridCellHighlight.ExamineSelectionAlly == highlightType ||
					GridCellHighlight.SelectedTargetAlly == highlightType ||
					// enemy selection
					GridCellHighlight.PlacementSelectionEnemy == highlightType ||
					GridCellHighlight.MoveSelectionEnemy == highlightType ||
					GridCellHighlight.OrientationSelectionEnemy == highlightType ||
					GridCellHighlight.TargetCellSelectionEnemy == highlightType ||
					GridCellHighlight.ExamineSelectionEnemy == highlightType ||
					GridCellHighlight.SelectedTargetEnemy == highlightType)
				{
					this.priorityHighlight = highlightType;
				}

				if(this.highlightStack.Count > 0 &&
					(GridCellHighlight.CellPlayer == highlightType ||
						GridCellHighlight.CellAlly == highlightType ||
						GridCellHighlight.CellEnemy == highlightType))
				{
					this.highlightStack.Insert(0, highlightType);
				}
				else
				{
					this.highlightStack.Add(highlightType);
				}

				this.PriorityHighlight();
				this.currentHighlight = this.GetLastHighlightType();
				if(GridCellHighlight.None != this.currentHighlight)
				{
					this.DoHighlight(this.currentHighlight);
				}
			}
		}

		public virtual void StopHighlight(GridCellHighlight highlightType)
		{
			// remove priority highlight
			if(this.priorityHighlight == highlightType)
			{
				this.priorityHighlight = GridCellHighlight.None;
			}

			if(this.currentHighlight == highlightType)
			{
				this.DoStopHighlight(this.currentHighlight);

				if(this.highlightStack != null &&
					this.highlightStack.Count > 0)
				{
					this.RemoveHighlightType(highlightType);
					this.currentHighlight = this.GetLastHighlightType();
					if(GridCellHighlight.None != this.currentHighlight)
					{
						this.DoHighlight(this.currentHighlight);
					}
				}
				else
				{
					this.currentHighlight = GridCellHighlight.None;
				}
			}
			else
			{
				this.RemoveHighlightType(highlightType);
			}
		}

		protected virtual GridCellHighlight GetLastHighlightType()
		{
			if(!ORK.BattleGridHighlights.HideGridHighlights &&
				this.highlightStack != null &&
				this.highlightStack.Count > 0)
			{
				if(this.parentGrid.HighlightsHiddenByUI)
				{
					for(int i = this.highlightStack.Count - 1; i >= 0; i--)
					{
						if(!ORK.BattleGridHighlights.IsHidden(this.highlightStack[i]))
						{
							return this.highlightStack[i];
						}
					}
				}
				else
				{
					return this.highlightStack[this.highlightStack.Count - 1];
				}
			}
			return GridCellHighlight.None;
		}

		protected virtual void PriorityHighlight()
		{
			if(ORK.BattleGridHighlights.selectingPriority &&
				this.highlightStack != null &&
				this.highlightStack.Count > 0 &&
				GridCellHighlight.None != this.priorityHighlight)
			{
				this.RemoveHighlightType(this.priorityHighlight);
				this.highlightStack.Add(this.priorityHighlight);
			}
		}

		protected virtual void RemoveHighlightType(GridCellHighlight highlightType)
		{
			if(this.highlightStack != null &&
				this.highlightStack.Contains(highlightType))
			{
				for(int i = this.highlightStack.Count - 1; i >= 0; i--)
				{
					if(this.highlightStack[i] == highlightType)
					{
						this.highlightStack.RemoveAt(i);
					}
				}
			}
		}

		public virtual void StopAllHighlights()
		{
			if(GridCellHighlight.None != this.currentHighlight)
			{
				this.DoStopHighlight(this.currentHighlight);

				if(this.highlightStack != null &&
					this.highlightStack.Count > 0)
				{
					this.highlightStack.Clear();
				}
				this.currentHighlight = GridCellHighlight.None;
			}
		}

		protected virtual void DoHighlight(GridCellHighlight highlightType)
		{
			GridHighlightSetting setting = ORK.BattleGridHighlights.GetHighlight(highlightType);
			if(setting != null)
			{
				setting.Highlight(this);
			}
		}

		protected virtual void DoStopHighlight(GridCellHighlight highlightType)
		{
			GridHighlightSetting setting = ORK.BattleGridHighlights.GetHighlight(highlightType);
			if(setting != null)
			{
				setting.StopHighlight(this);
			}
		}


		/*
		============================================================================
		Cell event functions
		============================================================================
		*/
		public virtual void GetCellEvents(ref List<GridCellEventCall> cellEvents, GridCellEventStartType startType)
		{
			// cell type events
			if(this.CellTypeSingle != null)
			{
				for(int i = 0; i < this.CellTypeSingle.cellEvent.Length; i++)
				{
					if(this.CellTypeSingle.cellEvent[i].startType == startType ||
						this.CellTypeSingle.cellEvent[i].startType == GridCellEventStartType.Any ||
						GridCellEventStartType.Any == startType)
					{
						cellEvents.Add(new GridCellEventCall(this, this.CellTypeSingle.cellEvent[i]));
					}
				}
			}
			// cell events
			for(int i = 0; i < this.settings.cellEvent.Length; i++)
			{
				if(this.settings.cellEvent[i].startType == startType ||
					this.settings.cellEvent[i].startType == GridCellEventStartType.Any ||
					GridCellEventStartType.Any == startType)
				{
					cellEvents.Add(new GridCellEventCall(this, this.settings.cellEvent[i]));
				}
			}
			// temporary cell events
			if(this.temporaryCellEvents != null)
			{
				foreach(KeyValuePair<string, TemporaryGridCellEvent> pair in this.temporaryCellEvents)
				{
					if(pair.Value.startType == startType ||
						pair.Value.startType == GridCellEventStartType.Any ||
						GridCellEventStartType.Any == startType)
					{
						cellEvents.Add(new GridCellEventCall(this, pair.Value));
					}
				}
			}
		}

		public virtual bool HasEvents
		{
			get
			{
				return this.settings.cellEvent.Length > 0 ||
					(this.CellTypeSingle != null &&
						this.CellTypeSingle.cellEvent.Length > 0) ||
					(this.temporaryCellEvents != null &&
						this.temporaryCellEvents.Count > 0);
			}
		}

		public virtual void AddTemporaryCellEvent(TemporaryGridCellEvent cellEvent)
		{
			if(this.temporaryCellEvents == null)
			{
				this.temporaryCellEvents = new Dictionary<string, TemporaryGridCellEvent>();
			}
			TemporaryGridCellEvent currentEvent;
			if(this.temporaryCellEvents.TryGetValue(cellEvent.EventKey, out currentEvent))
			{
				currentEvent.Clear();
				this.temporaryCellEvents[cellEvent.EventKey] = cellEvent;
			}
			else
			{
				this.temporaryCellEvents.Add(cellEvent.EventKey, cellEvent);
			}
			cellEvent.AddedTo(this);
		}

		public virtual bool HasTemporaryCellEvent(string eventKey)
		{
			return this.temporaryCellEvents != null &&
				this.temporaryCellEvents.ContainsKey(eventKey);
		}

		public virtual bool HasAnyTemporaryCellEvents()
		{
			return this.temporaryCellEvents != null &&
				this.temporaryCellEvents.Count > 0;
		}

		public virtual void RemoveTemporaryCellEvent(string eventKey)
		{
			TemporaryGridCellEvent currentEvent;
			if(this.temporaryCellEvents.TryGetValue(eventKey, out currentEvent))
			{
				currentEvent.Clear();
				this.temporaryCellEvents.Remove(eventKey);
			}
		}

		public virtual void ClearTemporaryCellEvents()
		{
			if(this.temporaryCellEvents != null)
			{
				foreach(KeyValuePair<string, TemporaryGridCellEvent> pair in this.temporaryCellEvents)
				{
					pair.Value.Clear();
				}
				this.temporaryCellEvents.Clear();
			}
		}


		/*
		============================================================================
		Settings class
		============================================================================
		*/
		public class Settings : BaseData
		{
			[EditorFoldout("Grid Cell Settings", "The settings of this grid cell.", "")]
			[EditorHelp("Grid Cell Type", "Select the grid cell type of this cell.")]
			public AssetSelection<BattleGridCellTypeAsset> cellType = new AssetSelection<BattleGridCellTypeAsset>();


			// deployment
			[EditorSeparator]
			[EditorHelp("Own Deployment", "This grid cell uses custom deployment settings.")]
			public bool ownDeployment = false;

			[EditorCondition("ownDeployment", true)]
			[EditorAutoInit]
			[EditorEndCondition]
			public GridDeploymentCell deployment;


			// rotation
			[EditorSeparator]
			[EditorHelp("Set Spawn Rotation", "Set the rotation of a combatant spawning on this cell.")]
			public bool setSpawnRotation = false;

			[EditorHelp("Spawn Rotation", "The rotation a combatant spawning on this cell will have.")]
			[EditorCondition("setSpawnRotation", true)]
			[EditorEndCondition]
			public float spawnRotation = 0;


			// own blocked cell
			[EditorSeparator]
			[EditorHelp("Own Blocked Settings", "This grid cell uses custom blocked settings.")]
			public bool ownBlockedSettings = false;

			[EditorHelp("Blocked", "This grid cell is blocked.")]
			[EditorCondition("ownBlockedSettings", true)]
			public bool blocked = false;

			[EditorHelp("Passable", "This grid cell is passable (while blocked).")]
			[EditorCondition("blocked", true)]
			public bool passable = false;

			[EditorEndFoldout]
			[EditorHelp("Block Diagonal Move", "This grid cell allows diagonal movement (square grids only).")]
			[EditorEndCondition(2)]
			public bool blockDiagonalMove = true;


			// cell events
			[EditorFoldout("Grid Cell Events", "A cell event can perform abilities, apply status effects or use schematics on " +
				"combatants that move to/over or start/end their turn on cells of this type.", "")]
			[EditorEndFoldout]
			[EditorArray("Add Cell Event", "Adds a cell event that can be performed on combatants on cells of this type.", "",
				"Remove", "Removes this cell event.", "",
				isCopy = true, isMove = true,
				foldout = true, foldoutText = new string[] {
					"Cell Event", "Define when this cell event will be performed and what abilities, status effects or schematics will be used.", ""
			})]
			public GridCellEvent[] cellEvent = new GridCellEvent[0];

			public Settings()
			{

			}
		}
	}
}
