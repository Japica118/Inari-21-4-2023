
using UnityEngine;
using System.Collections;
using GamingIsLove.Makinom;
using GamingIsLove.Makinom.Components;
using GamingIsLove.Makinom.Schematics;

namespace GamingIsLove.ORKFramework.Components
{
	[AddComponentMenu("ORK Framework/ORK Game Starter")]
	public class ORKGameStarter : GameStarter
	{
		// call start menu
		public bool loadStartMenuScene = false;

		public bool callStartMenu = false;

		public float callAfter = 0;

		protected override void UseStartOptions()
		{
			if(!Maki.Game.Running)
			{
				if(this.loadStartMenuScene)
				{
					ORK.Game.LoadStartMenuScene();
				}
				else if(this.callStartMenu)
				{
					this.StartCoroutine(this.CallStartMenu());
				}
				else if(this.startGame)
				{
					Maki.Game.NewGame(true, true);
				}
				if(this.schematicAsset != null)
				{
					Schematic schematic = new Schematic(this.schematicAsset);
					schematic.PlaySchematic(this, this,
						this.gameObject, this.gameObject,
						true, MachineUpdateType.Update, Maki.Control.InputID);
				}
			}
		}

		protected virtual IEnumerator CallStartMenu()
		{
			if(this.callAfter > 0)
			{
				yield return new WaitForSeconds(this.callAfter);
			}
			ORK.StartMenu.menu.Show();
		}


		/*
		============================================================================
		Gizmo functions
		============================================================================
		*/
		protected override void OnDrawGizmos()
		{
			Gizmos.DrawIcon(transform.position, "/GamingIsLove/ORKFramework/Components/ORKGameStarter Icon.png");
		}
	}
}
