
using UnityEngine;
using UnityEngine.AI;
using System.Collections.Generic;
using GamingIsLove.Makinom;
using GamingIsLove.Makinom.Components;
using GamingIsLove.Makinom.UI;

namespace GamingIsLove.ORKFramework.Components
{
	[AddComponentMenu("")]
	public class CombatantComponent : ObjectChanges, IDropInteraction, IMoveSpeed, ISoundAssignment
	{
		protected Combatant combatant;

		protected AddCombatant addCombatantComponent;

		protected bool preventDestroyReset = false;

		protected bool registered = false;


		// movement variables
		protected bool inAir = false;


		// movement components (find ground)
		protected CharacterController controllerComp;

		protected NavMeshAgent navMeshAgent;


		/*
		============================================================================
		Properties functions
		============================================================================
		*/
		public virtual Combatant Combatant
		{
			get { return this.combatant; }
			set
			{
				this.combatant = value;
				if(this.combatant != null)
				{
					this.settings = this.combatant.Object.ChangesSettings;
				}
			}
		}

		public virtual AddCombatant AddCombatantComponent
		{
			get { return this.addCombatantComponent; }
			set { this.addCombatantComponent = value; }
		}

		public virtual bool PreventDestroyReset
		{
			get { return this.preventDestroyReset; }
			set { this.preventDestroyReset = value; }
		}


		/*
		============================================================================
		Combatant register functions
		============================================================================
		*/
		protected virtual void Start()
		{
			// find character controller
			this.controllerComp = this.GetComponent<CharacterController>();
			if(this.controllerComp == null)
			{
				this.controllerComp = this.transform.root.GetComponentInChildren<CharacterController>();
			}
			// find navmesh agent
			this.navMeshAgent = this.GetComponent<NavMeshAgent>();
			if(this.navMeshAgent == null)
			{
				this.navMeshAgent = this.transform.root.GetComponentInChildren<NavMeshAgent>();
			}

			// set damage dealer/zone combatant
			if(this.combatant != null)
			{
				DamageBase[] damage = this.gameObject.GetComponentsInChildren<DamageBase>();
				for(int i = 0; i < damage.Length; i++)
				{
					damage[i].Combatant = this.combatant;
				}
			}
		}

		protected virtual void OnEnable()
		{
			this.Register();
		}

		protected virtual void Register()
		{
			if(this.combatant != null &&
				!this.registered &&
				Maki.Game.Running)
			{
				ORK.Game.Combatants.Add(this.combatant, false);
				this.registered = true;
			}
		}

		protected virtual void OnDisable()
		{
			if(!this.preventDestroyReset &&
				this.combatant != null &&
				this.registered)
			{
				ORK.Game.Combatants.Remove(this.combatant);
				this.registered = false;
			}
		}

		protected virtual void OnDestroy()
		{
			if(!this.preventDestroyReset &&
				this.combatant != null)
			{
				this.combatant.Grid.Cell = null;

				if(this.combatant.GameObject == this.gameObject)
				{
					this.combatant.Object.StorePosition();
					this.combatant.Object.StoreComponentData();
					this.combatant.UI.Clear();
				}
			}
		}


		/*
		============================================================================
		Update functions
		============================================================================
		*/
		protected override void Update()
		{
			base.Update();

			if(!this.registered)
			{
				this.Register();
			}

			if(this.combatant != null && 
				!Maki.Game.Paused &&
				!this.combatant.Status.IsDead &&
					this.combatant.GameObject != null)
			{
				// check leave arena
				if(ORK.Control.InBattle)
				{
					if(ORK.Battle.LeftBattleArena(this.combatant))
					{
						ORK.Battle.RemoveCombatant(this.combatant, false, ORK.Battle.System.leaveArenaDestroyNonPlayer);
					}
				}
				// check start battle
				else if(Maki.Control.CanInteract &&
					!ORK.Game.ActiveGroup.AllDeadBattle() &&
					ORK.Game.ActiveGroup.Leader != null &&
					ORK.Game.ActiveGroup.Leader.GameObject != null &&
					this.combatant.IsEnemy(ORK.Game.ActiveGroup.Leader) &&
					// check auto start
					this.combatant.Setting.AutoStartBattles.Check(this.combatant, ORK.Game.ActiveGroup.Leader))
				{
					List<GameObject> tmp = Maki.Pooling.GameObjectLists.Get();
					tmp.Add(this.combatant.GameObject);
					tmp.Add(ORK.Game.ActiveGroup.Leader.GameObject);

					Vector3 center = TransformHelper.GetCenterPosition(tmp);
					Maki.Pooling.GameObjectLists.Add(tmp);
					BattleComponent battle = null;

					if(this.combatant.Group.SpawnOrigin != null &&
						this.combatant.Group.SpawnOrigin.Spawner != null)
					{
						battle = this.combatant.Group.SpawnOrigin.Spawner.GetBattleComponent(center,
							ORK.Game.ActiveGroup.Leader.GameObject.transform.eulerAngles,
							this.combatant.Setting.AutoStartBattles);
					}
					else if(this.addCombatantComponent != null)
					{
						battle = this.addCombatantComponent.GetBattleComponent(center,
							ORK.Game.ActiveGroup.Leader.GameObject.transform.eulerAngles,
							this.combatant.Setting.AutoStartBattles);
					}
					else
					{
						battle = new GameObject("_Battle").AddComponent<BattleComponent>();
						if(this.combatant.Setting.AutoStartBattles.setRotation)
						{
							battle.transform.SetPositionAndRotation(center,
								ORK.Game.ActiveGroup.Leader.GameObject.transform.rotation);
						}
						else
						{
							battle.transform.position = center;
						}
						battle.SetBattleSystem(this.combatant.Group.BattleSystem);
						battle.UseSceneID = false;
					}

					if(battle != null)
					{
						battle.StartGroup(this.combatant.Group, null);
					}
				}
			}
		}

		protected override void LateUpdate()
		{
			base.LateUpdate();

			if(this.combatant != null)
			{
				this.FindGround(this.combatant.Setting.moveSettings.FindGround);
			}
		}

		protected virtual void FindGround(FindGroundSettings settings)
		{
			if(FindGroundType.CharacterController == settings.type)
			{
				if(this.controllerComp != null &&
					this.navMeshAgent == null)
				{
					this.inAir = !this.controllerComp.isGrounded;
				}
			}
			else if(FindGroundType.Raycast == settings.type)
			{
				this.inAir = !settings.Raycast(this.transform);
			}
		}

		public virtual bool InAir
		{
			get { return this.inAir; }
			set { this.inAir = value; }
		}


		/*
		============================================================================
		Other functions
		============================================================================
		*/
		public virtual float GetMoveSpeed(MoveSpeedType moveType)
		{
			return this.combatant != null ?
				this.combatant.Object.GetMoveSpeed(moveType) :
				0;
		}

		public virtual AudioClip GetClip(SoundTypeAsset type)
		{
			return this.combatant != null ?
				this.combatant.Animations.GetAudioClip(type) :
				null;
		}


		/*
		============================================================================
		Drop functions
		============================================================================
		*/
		public virtual bool DropInteract(DragInfo drag)
		{
			if(drag == null)
			{
				return ORK.Battle.CombatantClicked(this.combatant);
			}
			else if(drag.Origin != null)
			{
				return drag.Origin.DroppedOnObject(this.combatant, drag);
			}
			return false;
		}
	}
}
