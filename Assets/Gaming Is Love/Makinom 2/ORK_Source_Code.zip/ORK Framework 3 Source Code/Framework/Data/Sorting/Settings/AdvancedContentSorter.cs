﻿
using UnityEngine;
using System.Collections.Generic;
using GamingIsLove.Makinom;

namespace GamingIsLove.ORKFramework
{
	public class AdvancedContentSorter : BaseData
	{
		public enum Type
		{
			None, Name, ID, TypeName, TypeID,
			Added, BuyPrice, SellPrice,
			InventorySpace, InventorySpaceSingle,
			StatusValueBonus, IntVariable, FloatVariable
		}

		[EditorHelp("Sort By", "Select how the data will be sorted:\n" +
			"- None: The data isn't sorted and will be listet as it appears.\n" +
			"- Name: The data is sorted by name (e.g. item name, ability name).\n" +
			"- ID: The data is sorted by ID (i.e. the index of the data).\n" +
			"- Type Name: The data is first sorted by type, then by name.\n" +
			"- Type ID: The data is first sorted by type, then by ID.\n" +
			"- Added: The data is sorted by the time it was added.\n" +
			"- Buy Price: The data is sorted by the buy price.\n" +
			"- Sell Price: The data is sorted by the sell price.\n" +
			"- Inventory Space: The data is sorted by total inventory space.\n" +
			"- Inventory Space Single: The data is sorted by inventory space for a quantity of 1.\n" +
			"- Status Value Bonus: The data is sorted by bonus for a selected status value " +
			"(equipment only, doesn't account for percent bonuses).\n" +
			"- Int Variable: The data is sorted by the value of an int variable " +
			"(variables on ability, equipment and item only).\n" +
			"- Float Variable: The data is sorted by the value of a float variable " +
			"(variables on ability, equipment and item only).", "")]
		public Type sorting = Type.Name;

		// status value
		[EditorHelp("Status Value", "Select the status value that will be used.", "")]
		[EditorCondition("sorting", Type.StatusValueBonus)]
		[EditorEndCondition]
		[EditorAutoInit]
		public AssetSelection<StatusValueAsset> statusValue;

		// variable
		[EditorHelp("Variable Key", "Define the key of the variable that will be used.")]
		[EditorInfo(isVariableField = true)]
		[EditorWidth(true)]
		[EditorCondition("sorting", Type.IntVariable)]
		[EditorCondition("sorting", Type.FloatVariable)]
		[EditorEndCondition]
		public string variableKey = "";

		// invert
		[EditorHelp("Invert Order", "The data is sorted in inverted order.", "")]
		public bool invert = false;

		public AdvancedContentSorter()
		{

		}


		/*
		============================================================================
		Sort functions
		============================================================================
		*/
		public void Sort<T>(Combatant user, ref List<T> list) where T : IContent
		{
			if(Type.None == this.sorting)
			{
				if(this.invert)
				{
					list.Reverse();
				}
			}
			else if(Type.Name == this.sorting)
			{
				list.Sort(new NameContentSorter<T>(this.invert));
			}
			else if(Type.ID == this.sorting)
			{
				list.Sort(new IDContentSorter<T>(this.invert));
			}
			else if(Type.TypeName == this.sorting)
			{
				list.Sort(new TypeNameContentSorter<T>(this.invert));
			}
			else if(Type.TypeID == this.sorting)
			{
				list.Sort(new TypeIDContentSorter<T>(this.invert));
			}
			else if(Type.Added == this.sorting)
			{
				if(typeof(ITimestamp).IsAssignableFrom(typeof(T)))
				{
					List<ITimestamp> tmpList = new List<ITimestamp>(list.Count);
					for(int i = 0; i < list.Count; i++)
					{
						tmpList.Add((ITimestamp)list[i]);
					}

					tmpList.Sort(new TimestampSorter(this.invert));

					list.Clear();
					for(int i = 0; i < tmpList.Count; i++)
					{
						list.Add((T)tmpList[i]);
					}
				}
			}
			else if(Type.BuyPrice == this.sorting)
			{
				if(typeof(IShortcut).IsAssignableFrom(typeof(T)))
				{
					List<IShortcut> tmpList = new List<IShortcut>(list.Count);
					for(int i = 0; i < list.Count; i++)
					{
						tmpList.Add((IShortcut)list[i]);
					}

					tmpList.Sort(new BuyPriceSorter(user, this.invert));

					list.Clear();
					for(int i = 0; i < tmpList.Count; i++)
					{
						list.Add((T)tmpList[i]);
					}
				}
			}
			else if(Type.SellPrice == this.sorting)
			{
				if(typeof(IShortcut).IsAssignableFrom(typeof(T)))
				{
					List<IShortcut> tmpList = new List<IShortcut>(list.Count);
					for(int i = 0; i < list.Count; i++)
					{
						tmpList.Add((IShortcut)list[i]);
					}

					tmpList.Sort(new SellPriceSorter(user, this.invert));

					list.Clear();
					for(int i = 0; i < tmpList.Count; i++)
					{
						list.Add((T)tmpList[i]);
					}
				}
			}
			else if(Type.InventorySpace == this.sorting)
			{
				if(typeof(IInventoryShortcut).IsAssignableFrom(typeof(T)))
				{
					List<IInventoryShortcut> tmpList = new List<IInventoryShortcut>(list.Count);
					for(int i = 0; i < list.Count; i++)
					{
						tmpList.Add((IInventoryShortcut)list[i]);
					}

					tmpList.Sort(new InventorySpaceSorter(-1, this.invert));

					list.Clear();
					for(int i = 0; i < tmpList.Count; i++)
					{
						list.Add((T)tmpList[i]);
					}
				}
			}
			else if(Type.InventorySpaceSingle == this.sorting)
			{
				if(typeof(IInventoryShortcut).IsAssignableFrom(typeof(T)))
				{
					List<IInventoryShortcut> tmpList = new List<IInventoryShortcut>(list.Count);
					for(int i = 0; i < list.Count; i++)
					{
						tmpList.Add((IInventoryShortcut)list[i]);
					}

					tmpList.Sort(new InventorySpaceSorter(1, this.invert));

					list.Clear();
					for(int i = 0; i < tmpList.Count; i++)
					{
						list.Add((T)tmpList[i]);
					}
				}
			}
			else if(Type.StatusValueBonus == this.sorting)
			{
				if(this.statusValue.StoredAsset != null)
				{
					if(typeof(EquipShortcut).IsAssignableFrom(typeof(T)))
					{
						List<EquipShortcut> tmpList = new List<EquipShortcut>(list.Count);
						for(int i = 0; i < list.Count; i++)
						{
							tmpList.Add((EquipShortcut)(IInventoryShortcut)list[i]);
						}

						tmpList.Sort(new EquipStatusValueSorter(user, this.statusValue.StoredAsset.Settings, this.invert));

						list.Clear();
						for(int i = 0; i < tmpList.Count; i++)
						{
							list.Add((T)(IInventoryShortcut)tmpList[i]);
						}
					}
					else if(typeof(IInventoryShortcut).IsAssignableFrom(typeof(T)))
					{
						List<IInventoryShortcut> tmpList = new List<IInventoryShortcut>(list.Count);
						for(int i = 0; i < list.Count; i++)
						{
							tmpList.Add((IInventoryShortcut)list[i]);
						}

						tmpList.Sort(new EquipStatusValueSorter(user, this.statusValue.StoredAsset.Settings, this.invert));

						list.Clear();
						for(int i = 0; i < tmpList.Count; i++)
						{
							list.Add((T)tmpList[i]);
						}
					}
				}
			}
			else if(Type.IntVariable == this.sorting)
			{
				if(typeof(IVariableSource).IsAssignableFrom(typeof(T)))
				{
					List<IVariableSource> tmpList = new List<IVariableSource>(list.Count);
					for(int i = 0; i < list.Count; i++)
					{
						tmpList.Add((IVariableSource)list[i]);
					}

					tmpList.Sort(new IntVariableSorter(this.variableKey, this.invert));

					list.Clear();
					for(int i = 0; i < tmpList.Count; i++)
					{
						list.Add((T)tmpList[i]);
					}
				}
			}
			else if(Type.FloatVariable == this.sorting)
			{
				if(typeof(IVariableSource).IsAssignableFrom(typeof(T)))
				{
					List<IVariableSource> tmpList = new List<IVariableSource>(list.Count);
					for(int i = 0; i < list.Count; i++)
					{
						tmpList.Add((IVariableSource)list[i]);
					}

					tmpList.Sort(new FloatVariableSorter(this.variableKey, this.invert));

					list.Clear();
					for(int i = 0; i < tmpList.Count; i++)
					{
						list.Add((T)tmpList[i]);
					}
				}
			}
		}
	}
}
