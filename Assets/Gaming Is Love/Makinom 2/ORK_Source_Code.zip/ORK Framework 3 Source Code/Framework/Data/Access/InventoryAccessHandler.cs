﻿
using UnityEngine;
using System.Collections.Generic;
using GamingIsLove.ORKFramework.UI;
using GamingIsLove.Makinom;

namespace GamingIsLove.ORKFramework
{
	public class InventoryAccessHandler
	{
		public InventoryAccessHandler()
		{

		}


		/*
		============================================================================
		Crafting recipe functions
		============================================================================
		*/
		/// <summary>
		/// Creates the outcome of a crafting recipe.
		/// </summary>
		/// <param name="combatant">The combatant used to craft.</param>
		/// <param name="recipe">The crafting recipe.</param>
		/// <param name="notify">A callback function taking a bool parameter (<c>true</c> if crafting was successful).</param>
		public virtual void UseCraftingRecipe(Combatant combatant, CraftingRecipe recipe, NotifyBool notify)
		{
			if(recipe != null)
			{
				recipe.CreateItem(combatant, notify);
			}
		}

		/// <summary>
		/// Adds an item to the crafting list of a combatant.
		/// </summary>
		/// <param name="combatant">The used combatant.</param>
		/// <param name="item">The item that will be added.</param>
		public virtual void AddToCraftingList(Combatant combatant, IShortcut item)
		{
			combatant.Inventory.Crafting.AddToCraftingList(item, true);
		}

		/// <summary>
		/// Removes an item from the crafting list of a combatant.
		/// </summary>
		/// <param name="combatant">The used combatant.</param>
		/// <param name="item">The item that will be removed.</param>
		public virtual void RemoveFromCraftingList(Combatant combatant, IShortcut item)
		{
			combatant.Inventory.Crafting.RemoveFromCraftingList(item, true);
		}

		/// <summary>
		/// Removes all items in a combatant's crafting list and returns them to the inventory.
		/// </summary>
		/// <param name="combatant">The used combatant.</param>
		public virtual void ClearCraftingList(Combatant combatant)
		{
			combatant.Inventory.Crafting.ClearCraftingList(true);
		}

		/// <summary>
		/// Creates the outcome of a crafting recipe matching the items in the crafting list of a combatant.
		/// </summary>
		/// <param name="combatant">The used combatant.</param>
		/// <param name="creationType">The creation type used (Exact, One, Multi).</param>
		/// <param name="consumeUnused"><c>true</c> if unused items in the crafting list should be consumed.</param>
		/// <param name="onlyKnownRecipes"><c>true</c> if only crafting recipes that are known to the combatant should be used.</param>
		public virtual void CreateFromCraftingList(Combatant combatant, CraftingListCreationType creationType,
			bool consumeUnused, bool onlyKnownRecipes, Notify finished)
		{
			combatant.Inventory.Crafting.CreateFromCraftingList(combatant,
				creationType, consumeUnused, onlyKnownRecipes, finished);
		}


		/*
		============================================================================
		Inventory functions
		============================================================================
		*/
		/// <summary>
		/// Adds an item to an inventory.
		/// </summary>
		/// <param name="inventory">The inventory that will be used.</param>
		/// <param name="item">The item that will be added.</param>
		/// <param name="showNotification"><c>true</c> if a notification should be displayed.</param>
		/// <param name="showConsole"><c>true</c> if a console line should be added.</param>
		/// <param name="markNewContent"><c>true</c> if the item should be marked as new content.</param>
		/// <returns><c>true</c> if the item was added.</returns>
		public virtual bool Add(Inventory inventory, IShortcut item,
			bool showNotification, bool showConsole, bool markNewContent)
		{
			return inventory.Add(item, showNotification, showConsole, markNewContent);
		}

		/// <summary>
		/// Splits an item in the inventory into 2 stacks.
		/// </summary>
		/// <param name="inventory">The inventory that will be used.</param>
		/// <param name="item">The item that will be split.</param>
		/// <param name="newQuantity">The quantity of the new stack (removed from old stack).</param>
		/// <returns>The new shortcut that was split off.</returns>
		public virtual IShortcut Split(Inventory inventory, IShortcut item, int newQuantity)
		{
			return inventory.Split(item, newQuantity);
		}

		/// <summary>
		/// Merges two items in the inventory into a single stack.
		/// </summary>
		/// <param name="inventory">The inventory that will be used.</param>
		/// <param name="originalShortcut">The shortcut that will be added to.</param>
		/// <param name="otherShortcut">The shortcut that will be removed from.</param>
		/// <returns><c>true</c> if the shortcuts where merged.</returns>
		public virtual bool Merge(Inventory inventory, IShortcut originalShortcut, IShortcut otherShortcut)
		{
			return inventory.Merge(originalShortcut, otherShortcut);
		}

		/// <summary>
		/// Removes an item from an inventory
		/// </summary>
		/// <param name="inventory">The inventory that will be used.</param>
		/// <param name="item">The item that will be removed.</param>
		/// <param name="quantity">The quantity that will be removed.</param>
		/// <param name="showNotification"><c>true</c> if a notification should be displayed.</param>
		/// <param name="showConsole"><c>true</c> if a console line should be added.</param>
		public virtual void Remove(Inventory inventory, IShortcut item,
			int quantity, bool showNotification, bool showConsole)
		{
			inventory.Remove(item, quantity, showNotification, showConsole);
		}

		/// <summary>
		/// Drops an item from an inventory into the game world.
		/// </summary>
		/// <param name="inventory">The inventory that will be used.</param>
		/// <param name="item">The item that will be dropped.</param>
		/// <param name="quantity">The quantity that will be dropped.</param>
		/// <param name="showNotification"><c>true</c> if a notification should be displayed.</param>
		/// <param name="showConsole"><c>true</c> if a console line should be added.</param>
		public virtual void Drop(Inventory inventory, IShortcut item,
			int quantity, bool showNotification, bool showConsole)
		{
			inventory.Drop(item, quantity, showNotification, showConsole);
		}

		/// <summary>
		/// Drops an item from an inventory into the game world.
		/// </summary>
		/// <param name="inventory">The inventory that will be used.</param>
		/// <param name="item">The item that will be dropped.</param>
		/// <param name="quantity">The quantity that will be dropped.</param>
		/// <param name="showNotification"><c>true</c> if a notification should be displayed.</param>
		/// <param name="showConsole"><c>true</c> if a console line should be added.</param>
		/// <param name="droppedObjects">Game objects of dropped items will be added to this list.</param>
		public virtual void Drop(Inventory inventory, IShortcut item,
			int quantity, bool showNotification, bool showConsole, List<GameObject> droppedObjects)
		{
			inventory.Drop(item, quantity, showNotification, showConsole, droppedObjects);
		}

		/// <summary>
		/// Sets the amount of currency in an inventory.
		/// </summary>
		/// <param name="inventory">The inventory that will be used.</param>
		/// <param name="currency">The currency.</param>
		/// <param name="quantity">The quantity the currency will be set to.</param>
		/// <param name="showNotification"><c>true</c> if a notification should be displayed.</param>
		/// <param name="showConsole"><c>true</c> if a console line should be added.</param>
		public virtual void SetCurrency(Inventory inventory, Currency currency, int quantity, bool showNotification, bool showConsole)
		{
			inventory.SetCurrency(currency, quantity, showNotification, showConsole);
		}

		/// <summary>
		/// Removes items of an item type from an inventory.
		/// </summary>
		/// <param name="inventory">The inventory that will be used.</param>
		/// <param name="itemType">The item type that will be removed.</param>
		/// <param name="removeSubTypes"><c>true</c> if sub types of the item type should be removed.</param>
		/// <param name="removeCurrency"><c>true</c> if currency should be removed.</param>
		/// <param name="removeItems"><c>true</c> if items should be removed.</param>
		/// <param name="removeEquipment"><c>true</c> if equipment should be removed.</param>
		/// <param name="showNotification"><c>true</c> if a notification should be displayed.</param>
		/// <param name="showConsole"><c>true</c> if a console line should be added.</param>
		public virtual void RemoveItemType(Inventory inventory, ItemType itemType, bool removeSubTypes,
			bool removeCurrency, bool removeItems, bool removeEquipment,
			bool showNotification, bool showConsole)
		{
			inventory.RemoveItemType(itemType, removeSubTypes,
				removeCurrency, removeItems, removeEquipment,
				showNotification, showConsole);
		}


		/*
		============================================================================
		Equipment functions
		============================================================================
		*/
		/// <summary>
		/// Resets durability of an equipment.
		/// </summary>
		/// <param name="equip">The instance of the equipment.</param>
		/// <param name="combatant">The combatant used for resetting durability (e.g. in case durability uses a formula).</param>
		public virtual void ResetDurability(EquipShortcut equip, Combatant combatant)
		{
			equip.ResetDurability(combatant);
		}

		/// <summary>
		/// Changes the durability of an equipment.
		/// </summary>
		/// <param name="equip">The instance of the equipment.</param>
		/// <param name="combatant">The combatant used for the change (e.g. in case durability uses a formula).</param>
		/// <param name="value">The value the durability will be changed by.</param>
		/// <param name="op">The operator used for the change.</param>
		public virtual void ChangeDurability(EquipShortcut equip, Combatant combatant, float value, SimpleOperator op)
		{
			equip.ChangeDurability(combatant, value, op);
		}


		/*
		============================================================================
		Shop functions
		============================================================================
		*/
		public virtual ShopScreen OpenShop(GameObject shopObject, NotifyBool notifyClosed, ShopSetting setting, string shopID, FactionSetting faction)
		{
			return new ShopScreen(shopObject, notifyClosed, setting, shopID, faction);
		}
	}
}
