﻿
using UnityEngine;
using System.Collections.Generic;
using GamingIsLove.Makinom;

namespace GamingIsLove.ORKFramework
{
	public class ActionAccessHandler
	{
		public ActionAccessHandler()
		{

		}


		/*
		============================================================================
		Battle action functions
		============================================================================
		*/
		/// <summary>
		/// Adds a battle action to a combatant, and after checks adding it to the battle system's action handler.
		/// </summary>
		/// <param name="user">The user combatant the action will be added to.</param>
		/// <param name="action">The battle action that will be added.</param>
		/// <param name="newTurn"><c>true</c> if the user should start a new turn (action fails if a new turn can't be started).</param>
		public virtual void AddActionToCombatant(Combatant user, BaseAction action, bool newTurn)
		{
			user.Actions.Add(action, newTurn);
		}

		/// <summary>
		/// Starts a combatant's action selection.
		/// For the player, this'll bring up the battle menu (if used), for AI controlled combatants it'll use the battle AI.
		/// </summary>
		/// <param name="combatant">The combatant selecting actions.</param>
		/// <param name="newTurn"><c>true</c> if the combatant should start a new turn.</param>
		/// <param name="autoCallMenu"><c>true</c> if the battle menu should be called automatically.</param>
		public virtual void Choose(Combatant combatant, bool newTurn, bool autoCallMenu)
		{
			combatant.Actions.Choose(newTurn, autoCallMenu);
		}

		/// <summary>
		/// Starts a combatant's auto action selection (using battle AI).
		/// </summary>
		/// <param name="combatant">The combatant selecting actions.</param>
		/// <param name="newTurn"><c>true</c> if the combatant should start a new turn.</param>
		public virtual void ChooseAuto(Combatant combatant, bool newTurn)
		{
			combatant.Actions.ChooseAuto(newTurn);
		}

		/// <summary>
		/// Adds a battle action to the battle system's action handler.
		/// </summary>
		/// <param name="action">The battle action that will be added.</param>
		public virtual void AddActionToBattle(BaseAction action)
		{
			ORK.Battle.Actions.Add(action);
		}

		/// <summary>
		/// Adds a battle action to the battle system's action handler as the next action that will be performed.
		/// </summary>
		/// <param name="action">The battle action that will be added.</param>
		public virtual void UnshiftActionToBattle(BaseAction action)
		{
			ORK.Battle.Actions.Unshift(action);
		}


		/*
		============================================================================
		Shortcut functions
		============================================================================
		*/
		/// <summary>
		/// Calls the 'Use' function of an <c>IShortcut</c> implementation.
		/// </summary>
		/// <param name="shortcut">The shortcut that will be used.</param>
		/// <param name="user">The user combatant.</param>
		/// <param name="targets">The target combatants.</param>
		/// <param name="useAction"><c>true</c> if a battle action will be used to animate the use/action.</param>
		/// <returns><c>true</c> if the shortcut was used.</returns>
		public virtual bool UseShortcut(IShortcut shortcut, Combatant user, List<Combatant> targets, bool useAction)
		{
			return shortcut.Use(user, targets, useAction);
		}

		/// <summary>
		/// Spends experience points on something that can be leveled up (e.g. an ability).
		/// </summary>
		/// <param name="user">The combatant that spends the experience.</param>
		/// <param name="levelUp">The content that will level up.</param>
		public virtual void SpendExperience(Combatant user, ILevelUpSpend levelUp)
		{
			levelUp.SpendExperience(user);
		}


		/*
		============================================================================
		Use functions
		============================================================================
		*/
		public virtual void UseItem(ItemShortcut item, Combatant user, List<Combatant> target, GameObject flyingTextTargetObject, bool fromAction,
			bool animate, bool doConsume, float damageFactor, float damageMultiplier,
			VariableHandler localVariables, SelectedDataHandler selectedData, ActionCalculationFinished notify, ItemAction action)
		{
			item.Setting.Use(item, user, target, flyingTextTargetObject, fromAction, animate, doConsume,
				damageFactor, damageMultiplier, localVariables, selectedData, notify, action);
		}

		public virtual void UseAbility(AbilityShortcut ability, Combatant user, List<Combatant> target, 
			GameObject flyingTextTargetObject, bool fromAction,
			bool animate, bool doCounter, bool doUseCosts, float damageFactor, float damageMultiplier,
			VariableHandler localVariables, SelectedDataHandler selectedData, ActionCalculationFinished notify, AbilityAction action)
		{
			ability.GetActiveLevel().Use(ability, user, target, flyingTextTargetObject, fromAction, animate, doCounter, doUseCosts,
				damageFactor, damageMultiplier, localVariables, selectedData, notify, action);
		}
	}
}
