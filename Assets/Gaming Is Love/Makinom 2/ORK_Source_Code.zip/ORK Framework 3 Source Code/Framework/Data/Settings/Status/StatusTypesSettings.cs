﻿
using UnityEngine;
using GamingIsLove.Makinom;

namespace GamingIsLove.ORKFramework
{
	public class StatusTypesSettings : GenericAssetListSettings<StatusTypeAsset, StatusType>
	{
		public StatusTypesSettings(MakinomProjectAsset project)
		{
			this.LoadProject(project);
			this.CreateGUIDLookup();
		}


		/*
		============================================================================
		Properties
		============================================================================
		*/
		public override string Filename
		{
			get { return "Status Types"; }
		}
	}
}

