
using UnityEngine;
using GamingIsLove.ORKFramework.UI;
using System.Collections.Generic;
using GamingIsLove.Makinom;
using GamingIsLove.Makinom.Components;

namespace GamingIsLove.ORKFramework
{
	public class InventorySettings : BaseSettings
	{
		// editor help text display
		[EditorHelp("Inventory Type", "Select the inventory type.\n" +
			"- Group: The whole group shares an inventory.\n" +
			"- Individual: Each group member has its own inventory. This means " +
			"they can only use items from their own inventory.", "")]
		[EditorFoldout("Inventory Settings", "Base inventory management settings.", "")]
		[EditorTitleLabel("General Settings")]
		public CombatantScope type = CombatantScope.Group;

		[EditorHelp("Update Size By Variables", "Inventory space and inventory container slot counts are checked/updated " +
			"by changes to global variables and object variables on the inventory's owners (combatants).\n" +
			"If disabled, variable changes don't automatically update the inventory sizes.")]
		public bool sizeUpdateByVariables = false;

		// add types
		[EditorHelp("Item Stack Type", "Select how items are stacked in the inventory:\n" +
			"- Add: Just adds the items as they are as new items to the inventory (using the same quantity).\n" +
			"- Auto Stack: Automatically stacks items, " +
			"i.e. items that are equal will be grouped together.\n" +
			"- Auto Split: Automatically splits items, " +
			"i.e. adding multiple items will split them into single items in the inventory.\n" +
			"This can be overridden by individual items.", "")]
		[EditorSeparator]
		[EditorTitleLabel("Item Stacking")]
		public InventoryAddType itemAddType = InventoryAddType.AutoStack;

		[EditorHelp("Equipment Stack Type", "Select how equipment is stacked in the inventory:\n" +
			"- Add: Just adds the equpment as they are as new equpment to the inventory (using the same quantity).\n" +
			"- Auto Stack: Automatically stacks equpment, " +
			"i.e. equpment that are equal will be grouped together.\n" +
			"- Auto Split: Automatically splits equpment, " +
			"i.e. adding multiple equpment will split them into single equpment in the inventory.\n" +
			"This can be overridden by individual equpment.", "")]
		public InventoryAddType equipmentAddType = InventoryAddType.AutoStack;

		// inventory space
		[EditorSeparator]
		[EditorTitleLabel("Default Inventory Space")]
		public InventorySpace inventorySpace = new InventorySpace();

		// quantity limit
		[EditorSeparator]
		[EditorTitleLabel("Default Quantity Limit")]
		public InventoryQuantityLimit quantityLimit = new InventoryQuantityLimit();

		// stack limit
		[EditorSeparator]
		[EditorTitleLabel("Default Stack Limit")]
		public InventoryStackLimit stackLimit = new InventoryStackLimit();

		// space limit
		[EditorHelp("Space Limit", "The inventory will be limited by space - items and equipment will occupy space.\n" +
			"If disabled, there is no inventory limit, items and equipment can be added without limitations.", "")]
		[EditorFoldout("Space Limit", "Optionally limit the space available in inventories.")]
		public bool limit = false;

		[EditorHelp("Block Adding", "Items and equipment can't be added if the inventory limit is reached.", "")]
		[EditorCondition("limit", true)]
		public bool blockAdd = false;

		[EditorHelp("Block Unequip", "Unequipping equipment is blocked if not enough space is left in the inventory it's returned to.\n" +
			"If disabled, unequipped equipment can disappear completely if no space is available in the inventory.", "")]
		[EditorIndent]
		[EditorCondition("blockAdd", true)]
		[EditorEndCondition]
		public bool limitBlockUnequip = false;

		[EditorHelp("Only Leader (Group)", "Only use the leader of the group when using 'Group' inventory " +
			"instead of summing up the value for each member.", "")]
		[EditorCondition("type", CombatantScope.Group)]
		[EditorEndCondition]
		public bool limitOnlyLeader = false;

		[EditorHelp("Limit Value", "Define the inventory limit.\n" +
			"If 'Group' inventory is used, the limit is calculated by summing up the value for all active group members.\n" +
			"If 'Only Leader' is enabled, the group inventory space is calculated using the leader instead of summing up for all members.\n" +
			"Please note: Using variables (global or object variables on combatants), " +
			"enable 'Update Size By Variables' in 'Inventory > Inventory Settings' to automatically update the space on variable changes.", "")]
		[EditorAutoInit]
		public FloatValue<GameObjectSelection> limitValue;

		[EditorEndFoldout]
		[EditorArray("Add Status Effect", "Adds an status effect. " +
			"The status effect will be applied to the inventory owner when the inventory is filled to a defined percentage.", "",
			"Remove", "Removes this status effect.", "",
			foldout = true, foldoutText = new string[] {
				"Inventory Status Effect", "Define the filled percent and status effect used.", ""
			})]
		[EditorEndCondition]
		public InventoryFullStatusEffect[] fullStatusEffect = new InventoryFullStatusEffect[0];

		// default item prefab
		[EditorFoldout("Default Item Prefab", "Define the prefab used to display currencies, items, crafting recipes, AI behaviours and AI rulesets in a scene.\n" +
			"Optionally use conditional prefabs to display different prefabs based on variable conditions.\n" +
			"Currencies, items, crafting recipes, AI behaviours and AI rulesets can override the default item prefab.\n" +
			"Equipment doesn't use the default item prefab.", "")]
		[EditorEndFoldout(2)]
		public ItemPrefabSettings prefabSettings = new ItemPrefabSettings();


		// mark new content settings
		[EditorFoldout("Mark New Content", "These settings handle if and how new content will be marked and unmarked.\n" +
			"E.g. getting a new quest can optionally mark the quest as new in menus.", "")]
		[EditorEndFoldout]
		public MarkNewContentSettings markNewContent = new MarkNewContentSettings();


		// drop item settings
		[EditorHelp("Drop On Ground", "The item will be spawned on the ground (using a raycast, see the Unity documentations for details).", "")]
		[EditorFoldout("Drop Item Settings", "Items, equipment and currency can be  dropped into the game world by the player or defeated combatants.", "")]
		public bool dropOnGround = false;

		[EditorCondition("dropOnGround", true)]
		[EditorEndCondition]
		[EditorAutoInit]
		public PlaceOnGround.Settings dropOnGroundSettings;

		[EditorHelp("Use Drop Rotation", "Use the rotation of the combatant (or used game object) when dropping the item into the game world.", "")]
		[EditorSeparator]
		public bool dropUseRotation = false;

		[EditorHelp("Save Updated Position", "Saving item drops will save the latest position/rotation of the item.\n" +
			"If disabled, the drop position/rotation will be saved.", "")]
		public bool dropSaveUpdatedPosition = false;

		[EditorSeparator]
		[EditorTitleLabel("Offset Settings")]
		public LocalSpace dropLocalSpace = new LocalSpace(true);

		[EditorHelp("Offset X", "The offset added to the position of the combatant who drops the item.\n" +
			"The X and Y values are used for random calculation.\n" +
			"E.g. X=1 and Y=-1: The item will be dropped at a random offset between 1 and -1 on the X-axis.", "")]
		public Vector2 dropOffsetX = new Vector2(1, -1);

		[EditorHelp("Offset Y", "The offset added to the position of the combatant who drops the item.\n" +
			"The X and Y values are used for random calculation.\n" +
			"E.g. X=1 and Y=-1: The item will be dropped at a random offset between 1 and -1 on the Y-axis.", "")]
		public Vector2 dropOffsetY = new Vector2(1, -1);

		[EditorHelp("Offset Z", "The offset added to the position of the combatant who drops the item.\n" +
			"The X and Y values are used for random calculation.\n" +
			"E.g. X=1 and Y=-1: The item will be dropped at a random offset between 1 and -1 on the Z-axis.", "")]
		public Vector2 dropOffsetZ = new Vector2(1, 1);

		// item collector settings
		[EditorFoldout("Item Collector Settings", "Define some settings of the 'Item Collector' component used by drop items.")]
		public DropItemCollectorSettings dropCollectorSettings = new DropItemCollectorSettings();

		[EditorFoldout("Start Settings", "Define how drop item interactions can be started.")]
		[EditorEndFoldout]
		public BaseInteractionComponent.StartSettings dropStartSettings = new BaseInteractionComponent.StartSettings(true);

		[EditorFoldout("Condition Settings", "Define the conditions of drop item interactions.")]
		[EditorEndFoldout(2)]
		public ComponentConditionSetting dropConditionSettings = new ComponentConditionSetting();

		// despawn
		// inventory
		[EditorHelp("Despawn Inventory Drops", "Automatically despawn drops made from an inventory (e.g. using a menu screen).\n" +
			"Despawned drops will be removed forever.", "")]
		[EditorFoldout("Despawn Settings", "Optionally despawn item drops from the inventory or battle loot after a defined amount of time.", "")]
		public bool dropDespawnInventory = false;

		[EditorHelp("Despawn Time (s)", "The time in seconds until the drops are despawned.")]
		[EditorCondition("dropDespawnInventory", true)]
		[EditorEndCondition]
		[EditorAutoInit]
		public FloatValue<GameObjectSelection> dropDespawnInventoryTime;

		// battle
		[EditorHelp("Despawn Battle Drops", "Automatically despawn battle loot drops.\n" +
			"Despawned drops will be removed forever.", "")]
		[EditorSeparator]
		public bool dropDespawnBattle = false;

		[EditorHelp("Despawn Time (s)", "The time in seconds until the drops are despawned.", "")]
		[EditorEndFoldout(2)]
		[EditorCondition("dropDespawnBattle", true)]
		[EditorEndCondition]
		[EditorAutoInit]
		public FloatValue<GameObjectSelection> dropDespawnBattleTime;


		// item collection
		[EditorFoldout("Item Collection", "These settings are used by item collectors when " +
			"picking up single or random items, equipment or currency in a scene.\n" +
			"You can use the 'Start Item Collector' node in schematics to add additional " +
			"functionality to item collection.", "")]
		[EditorEndFoldout]
		public ItemCollectionControl itemCollection = new ItemCollectionControl();


		// item box
		[EditorFoldout("Item Box", "These settings are used by item collectors when " +
			"picking up items, equipment or currency from a box in a scene.\n" +
			"You can use the 'Start Item Collector' node in schematics to add additional " +
			"functionality to item collection.", "")]
		[EditorEndFoldout]
		public ItemBoxControl itemBoxCollection = new ItemBoxControl();


		// notifications
		[EditorFoldout("Notification Settings", "Inventory changes and crafting recipes can display notifications.", "")]
		[EditorEndFoldout]
		public InventoryNotificationSettings notifications = new InventoryNotificationSettings();

		public InventorySettings(MakinomProjectAsset project)
		{
			this.LoadProject(project);
		}


		/*
		============================================================================
		Properties
		============================================================================
		*/
		public override string Filename
		{
			get { return "Inventory Settings"; }
		}


		/*
		============================================================================
		Inventory functions
		============================================================================
		*/
		public virtual bool IsGroup()
		{
			return CombatantScope.Group == this.type;
		}

		public virtual bool IsIndividual()
		{
			return CombatantScope.Individual == this.type;
		}

		public virtual void AddDropOffset(ref Vector3 position)
		{
			position += new Vector3(
				UnityWrapper.Range(this.dropOffsetX.x, this.dropOffsetX.y),
				UnityWrapper.Range(this.dropOffsetY.x, this.dropOffsetY.y),
				UnityWrapper.Range(this.dropOffsetZ.x, this.dropOffsetZ.y));

		}

		public virtual Vector3 GetDropOffset(GameObject gameObject)
		{
			return this.dropLocalSpace.GetOffsetPosition(gameObject.transform, 
				new Vector3(
					UnityWrapper.Range(this.dropOffsetX.x, this.dropOffsetX.y),
					UnityWrapper.Range(this.dropOffsetY.x, this.dropOffsetY.y),
					UnityWrapper.Range(this.dropOffsetZ.x, this.dropOffsetZ.y)));

		}
	}
}

