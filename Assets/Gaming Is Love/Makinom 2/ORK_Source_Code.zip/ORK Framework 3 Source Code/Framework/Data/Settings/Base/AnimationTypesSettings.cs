
using UnityEngine;
using GamingIsLove.ORKFramework.Animations;
using System.Collections.Generic;
using GamingIsLove.Makinom;

namespace GamingIsLove.ORKFramework
{
	public class AnimationTypesSettings : BaseSettings
	{
		// movement
		[EditorHelp("Idle Type", "Select the animation type used for the idle animation " +
			"(i.e. when the combatant isn't moving).", "")]
		[EditorFoldout("Default Animation Types", "Select the animation types for the default animations used by ORK, " +
			"e.g. damage, evade, etc.\n" +
			"The default animation types are displayed in all animation types, but you only need to define them once.", "")]
		[EditorTitleLabel("Movement Animation Types")]
		public AssetSelection<AnimationTypeAsset> idle = new AssetSelection<AnimationTypeAsset>();

		[EditorHelp("Walk Type", "Select the animation type used for the walk animation " +
			"(i.e. when the combatant is walking (walk speed setting of the combatant).", "")]
		public AssetSelection<AnimationTypeAsset> walk = new AssetSelection<AnimationTypeAsset>();

		[EditorHelp("Run Type", "Select the animation type used for the run animation " +
			"(i.e. when the combatant is running (run speed setting of the combatant).", "")]
		public AssetSelection<AnimationTypeAsset> run = new AssetSelection<AnimationTypeAsset>();

		[EditorHelp("Sprint Type", "Select the animation type used for the sprint animation " +
			"(i.e. when the combatant is sprinting (sprint speed setting of the combatant).", "")]
		public AssetSelection<AnimationTypeAsset> sprint = new AssetSelection<AnimationTypeAsset>();

		[EditorHelp("Jump Type", "Select the animation type used for the jump animation " +
			"(i.e. when the combatant jumps).", "")]
		public AssetSelection<AnimationTypeAsset> jump = new AssetSelection<AnimationTypeAsset>();

		[EditorHelp("Fall Type", "Select the animation type used for the fall animation " +
			"(i.e. when the combatant falls).", "")]
		public AssetSelection<AnimationTypeAsset> fall = new AssetSelection<AnimationTypeAsset>();

		[EditorHelp("Land Type", "Select the animation type used for the land animation " +
			"(i.e. when the combatant lands on the ground after falling).", "")]
		public AssetSelection<AnimationTypeAsset> land = new AssetSelection<AnimationTypeAsset>();


		// battle
		[EditorHelp("Action Choose Idle Type", "Select the animation type used for the idle animation when choosing an action " +
			"(e.g. when the player chooses the combatant's next action in the battle menu and isn't moving).", "")]
		[EditorSeparator]
		[EditorTitleLabel("Battle Animation Types")]
		public AssetSelection<AnimationTypeAsset> actionChooseIdle = new AssetSelection<AnimationTypeAsset>();

		[EditorHelp("Action Wait Idle Type", "Select the animation type used for the idle animation when waiting to perform an action " +
			"(i.e. when the combatant already chose the next action and isn't moving).", "")]
		public AssetSelection<AnimationTypeAsset> actionWaitIdle = new AssetSelection<AnimationTypeAsset>();

		[EditorHelp("Action Cast Idle Type", "Select the animation type used for the idle animation when casting an action " +
			"(i.e. when the combatant is casting an action and isn't moving).", "")]
		public AssetSelection<AnimationTypeAsset> actionCastIdle = new AssetSelection<AnimationTypeAsset>();

		[EditorHelp("Turn Ended Idle Type", "Select the animation type used for the idle animation when a combatant's turn ended " +
			"(i.e. when the combatant finished all actions).", "")]
		public AssetSelection<AnimationTypeAsset> turnEndedIdle = new AssetSelection<AnimationTypeAsset>();

		[EditorHelp("Death Type", "Select the animation type used for the death animation " +
			"(i.e. when the combatant dies).", "")]
		public AssetSelection<AnimationTypeAsset> death = new AssetSelection<AnimationTypeAsset>();

		[EditorHelp("Revive Type", "Select the animation type used for the revive animation " +
			"(i.e. when the combatant is revived while being dead.", "")]
		public AssetSelection<AnimationTypeAsset> revive = new AssetSelection<AnimationTypeAsset>();

		[EditorHelp("Victory Type", "Select the animation type used for the victory animation " +
			"(i.e. when the combatant wins a battle.", "")]
		[EditorEndFoldout]
		public AssetSelection<AnimationTypeAsset> victory = new AssetSelection<AnimationTypeAsset>();

		public AnimationTypesSettings(MakinomProjectAsset project)
		{
			this.LoadProject(project);
		}


		/*
		============================================================================
		Properties
		============================================================================
		*/
		public override string Filename
		{
			get { return "Animation Types"; }
		}

		public override bool HasGeneralSettings
		{
			get { return true; }
		}
	}
}
