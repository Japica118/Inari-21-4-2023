﻿
using UnityEngine;
using GamingIsLove.ORKFramework.UI;
using GamingIsLove.Makinom;
using GamingIsLove.Makinom.UI;

namespace GamingIsLove.ORKFramework
{
	public class ShopLayoutsSettings : BaseSettings
	{
		// shop background
		[EditorFoldout("Shop Backgrounds", "Shops can display background UIs.\n" +
			"You can select the default backgrounds for all shops here.\n" +
			"Each shop layout and shop can override the default background UIs.\n" +
			"General background UIs are displayed in all shops and can't be overridden. " +
			"They're displayed behind the default backgrounds.", "")]
		[EditorEndFoldout]
		[EditorArray("Add Default Background", "Adds a default background UI.", "",
			"Remove", "Removes this default background UI.", "", foldout=true,
			foldoutText=new string[] {
				"Default Background", "Define the default background UI that will be displayed.\n" +
				"Default backgrounds can be overridden by shop layouts and shops.", ""
			})]
		public UIBackgroundSettings[] defaultShopBG = new UIBackgroundSettings[0];

		[EditorFoldout("General Backgrounds", "General background UIs are displayed in all shops and can't be overridden.", "")]
		[EditorEndFoldout]
		[EditorArray("Add General Background", "Adds a general background UI.", "",
			"Remove", "Removes this general background UI.", "", foldout=true,
			foldoutText=new string[] {
				"General Background", "Define the general background UI that will be displayed in all shops.\n" +
				"This background can't be overridden by individual shop layouts or shops.", ""
			})]
		public UIBackgroundSettings[] generalShopBG = new UIBackgroundSettings[0];

		public ShopLayoutsSettings(MakinomProjectAsset project)
		{
			this.LoadProject(project);
		}


		/*
		============================================================================
		Properties
		============================================================================
		*/
		public override string Filename
		{
			get { return "Shop Layouts"; }
		}
	}
}
