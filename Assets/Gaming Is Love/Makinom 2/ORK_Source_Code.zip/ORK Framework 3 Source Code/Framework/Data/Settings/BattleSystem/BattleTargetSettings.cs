﻿
using UnityEngine;
using GamingIsLove.ORKFramework.Combatants;
using GamingIsLove.ORKFramework.UI;
using System.Collections.Generic;
using GamingIsLove.Makinom;

namespace GamingIsLove.ORKFramework
{
	public class BattleTargetSettings : BaseSettings
	{
		// target selection
		// target menu
		[EditorHelp("Use Target Menu", "A menu based target selection is used.\n" +
			"Targets are listed as choices in a UI box.\n" +
			"The used UI box is defined by the battle menu.", "")]
		[EditorFoldout("Target Selection", "The settings for the target selection.\n" +
			"The target selection is used when selecting the target for a base attack, ability or item.\n" +
			"You can combine the different target selections.", "",
			"Target Menu", "Use a menu to select targets.\n" +
			"The used UI box is defined by the battle menu.", "")]
		public bool useTargetMenu = true;

		[EditorHelp("Auto 1 Single Target", "Automatically select the target if only one target choice is available ('Single' target range).\n" +
			"If disabled, the target selection is used.", "")]
		public bool autoOnlySingleTarget = false;

		[EditorHelp("Auto 1 Group Target", "Automatically select the target if only one target choice is available ('Group' target range).\n" +
			"If disabled, the target selection is used.", "")]
		public bool autoOnlyGroupTarget = false;

		[EditorHelp("Rotate To Target", "Rotate the user to the selected target during target selections.", "")]
		public bool rotateToTarget = false;

		[EditorHelp("Grid Rotation", "Limit the rotation to the nearest grid rotation during grid battles.", "")]
		[EditorCondition("rotateToTarget", true)]
		public bool rotateToTargetGridRotation = false;

		[EditorHelp("Rotate Cursor Over", "The user only rotates to a target when first hovering the cursor over it.", "")]
		[EditorEndFoldout]
		[EditorCondition("targetCursorOverSelection", true)]
		[EditorEndCondition(2)]
		[EditorDefaultValue(false)]
		public bool rotateToTargetCursorOver = false;

		// target keys
		[EditorFoldout("Target Change Keys", "Define input keys that can be used to switch between available targets.\n" +
			"These keys are used during the target selection (e.g. when the target menu would be displayed).", "",
			"Next Target Key", "The key to select the next target.\n" +
			"This will move the selection down in the target menu.", "")]
		[EditorEndFoldout]
		public AudioInputSelection targetNextKey = new AudioInputSelection();

		[EditorFoldout("Previous Target Key", "The key to select the previous target.\n" +
			"This will move the selection up in the target menu.", "")]
		[EditorEndFoldout]
		public AudioInputSelection targetPreviousKey = new AudioInputSelection();

		[EditorFoldout("Nearest Target Key", "The key to select the target closest to the user.", "")]
		[EditorEndFoldout]
		public AudioInputSelection targetNearestKey = new AudioInputSelection();

		[EditorFoldout("Target Range Key", "The key to toggle between 'Single' and 'Group' target range " +
			"for abilities/items that allow changing the target range.\n" +
			"This input key can be used during target selections (e.g. in the battle menu or menu screens).", "")]
		[EditorEndFoldout]
		public AudioInputSelection targetRangeKey = new AudioInputSelection();

		// directional keys
		[EditorHelp("Use Directional Selection", "Use directional keys (up, down, left, right, or horizontal and vertical axes) " +
			"to select targets based on screen-space directions from the current target " +
			"(e.g. pressing up selects the nearest target above the current one, in screen space).\n" +
			"If no target is selected, the selection is done based on the screen center.", "")]
		[EditorFoldout("Directional Selection", "Optionally use directional keys (up, down, left, right, or horizontal and vertical axes) " +
			"to select targets based on screen-space directions from the current target.", "")]
		public bool useDirectionalSelection = false;

		[EditorHelp("Block UI Box Input", "Block the target selection from the battle menu's UI box, " +
			"i.e. horizontal and vertical menu input isn't used during target selections.", "")]
		[EditorCondition("useDirectionalSelection", true)]
		public bool directionalSelectionBlockUIBoxInput = true;

		[EditorEndFoldout(2)]
		[EditorEndCondition]
		[EditorAutoInit]
		public DirectionalTargetSelection directionalSelection;

		// highlight target
		[EditorFoldout("Target Highlight", "Optionally highlight a targeted combatant's game object or HUD.")]
		[EditorEndFoldout]
		public HighlightCombatantSetting targetHighlight = new HighlightCombatantSetting();

		// click combatant
		// raycast settings
		[EditorHelp("Layer Mask", "Select the layer the raycast will use.\n" +
			"Only objects on this layer can be hit by the raycast.", "")]
		[EditorFoldout("Mouse/Touch Control", "Input settings for mouse and touch control.\n" +
			"A click/touch will use a raycast on that position to find a combatant.", "")]
		[EditorTitleLabel("Raycast Settings")]
		public LayerMask targetLayerMask = -1;

		[EditorHelp("Distance", "The distance the raycast will use (from the camera).", "")]
		public float targetRayDistance = 100.0f;

		[EditorHelp("Accept Only Selected", "Mouse/touch input can only accept already selected combatants.\n" +
			"E.g. first click will select, 2nd click (on selected combatant) will accept the combatant.", "")]
		public bool targetAcceptOnlySelected = false;

		[EditorHelp("Use Grid Cell", "Selection also works on the grid cells of combatants in grid battles.", "")]
		public bool targetUseGridCell = false;

		[EditorHelp("Cursor Over Selection", "Targets can be selected by hovering the cursor over the target's game object.", "")]
		public bool targetCursorOverSelection = false;

		[EditorHelp("Cursor Move Only", "Only check for hover selection when the cursor has actually been moved.\n" +
			"If disabled, hover selection is checked at all times.", "")]
		[EditorCondition("targetCursorOverSelection", true)]
		[EditorEndCondition]
		public bool targetCursorOverMouseMoveOnly = false;

		[EditorEndFoldout()]
		[EditorSeparator]
		public MouseTouchControl targetMouseTouch = new MouseTouchControl();

		[EditorFoldout("Default Target Raycast Settings", "Abilities and items with a 'None' target range " +
			"can optionally use raycast target selection to set a target (position).\n" +
			"This can e.g. be used for area of effect type of abilities.\n" +
			"Individual abilities and items can replace the default raycast settings.", "")]
		[EditorEndFoldout(2)]
		public TargetRaycastSetting defaultTargetRaycast = new TargetRaycastSetting();


		// group targets
		[EditorFoldout("Group Target Settings", "Group targets are available to all combatants of a group.", "")]
		[EditorEndFoldout]
		[EditorArray("Add Target Settings", "Adds target settings.", "",
			"Remove", "Removes this target settings.", "", isMove=true, isCopy=true,
			foldout=true, foldoutText=new string[] {
				"Target Settings", "Define the input keys and targets that can be selected.", ""
		})]
		public TargetSelection[] groupTargetSelection = new TargetSelection[0];


		// individual targets
		[EditorFoldout("Individual Target Settings", "Individual targets are only available to the combatant who selected them.", "")]
		[EditorEndFoldout]
		[EditorArray("Add Target Settings", "Adds target settings.", "",
			"Remove", "Removes this target settings.", "", isMove=true, isCopy=true,
			foldout=true, foldoutText=new string[] {
				"Target Settings", "Define the input keys and targets that can be selected.", ""
		})]
		public TargetSelection[] individualTargetSelection = new TargetSelection[0];


		// target dialogues
		// target information dialogue
		[EditorFoldout("Target Dialogues", "Define optional target information or confirmation dialogues.", "",
			"Target Information Dialogue", "Optionally display status changes that " +
			"will happen to the user and targets of an ability/item.", "")]
		[EditorEndFoldout]
		[EditorArray("Add Target Information", "Adds a target information dialogue.", "",
			"Remove", "Removes this target information dialogue.", "", isMove=true, isCopy=true,
			foldout=true, foldoutText=new string[] {
				"Target Information", "Displays status changes that will happen to the user and targets of an ability/item.", ""
		})]
		public TargetInformationControl[] targetInformation = new TargetInformationControl[0];


		// target confirmation dialogue
		[EditorHelp("Show Target Confirmation", "Show a target confirmation dialogue after " +
			"selecting a target for an ability or item.\n" +
			"The ability/item will only be used when the target confirmation dialogue is accepted, " +
			"otherwise the target selection is resumed.", "")]
		[EditorFoldout("Target Confirmation Dialogue", "Optionally display a target confirmation dialogue " +
			"showing status changes that will happen to the user and targets of an ability/item.", "")]
		public bool showTargetConfirmation = false;

		[EditorSeparator]
		[EditorEndFoldout]
		[EditorCondition("showTargetConfirmation", true)]
		[EditorEndCondition]
		[EditorAutoInit]
		public TargetConfirmationControl targetConfirmation;


		// target info display
		[EditorFoldout("Target Information Layout", "Define how status change information on the " +
			"user and targets of an ability or item will be displayed.\n" +
			"This is used by the 'Target Information Dialogue' and 'Target Confirmation Dialogue' " +
			"and can optionally be overridden there.", "",
			initialState=false)]
		[EditorEndFoldout(2)]
		public TargetInformationLayout targetInformationLayout = new TargetInformationLayout();

		public BattleTargetSettings(MakinomProjectAsset project)
		{
			this.LoadProject(project);
		}


		/*
		============================================================================
		Properties
		============================================================================
		*/
		public override string Filename
		{
			get { return "Target Settings"; }
		}


		/*
		============================================================================
		Target information functions
		============================================================================
		*/
		public virtual void ShowTargetInformation(Combatant user, List<Combatant> targets, IShortcut shortcut)
		{
			for(int i = 0; i < targetInformation.Length; i++)
			{
				this.targetInformation[i].Show(user, targets, shortcut);
			}
		}

		public virtual void CursorOverTargetInformation(Combatant combatant, bool changed)
		{
			for(int i = 0; i < targetInformation.Length; i++)
			{
				this.targetInformation[i].CombatantCursorOver(combatant, changed);
			}
		}

		public virtual void CloseTargetInformation()
		{
			for(int i = 0; i < targetInformation.Length; i++)
			{
				this.targetInformation[i].Close();
			}
		}
	}
}
