﻿
using UnityEngine;
using System.Collections.Generic;

namespace GamingIsLove.ORKFramework
{
	public enum CombatantBattleActionResult { None, Hit, Critical, Miss, Block };

	public class ActionResultsPredetermined
	{
		public bool useOnce = true;

		public int hit = 0;

		public int critical = 0;

		public int miss = 0;

		public int block = 0;

		public Dictionary<Combatant, CombatantBattleActionResult> combatantResult = new Dictionary<Combatant, CombatantBattleActionResult>();

		public ActionResultsPredetermined()
		{

		}

		public virtual void Clear()
		{
			this.combatantResult.Clear();
			this.hit = 0;
			this.critical = 0;
			this.miss = 0;
			this.block = 0;
		}


		/*
		============================================================================
		Result functions
		============================================================================
		*/
		public BattleActionResult GetResult()
		{
			if(this.critical > 0 &&
				this.critical >= this.hit &&
				this.critical >= this.miss &&
				this.critical >= this.block)
			{
				return BattleActionResult.Critical;
			}
			else if(this.miss > 0 &&
				this.miss >= this.hit &&
				this.miss >= this.critical &&
				this.miss >= this.block)
			{
				return BattleActionResult.Miss;
			}
			else if(this.block > 0 &&
				this.block >= this.hit &&
				this.block >= this.critical &&
				this.block >= this.miss)
			{
				return BattleActionResult.Block;
			}
			return BattleActionResult.Hit;
		}

		public virtual CombatantBattleActionResult GetResult(Combatant combatant)
		{
			if(this.combatantResult.ContainsKey(combatant))
			{
				return this.combatantResult[combatant];
			}
			return CombatantBattleActionResult.None;
		}

		public CombatantBattleActionResult GetResult(List<Combatant> list)
		{
			int hit = 0;
			int critical = 0;
			int miss = 0;
			int block = 0;

			for(int i = 0; i < list.Count; i++)
			{
				CombatantBattleActionResult result = this.GetResult(list[i]);
				if(CombatantBattleActionResult.Hit == result)
				{
					hit++;
				}
				else if(CombatantBattleActionResult.Critical == result)
				{
					critical++;
				}
				else if(CombatantBattleActionResult.Miss == result)
				{
					miss++;
				}
				else if(CombatantBattleActionResult.Block == result)
				{
					block++;
				}
			}

			if(critical > 0 &&
				critical >= hit &&
				critical >= miss &&
				critical >= block)
			{
				return CombatantBattleActionResult.Critical;
			}
			else if(miss > 0 &&
				miss >= hit &&
				miss >= critical &&
				miss >= block)
			{
				return CombatantBattleActionResult.Miss;
			}
			else if(block > 0 &&
				block >= hit &&
				block >= critical &&
				block >= miss)
			{
				return CombatantBattleActionResult.Block;
			}
			else if(hit > 0)
			{
				return CombatantBattleActionResult.Hit;
			}
			return CombatantBattleActionResult.None;
		}


		/*
		============================================================================
		Change functions
		============================================================================
		*/
		public virtual void Add(Combatant combatant, CombatantBattleActionResult result)
		{
			if(this.combatantResult.ContainsKey(combatant))
			{
				this.Change(this.combatantResult[combatant], -1);
				this.combatantResult[combatant] = result;
			}
			else
			{
				this.combatantResult.Add(combatant, result);
			}
			this.Change(result, 1);
		}

		protected virtual void Change(CombatantBattleActionResult result, int change)
		{
			if(CombatantBattleActionResult.Hit == result)
			{
				this.hit += change;
			}
			else if(CombatantBattleActionResult.Critical == result)
			{
				this.critical += change;
			}
			else if(CombatantBattleActionResult.Miss == result)
			{
				this.miss += change;
			}
			else if(CombatantBattleActionResult.Block == result)
			{
				this.block += change;
			}
		}


		/*
		============================================================================
		Check functions
		============================================================================
		*/
		public virtual bool HasResult(Combatant combatant)
		{
			return this.combatantResult.ContainsKey(combatant);
		}
	}
}
