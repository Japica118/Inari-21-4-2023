
using System.Collections.Generic;
using UnityEngine;
using GamingIsLove.ORKFramework.Components;
using GamingIsLove.ORKFramework.UI;
using GamingIsLove.Makinom;

namespace GamingIsLove.ORKFramework
{
	public class AbilityAction : TargetRangeAction
	{
		protected AbilityShortcut ability;

		protected bool experienceGained = false;

		public AbilityAction(Combatant user, AbilityShortcut ability)
		{
			this.user = user;
			this.ability = ability;
			this.SetTargetRange(this.ability);

			ActiveAbility activeLevel = this.ability.GetActiveLevel();
			if(activeLevel != null)
			{
				this.targetDead = activeLevel.targetSettings.isDead;
				this.targetRaycast = activeLevel.targetSettings.targetRaycast;

				if(AbilityState.CounterAttack == this.ability.State)
				{
					this.consumeTime = false;
				}
				else
				{
					this.actionCost = activeLevel.GetActionCost(
						this.user, this.ability, this.Variables, this.SelectedData);
					this.originalActionCost = this.actionCost;

					if(ORK.Battle.System != null)
					{
						ActionCost costSettings = ORK.Battle.System.settings.GetAbilityActionCostSettings(this.ability);
						if(costSettings != null &&
							costSettings.endTurn)
						{
							this.endTurnFlag = true;
						}
					}
				}
			}

			this.CheckActionAffiliation();
		}

		public override string GetName()
		{
			return this.ability != null ? this.ability.GetName() : "Ability";
		}

		public static AbilityState ToState(AbilityActionType type)
		{
			if(AbilityActionType.BaseAttack == type)
			{
				return AbilityState.BaseAttack;
			}
			else if(AbilityActionType.CounterAttack == type)
			{
				return AbilityState.CounterAttack;
			}
			return AbilityState.None;
		}

		public override bool IsType(ActionType t)
		{
			return (ActionType.Attack == t && this.ability.IsBaseAttack) ||
				(ActionType.CounterAttack == t && this.ability.IsCounterAttack) ||
				(ActionType.Ability == t && this.ability.IsAbility);
		}

		public override bool IsPriorityAction
		{
			get { return this.ability.Setting.isPriorityAction; }
		}

		public override int PriorityActionValue
		{
			get { return this.ability.Setting.priorityActionValue; }
		}

		public override IShortcut Shortcut
		{
			get { return this.ability; }
		}

		public AbilityShortcut Ability
		{
			get { return this.ability; }
		}

		public override SelectedDataHandler SelectedData
		{
			get
			{
				if(this.selectedData == null)
				{
					this.selectedData = this.ability.GetSelectedData();
				}
				return this.selectedData;
			}
			set { this.selectedData = value; }
		}

		public override void PredetermineResults(bool useOnce, List<Combatant> usedTargets)
		{
			ActiveAbility activeLevel = this.ability.GetActiveLevel();

			// get affected range targets
			usedTargets = this.GetTargetsWithAffectRange(AffectRangeType.Calculation,
				activeLevel.targetSettings, usedTargets);

			if(this.user != null &&
				(!this.user.Status.IsDead ||
					this.ability.Setting.allowDeadUser) &&
				usedTargets.Count > 0 &&
				usedTargets[0] != null)
			{
				this.predeterminedResults = activeLevel.PredetermineResults(
					this.ability, this.user, usedTargets, this.Variables, this.SelectedData);
				this.predeterminedResults.useOnce = useOnce;
			}
		}

		public override void SetTarget(Combatant t)
		{
			this.target = new List<Combatant>();
			this.target.Add(t);
			this.CheckNoneTarget(t, this.ability.GetActiveLevel().targetSettings);
		}

		public override void SetTargets(List<Combatant> t)
		{
			this.target = t;

			if(this.target != null)
			{
				TargetSettings targetSettings = this.ability.GetActiveLevel().targetSettings;
				for(int i = 0; i < this.target.Count; i++)
				{
					if(this.CheckNoneTarget(this.target[i], targetSettings))
					{
						break;
					}
				}
			}
		}

		public override bool AutoTarget(List<Combatant> preferredTargets, List<Combatant> allies, List<Combatant> enemies)
		{
			if(this.user.Status.Effects.AttackAllies)
			{
				enemies = allies;
			}
			return this.ability.GetActiveLevel().targetSettings.SetAutoTargets(this, preferredTargets, allies, enemies);
		}

		public override bool ForceFoundTargets(List<Combatant> preferredTargets, List<Combatant> allies, List<Combatant> enemies)
		{
			ActiveAbility level = this.ability.GetActiveLevel();
			if(level != null)
			{
				if(level.targetSettings.TargetSelf())
				{
					return this.AutoTarget(preferredTargets, allies, enemies);
				}
				else if(level.targetSettings.TargetEnemy())
				{
					return this.AutoTarget(preferredTargets, allies, preferredTargets);
				}
				else if(level.targetSettings.TargetAlly())
				{
					return this.AutoTarget(preferredTargets, preferredTargets, enemies);
				}
				else if(level.targetSettings.TargetAll())
				{
					return this.AutoTarget(preferredTargets, preferredTargets, preferredTargets);
				}
			}
			return false;
		}

		public override bool SetGroupTarget()
		{
			Combatant tmpTarget = this.user.Group.SelectedTargets.GetAbilityTarget(this.user, this.ability);
			if(tmpTarget != null)
			{
				if(this.ability.IsGroupTarget())
				{
					List<Combatant> targets = this.ability.GetPossibleTargets(this.user, null);
					if(targets.Contains(tmpTarget))
					{
						this.SetTargets(targets);
					}
					else
					{
						this.SetTarget(tmpTarget);
					}
				}
				else
				{
					this.SetTarget(tmpTarget);
				}
				return true;
			}
			return false;
		}

		public override bool SetIndividualTarget()
		{
			Combatant tmpTarget = this.user.SelectedTargets.GetAbilityTarget(this.user, this.ability);
			if(tmpTarget != null)
			{
				if(this.ability.IsGroupTarget())
				{
					List<Combatant> targets = this.ability.GetPossibleTargets(this.user, null);
					if(targets.Contains(tmpTarget))
					{
						this.SetTargets(targets);
					}
					else
					{
						this.SetTarget(tmpTarget);
					}
				}
				else
				{
					this.SetTarget(tmpTarget);
				}
				return true;
			}
			return false;
		}

		protected override void CreateStatusChangeInfos()
		{
			if(this.target != null &&
				this.target.Count > 0)
			{
				if(this.statusChangesTarget == null)
				{
					this.statusChangesTarget = new Dictionary<Combatant, StatusChangeInformation>();
				}

				for(int i = 0; i < this.target.Count; i++)
				{
					if(!this.statusChangesTarget.ContainsKey(this.target[i]))
					{
						this.statusChangesTarget.Add(this.target[i],
							new StatusChangeInformation(this.ability, this.user, this.target[i]));
					}
				}
			}
		}


		/*
		============================================================================
		Check functions
		============================================================================
		*/
		public override bool CanTarget(Combatant c)
		{
			return (this.user.Status.Effects.AttackAllies ||
				this.ability.CanTarget(this.user, c));
		}

		public override bool CanCancelAction()
		{
			if(this.user.Status.Effects.BlockActionCancel)
			{
				return false;
			}
			else
			{
				ActiveAbility activeLevel = this.ability.GetActiveLevel();
				return activeLevel != null ? activeLevel.cancelable : false;
			}
		}


		/*
		============================================================================
		Damage dealer functions
		============================================================================
		*/
		public override void AutoActivateUserDamageDealers(bool activate)
		{
			if(this.user != null && this.user.GameObject != null)
			{
				DamageDealer[] damage = this.user.GameObject.GetComponentsInChildren<DamageDealer>(true);
				for(int i = 0; i < damage.Length; i++)
				{
					if(damage[i].settings.CheckAutoActivate(this.user) &&
						this.CheckDamageDealer(damage[i], true))
					{
						damage[i].SetAction(activate ? this : null);

						ActiveAbility activeLevel = this.ability.GetActiveLevel();
						if(activeLevel != null)
						{
							activeLevel.ddActivation.Add(damage[i], this.user);

							if(DamageDealerAutoActivationType.Activate == this.activeAnimation.autoDamageDealers)
							{
								damage[i].SetDamageActive(activate);
							}
						}
					}
				}
			}
		}

		public override void ActivateUserDamageDealers(bool activate)
		{
			if(this.user != null && this.user.GameObject != null)
			{
				DamageDealer[] damage = this.user.GameObject.GetComponentsInChildren<DamageDealer>(true);
				for(int i = 0; i < damage.Length; i++)
				{
					if(!damage[i].settings.alwaysOn &&
						this.CheckDamageDealer(damage[i], true))
					{
						damage[i].SetAction(activate ? this : null);

						ActiveAbility activeLevel = this.ability.GetActiveLevel();
						if(activeLevel != null)
						{
							activeLevel.ddActivation.Add(damage[i], this.user);
							damage[i].SetDamageActive(activate);
						}
					}
				}
			}
		}

		public override bool CheckDamageDealer(DamageDealer dealer, bool useTags)
		{
			if(useTags &&
				dealer.settings.activationTag.Length > 0)
			{
				ActiveAbility activeLevel = this.ability.GetActiveLevel();
				if(activeLevel != null &&
					dealer.CheckTags(activeLevel.activationTags))
				{
					return true;
				}
			}
			if(this.ability.IsBaseAttack)
			{
				return dealer.settings.baseAttack;
			}
			else if(this.ability.IsCounterAttack)
			{
				return dealer.settings.counterAttack;
			}
			else
			{
				for(int i = 0; i < dealer.settings.ability.Length; i++)
				{
					if(dealer.settings.ability[i].Is(this.ability.Setting))
					{
						return true;
					}
				}
			}
			return false;
		}

		public override string[] GetActivationTags()
		{
			return this.ability.GetActiveLevel().activationTags;
		}

		public override DamageDealerActivation GetDamageDealerActivation()
		{
			return this.ability.GetActiveLevel().ddActivation;
		}


		/*
		============================================================================
		Target selection functions
		============================================================================
		*/
		public override void SetRandomTarget()
		{
			if(this.forceFoundTargets)
			{
				List<Combatant> list = new List<Combatant>();
				if(this.target != null)
				{
					list.AddRange(this.target);
					this.target = null;
				}
				if(this.outOfRange != null)
				{
					list.AddRange(this.outOfRange);
					this.outOfRange = null;
				}

				ActiveAbility level = this.ability.GetActiveLevel();
				if(level != null)
				{
					if(level.targetSettings.TargetSelf())
					{
						this.AutoTarget(list, list, list);
					}
					else if(level.targetSettings.TargetEnemy())
					{
						this.AutoTarget(list,
							ORK.Game.Combatants.Get(this.user, true, Battle.BattleRange,
								Consider.No, Consider.Ignore, Consider.Ignore, null),
							list);
					}
					else if(level.targetSettings.TargetAlly())
					{
						this.AutoTarget(list, list,
							ORK.Game.Combatants.Get(this.user, true, Battle.BattleRange,
								Consider.Yes, Consider.Ignore, Consider.Ignore, null));
					}
					else if(level.targetSettings.TargetAll())
					{
						this.AutoTarget(list, list, list);
					}
				}
			}
			else
			{
				List<Combatant> allies = new List<Combatant>();
				List<Combatant> enemies = new List<Combatant>();
				ORK.Game.Combatants.Get(ref allies, ref enemies, this.user, true,
					Battle.BattleRange, Consider.Ignore, Consider.Ignore, null);
				this.AutoTarget(null, allies, enemies);
			}
		}

		public override bool TargetNone()
		{
			return this.ability.IsNoneTarget();
		}


		/*
		============================================================================
		Range functions
		============================================================================
		*/
		public override bool InRange(Combatant t)
		{
			if(this.user != null && t != null &&
				!this.ability.InRange(this.user, t))
			{
				return false;
			}
			return true;
		}

		public override bool InRange(Vector3 position)
		{
			if(this.user != null)
			{
				return this.ability.GetActiveLevel().targetSettings.InUseRange(this.user, position, this.ability);
			}
			return true;
		}

		public override void ClampToRange(ref Vector3 position)
		{
			if(this.user != null)
			{
				this.ability.GetActiveLevel().targetSettings.ClampToUseRange(this.user, ref position, this.ability);
			}
		}


		/*
		============================================================================
		Action performing functions
		============================================================================
		*/
		public override bool CanUse()
		{
			return this.ignoreCanUse ||
				(this.user != null && !this.user.Status.IsDead &&
				this.ability.CanUse(this.user, false, !this.userConsumeDone) &&
				(this.ability.IsNoneTarget() || this.target.Count > 0));
		}

		public override void ActionAdded()
		{
			if(ORK.ConsoleSettings.displayActions)
			{
				this.CreateStatusChangeInfos();

				if(this.ability.Setting.ownConsoleAddAction)
				{
					this.ability.Setting.consoleAddAction.Print(this.user, this.target,
						this.statusChangesTarget, this.ability);
				}
				else if(this.ability.Setting.TypeData != null &&
					this.ability.Setting.TypeData.ownConsoleAddAction)
				{
					this.ability.Setting.TypeData.consoleAddAction.Print(this.user, this.target,
						this.statusChangesTarget, this.ability);
				}
				else
				{
					ORK.ConsoleSettings.actionAddAbility.Print(this.user, this.target,
						this.statusChangesTarget, this.ability);
				}
			}

			if(this.ability != null)
			{
				ActiveAbility activeLevel = this.ability.GetActiveLevel();

				if(UseCostAutoConsumeType.OnSelection == activeLevel.autoConsumeType)
				{
					this.ConsumeCosts();
				}
			}
		}

		protected override void ActionStartSetup()
		{
			ActionInfoNotifications notification = AlliedStateSettings<ActionInfoNotifications>.GetForCombatant(
				this.user, ORK.BattleTexts.actionInfos);
			if(notification != null)
			{
				if(this.ability.Setting.ownBattleInfoText)
				{
					ActionInfo info = AlliedStateSettings<ActionInfo>.GetForCombatant(this.user, this.ability.Setting.actionInfo);
					if(info != null)
					{
						info.Show(notification, this.user, this.ability);
					}
				}
				else if(this.ability.Setting.TypeData != null &&
					this.ability.Setting.TypeData.ownBattleInfoText)
				{
					ActionInfo info = AlliedStateSettings<ActionInfo>.GetForCombatant(this.user, this.ability.Setting.TypeData.actionInfo);
					if(info != null)
					{
						info.Show(notification, this.user, this.ability);
					}
				}
				else if(this.ability.IsBaseAttack)
				{
					notification.attackInfo.Show(notification, this.user, this.ability);
				}
				else if(this.ability.IsCounterAttack)
				{
					notification.counterInfo.Show(notification, this.user, this.ability);
				}
				else
				{
					notification.abilityInfo.Show(notification, this.user, this.ability);
				}
			}

			if(ORK.ConsoleSettings.displayActions)
			{
				this.CreateStatusChangeInfos();

				if(this.ability.Setting.ownConsoleAction)
				{
					this.ability.Setting.consoleAction.Print(this.user, this.target,
						this.statusChangesTarget, this.ability);
				}
				else if(this.ability.Setting.TypeData != null &&
					this.ability.Setting.TypeData.ownConsoleAction)
				{
					this.ability.Setting.TypeData.consoleAction.Print(this.user, this.target,
						this.statusChangesTarget, this.ability);
				}
				else
				{
					ORK.ConsoleSettings.actionAbility.Print(this.user, this.target,
						this.statusChangesTarget, this.ability);
				}
			}

			ActiveAbility activeLevel = this.ability.GetActiveLevel();

			activeLevel.SetReuseAfter(this.user, this.ability, this.Variables, this.SelectedData, ActionReuseStartType.Start, false);

			// get affected range targets
			this.target = this.GetTargetsWithAffectRange(AffectRangeType.Execution,
				activeLevel.targetSettings, this.target);

			if(UseCostAutoConsumeType.Always == activeLevel.autoConsumeType ||
				(UseCostAutoConsumeType.WithoutTargets == activeLevel.autoConsumeType &&
					(this.target == null || this.target.Count == 0)))
			{
				this.ConsumeCosts();
			}
			if(activeLevel.useStartAnimation)
			{
				this.user.GetBattleAnimation(BattleAnimationType.AbilityStart, ref this.schematics);
			}
			if(!this.user.GetAbilityAnimation(this.ability, this.ability.UseLevel, ref this.schematics))
			{
				activeLevel.battleAnimation.GetBattleAnimation(this.user, ref this.schematics);
			}
			if(activeLevel.useEndAnimation)
			{
				this.user.GetBattleAnimation(BattleAnimationType.AbilityEnd, ref this.schematics);
			}
		}

		public override void Calculate(List<Combatant> ts, float damageFactor, bool animate, GameObject flyingTextTargetObject, ActionCalculationFinished notify)
		{
			ActiveAbility activeLevel = this.ability.GetActiveLevel();

			// get affected range targets
			ts = this.GetTargetsWithAffectRange(AffectRangeType.Calculation,
				activeLevel.targetSettings, ts);

			if(!this.blockBattleCamera &&
				!ORK.BattleCamera.IsNone &&
				!ORK.BattleCamera.latestDamageActionBlock.IsBlocked(this))
			{
				if(ts.Count == 1 &&
					ts[0] != null &&
					ts[0].GameObject != null)
				{
					ORK.BattleCamera.SetLatestDamage(
						this.user.GameObject != null ? this.user.GameObject.transform : null,
						ts[0].GameObject.transform);
				}
				else if(ts.Count > 1)
				{
					ORK.BattleCamera.SetLatestDamage(
						this.user.GameObject != null ? this.user.GameObject.transform : null,
						ORK.Battle.GetGroupCenter(ts).transform);
				}
			}

			if(this.user != null &&
				(!this.user.Status.IsDead ||
					this.ability.Setting.allowDeadUser) &&
				ts.Count > 0 &&
				ts[0] != null)
			{
				this.CheckBestiary(ts);

				bool doUseCosts = !this.userConsumeDone;
				this.userConsumeDone = true;

				// use level up only once
				if(!this.experienceGained)
				{
					// ability
					if(this.user.Abilities.CanGetUseExperience(this.ability))
					{
						this.ability.UsesExperience(this.user, 1);
					}
					// equipment
					if(this.ability.IsBaseAttack ||
						this.ability.IsCounterAttack)
					{
						for(int i = 0; i < ORK.EquipmentSlots.Count; i++)
						{
							if(this.user.Equipment[i].Equipped &&
								this.user.Equipment[i].Contribute)
							{
								this.user.Equipment[i].Equipment.UsesExperience(this.user, 1);
							}
						}
					}
					this.experienceGained = true;
				}

				activeLevel.UseAccess(this.ability, this.user, ts, flyingTextTargetObject, true, animate,
					!this.ability.IsCounterAttack, doUseCosts, damageFactor, this.damageMultiplier,
					this.Variables, this.SelectedData,
					delegate (ActionResults results)
					{
						if(results != null)
						{
							results.GetCounter(this.counter);
						}
						if(notify != null)
						{
							notify(results);
						}
					}, this);
			}
			else if(notify != null)
			{
				notify(null);
			}
		}

		public override void ConsumeCosts()
		{
			if(this.ability != null && this.user != null)
			{
				ActiveAbility activeLevel = this.ability.GetActiveLevel();
				if(activeLevel != null)
				{
					activeLevel.UseCosts(this.user, this.ability,
						this.Variables, this.SelectedData, true);
				}
			}
			this.userConsumeDone = true;
		}

		protected override void ActionEndSetup()
		{
			// set last ability
			this.user.Abilities.LastAbility = this.ability.Setting;

			// update base attack index
			if(this.ability.IsBaseAttack)
			{
				if(this.isStopped &&
					(this.user.Setting.ownBaseAttack ?
						this.user.Setting.actionStopResetsAttackIndex :
						ORK.Combatants.actionStopResetsAttackIndex))
				{
					this.user.Abilities.ResetBaseAttack();
				}
				else
				{
					this.user.Abilities.NextBaseAttack();
				}
			}

			// set reuse and delay
			ActiveAbility lvl = this.ability.GetActiveLevel();
			if(lvl != null)
			{
				lvl.SetReuseAfter(this.user, this.ability, this.Variables, this.SelectedData, ActionReuseStartType.End, false);
			}
		}
	}
}
