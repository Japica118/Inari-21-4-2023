
using UnityEngine;
using GamingIsLove.ORKFramework.AI;
using GamingIsLove.ORKFramework.Components;
using System.Collections.Generic;
using GamingIsLove.Makinom;
using GamingIsLove.Makinom.Schematics;

namespace GamingIsLove.ORKFramework
{
	public delegate void ActionFinished(BaseAction action);

	public delegate void ActionCalculationFinished(ActionResults results);

	public abstract class BaseAction : ISchematicStarter
	{
		protected CombatantAffiliationType actionAffiliation = CombatantAffiliationType.Player;

		protected Combatant user;

		public bool forceFoundTargets = false;

		public bool moveToTarget = false;

		public bool blockBattleCamera = false;

		public List<Combatant> target;

		public List<Combatant> outOfRange;

		public List<Combatant> counter = new List<Combatant>();

		public ActionFinished finishedCallback;

		protected GridPath gridPath;


		// status previews
		protected Dictionary<Combatant, StatusChangeInformation> statusChangesTarget;

		protected ActionResultsPredetermined predeterminedResults;


		// casting
		protected CastTime castTimeSetting;

		protected float castTime = -2;

		protected float castTimeMax = -1;

		protected bool isCasted = false;


		// schematics
		protected List<KeyValuePair<BattleAnimation, Schematic>> schematics;

		protected BattleAnimation activeAnimation;

		protected Schematic activeSchematic;

		protected VariableHandler variableHandler;

		protected SelectedDataHandler selectedData;

		protected bool isStopped = false;


		// sub actions
		protected List<BaseAction> subAction;

		public ActionFinished subActionFinishedCallback;


		// settings
		protected bool userConsumeDone = false;

		protected bool ignoreCanUse = false;

		protected Consider targetDead = Consider.No;

		protected bool consumeTime = true;

		public bool autoAttackFlag = false;

		protected float actionCost = 0;

		protected float originalActionCost = 0;

		protected bool tooltipDisplayed = false;


		// turn based battles
		public bool isPerforming = false;

		public bool notifiedFinished = false;

		public bool endTurnFlag = false;


		// phase battles
		public bool endPhaseFlag = false;


		// raycast target
		public TargetRaycast targetRaycast;

		public bool rayTargetSet = false;

		public Vector3 rayPoint = Vector3.zero;

		public bool rayObjectCreated = false;

		public GameObject rayObject = null;


		// from schematic
		public float damageMultiplier = 1;


		/*
		============================================================================
		Helper functions
		============================================================================
		*/
		public abstract bool IsType(ActionType t);

		public virtual Combatant User
		{
			get { return this.user; }
		}

		public virtual bool IsPriorityAction
		{
			get { return false; }
		}

		public virtual int PriorityActionValue
		{
			get { return 0; }
		}

		public virtual IShortcut Shortcut
		{
			get { return null; }
		}

		public static AbilityAction CreateAbility(Combatant user, AbilityShortcut ability,
			int lvl, bool checkTime, bool checkUseCosts)
		{
			if(ability != null)
			{
				if(lvl == -1)
				{
					ability.SetHighestUseLevel(user);
				}
				else if(lvl >= 0)
				{
					ability.UseLevel = lvl;
				}
				if(!ability.IsUseable(UseableIn.None) &&
					ability.CanUse(user, checkTime ? !ability.IsCounterAttack : false, checkUseCosts))
				{
					return new AbilityAction(user, ability);
				}
			}
			return null;
		}

		public virtual string GetName()
		{
			return "";
		}

		public virtual float ActionCost
		{
			get { return this.actionCost; }
			set { this.actionCost = value; }
		}

		public virtual float OriginalActionCost
		{
			get { return this.originalActionCost; }
			set { this.originalActionCost = value; }
		}

		public virtual void ConsumeActionCostPart(float cost)
		{
			this.originalActionCost -= cost;
			this.user.Battle.UsedActionBar -= cost;
			if(this.consumeTime)
			{
				this.actionCost -= cost;
				this.user.Battle.ActionBar -= cost;
			}
		}

		public virtual bool ConsumeTime
		{
			get { return this.consumeTime; }
			set { this.consumeTime = value; }
		}

		public virtual GridPath GridPath
		{
			get { return this.gridPath; }
			set
			{
				if(this.gridPath != null)
				{
					this.gridPath.Clear();
				}
				this.gridPath = value;
			}
		}

		public virtual void InitGridPath(List<GridPath.PathCell> path,
			float moveCost, float actionCost, int statusValueCost)
		{
			this.GridPath = new GridPath(this, this.user, path, moveCost, statusValueCost);
			this.actionCost += actionCost;
			this.originalActionCost += actionCost;
		}


		public virtual CombatantAffiliationType ActionAffiliation
		{
			get { return this.actionAffiliation; }
		}

		public virtual void CheckActionAffiliation()
		{
			if(this.user.IsPlayerControlled())
			{
				this.actionAffiliation = CombatantAffiliationType.Player;
			}
			else if(this.user.IsEnemy(ORK.Game.ActiveGroup.Leader))
			{
				this.actionAffiliation = CombatantAffiliationType.Enemy;
			}
			else
			{
				this.actionAffiliation = CombatantAffiliationType.Ally;
			}
		}

		public virtual ActionResultsPredetermined PredeterminedResults
		{
			get { return this.predeterminedResults; }
			set { this.predeterminedResults = value; }
		}

		public virtual void PredetermineResults(bool useOnce, List<Combatant> usedTargets)
		{

		}

		public virtual void SetTarget(Combatant t)
		{

		}

		public virtual void SetTargets(List<Combatant> t)
		{

		}

		public virtual bool AutoTarget(List<Combatant> preferredTargets, List<Combatant> allies, List<Combatant> enemies)
		{
			return false;
		}

		public virtual bool ForceFoundTargets(List<Combatant> preferredTargets, List<Combatant> allies, List<Combatant> enemies)
		{
			return false;
		}

		public virtual bool SetGroupTarget()
		{
			return false;
		}

		public virtual bool SetIndividualTarget()
		{
			return false;
		}

		public virtual bool ConsumeDone
		{
			get { return this.userConsumeDone; }
			set { this.userConsumeDone = value; }
		}

		public virtual void ConsumeCosts()
		{
			this.userConsumeDone = true;
		}

		public virtual VariableHandler Variables
		{
			get
			{
				if(this.variableHandler == null)
				{
					this.variableHandler = new VariableHandler();
				}
				return this.variableHandler;
			}
			set { this.variableHandler = value; }
		}

		public virtual SelectedDataHandler SelectedData
		{
			get
			{
				if(this.selectedData == null)
				{
					this.selectedData = SelectedDataHelper.CreateSelectedData(
						SelectedDataHelper.Action, this.Shortcut);
				}
				return this.selectedData;
			}
			set { this.selectedData = value; }
		}

		protected virtual void CreateStatusChangeInfos()
		{

		}


		/*
		============================================================================
		Check functions
		============================================================================
		*/
		public virtual Consider TargetDead
		{
			get { return this.targetDead; }
		}

		public virtual bool CanTarget(Combatant combatant)
		{
			return this.user == combatant;
		}

		public virtual bool CanCancelAction()
		{
			return false;
		}


		/*
		============================================================================
		Casting functions
		============================================================================
		*/
		public virtual float CastTime
		{
			get { return this.castTime; }
			set { this.castTime = value; }
		}

		public virtual float CastTimeMax
		{
			get { return this.castTimeMax; }
		}

		public virtual bool CastMove
		{
			get { return this.castTimeSetting != null ? this.castTimeSetting.castMove : false; }
		}

		public virtual bool IsCasted
		{
			get { return this.isCasted; }
			set { this.isCasted = value; }
		}

		public virtual bool IsCasting()
		{
			ICastTime shortcut = this.Shortcut as ICastTime;
			if(!this.isCasted &&
				this.castTime < 0 &&
				shortcut != null)
			{
				this.castTimeSetting = shortcut.GetCastTimeSetting(this.user);
				if(this.castTimeSetting != null)
				{
					float time = this.castTimeSetting.GetCastTime(this.user, this.SelectedData);
					if(time > 0)
					{
						this.castTimeMax = time;
						this.castTime = 0;
						if(this.user != null)
						{
							ORK.Battle.Actions.AddCasting(this);
							this.user.Actions.CastAction(this);
							this.castTimeSetting.PlayCastAudio(this.user);
							this.castTimeSetting.StartCastingSchematic(this.user, this.SelectedData);

							if(ORK.ConsoleSettings.displayActions)
							{
								this.CreateStatusChangeInfos();
								shortcut.ShowCastingConsoleText(
									this.user, this.target, this.statusChangesTarget);
							}
						}
						return true;
					}
				}
			}
			return false;
		}

		public virtual bool CanCancelCasting()
		{
			if(this.castTimeSetting != null &&
				!this.user.Status.Effects.BlockCastCancel)
			{
				return this.castTimeSetting.cancelable;
			}
			return false;
		}

		public virtual bool CancelCasting()
		{
			ICastTime shortcut = this.Shortcut as ICastTime;
			if(shortcut != null)
			{
				if(!this.isCasted &&
					this.castTime > 0 &&
					this.castTimeSetting != null &&
					this.castTimeSetting.cancelable)
				{
					ORK.Battle.Actions.RemoveCasting(this);
					this.castTimeSetting.CancelCastingSchematic(this.user, this.SelectedData);
					if(ORK.ConsoleSettings.displayActions)
					{
						this.CreateStatusChangeInfos();
						shortcut.ShowCancelCastingConsoleText(
							this.user, this.target, this.statusChangesTarget);
					}
					return true;
				}
			}
			return false;
		}


		/*
		============================================================================
		Target selection functions
		============================================================================
		*/
		public virtual void SetRandomTarget()
		{

		}

		public virtual void UpdateTargets()
		{
			bool changed = false;
			if(this.target == null)
			{
				this.target = new List<Combatant>();
			}

			List<Combatant> removed = new List<Combatant>();
			for(int i = 0; i < this.target.Count; i++)
			{
				if(!this.InRange(this.target[i]))
				{
					changed = true;
					removed.Add(this.target[i]);
					this.target.RemoveAt(i--);
				}
			}

			if(this.outOfRange != null)
			{
				for(int i = 0; i < this.outOfRange.Count; i++)
				{
					if(this.InRange(this.outOfRange[i]))
					{
						changed = true;
						this.target.Add(this.outOfRange[i]);
						this.outOfRange.RemoveAt(i--);
					}
				}
			}

			if(removed.Count > 0)
			{
				if(this.outOfRange == null)
				{
					this.outOfRange = new List<Combatant>();
				}
				this.outOfRange.AddRange(removed);
			}

			if(changed)
			{
				List<Combatant> newTargets = new List<Combatant>(this.target);
				this.AutoTarget(newTargets, newTargets, newTargets);
				if(this.target.Count == 0 &&
					newTargets.Count > 0)
				{
					this.target.AddRange(newTargets);
				}
			}
		}

		public virtual void PerformCheckTargets()
		{
			this.UpdateTargets();
			if(this.target != null && target.Count > 0)
			{
				for(int i = 0; i < this.target.Count; i++)
				{
					if(this.target[i] == null ||
						!TargetHelper.CheckDeath(this.target[i], this.targetDead))
					{
						this.target.RemoveAt(i--);
					}
				}
			}

			if(!this.rayTargetSet && (this.target == null || this.target.Count == 0))
			{
				this.SetRandomTarget();
			}
		}

		public virtual bool TargetNone()
		{
			return false;
		}

		public virtual bool HasTargets()
		{
			return this.HasTargets(this.target);
		}

		public virtual bool HasTargets(List<Combatant> list)
		{
			if(!this.TargetNone() &&
				list != null && list.Count > 0)
			{
				for(int i = 0; i < list.Count; i++)
				{
					if(TargetHelper.CheckDeath(list[i], this.targetDead))
					{
						return true;
					}
				}
				return false;
			}
			return true;
		}

		public virtual bool HasOutOfRangeTargets()
		{
			return this.outOfRange != null && this.outOfRange.Count > 0;
		}

		public virtual Combatant GetNearestTarget()
		{
			Combatant nearest = null;
			if(this.target != null && this.target.Count > 0)
			{
				nearest = TargetHelper.GetNearestTarget(this.user, this.target, this.targetDead);
			}
			if(nearest == null && this.outOfRange != null && this.outOfRange.Count > 0)
			{
				nearest = TargetHelper.GetNearestTarget(this.user, this.outOfRange, this.targetDead);
			}
			return nearest;
		}

		public virtual void CheckTargetAggressive()
		{
			if(this.target != null && this.target.Count > 0)
			{
				for(int i = 0; i < this.target.Count; i++)
				{
					if(this.target[i] != null && this.user.IsEnemy(this.target[i]))
					{
						ORK.Access.Combatant.CheckAggressive(this.target[i], AggressionType.OnSelection, this.user);
					}
				}
			}
		}

		public virtual void CheckBestiary(List<Combatant> list)
		{
			if(this.user.IsPlayerControlled())
			{
				for(int i = 0; i < list.Count; i++)
				{
					ORK.Game.Bestiary.Attack(list[i]);
				}
			}
			else if(this.user.IsEnemy(ORK.Game.ActiveGroup.Leader))
			{
				for(int i = 0; i < list.Count; i++)
				{
					if(list[i].IsPlayerControlled())
					{
						ORK.Game.Bestiary.AttackedBy(this.user);
					}
				}
			}
		}

		public virtual List<Combatant> GetTargetsWithAffectRange(AffectRangeType type,
			TargetSettings targetSettings, List<Combatant> targets)
		{
			if(targetSettings.CheckAffectRangeType(type))
			{
				if(this.rayObject != null &&
					ORK.Battle.Grid != null &&
					targetSettings.IsNoneTarget() &&
					targetSettings.noneSelectGridCell)
				{
					BattleGridCellComponent originCell = this.rayObject.GetComponent<BattleGridCellComponent>();
					if(originCell != null)
					{
						List<BattleGridCellComponent> affectRangeCells = new List<BattleGridCellComponent>();
						targetSettings.GetAffectRangeCells(this.user, originCell,
							this.Shortcut as IVariableSource, ref affectRangeCells, null);
						for(int i = 0; i < affectRangeCells.Count; i++)
						{
							if(affectRangeCells[i] != null &&
								!affectRangeCells[i].IsEmpty)
							{
								affectRangeCells[i].GetCombatants(ref targets, this.CanTarget);
							}
						}
					}
				}
				else
				{
					targets = targetSettings.GetInAffectRange(this.user, targets,
						this.Shortcut as IVariableSource);
				}
			}
			return targets;
		}

		protected virtual bool CheckNoneTarget(Combatant target, TargetSettings targetSettings)
		{
			if(targetSettings.IsNoneTarget() &&
				(targetSettings.targetRaycast.IsActive ||
					(ORK.Battle.Grid != null &&
						targetSettings.noneSelectGridCell)))
			{
				if(!this.rayTargetSet &&
					target != null)
				{
					if(ORK.Battle.Grid != null &&
						targetSettings.noneSelectGridCell)
					{
						if(target.Grid.Cell != null)
						{
							this.rayObject = target.Grid.Cell.gameObject;
							this.rayTargetSet = true;
							return true;
						}
					}
					else if(target.GameObject != null)
					{
						this.rayObject = target.GameObject;
						this.rayTargetSet = true;
						return true;
					}
				}
				return false;
			}
			return true;
		}

		public virtual void CheckCanTarget()
		{
			if(this.target != null)
			{
				for(int i = 0; i < this.target.Count; i++)
				{
					if(!this.CanTarget(this.target[i]))
					{
						this.target.RemoveAt(i--);
					}
				}
			}
			if(this.outOfRange != null)
			{
				for(int i = 0; i < this.outOfRange.Count; i++)
				{
					if(!this.CanTarget(this.outOfRange[i]))
					{
						this.outOfRange.RemoveAt(i--);
					}
				}
			}
		}


		/*
		============================================================================
		Range functions
		============================================================================
		*/
		public virtual bool InRange()
		{
			return this.TargetNone() || this.InRange(this.GetNearestTarget());
		}

		public virtual bool InRange(Combatant t)
		{
			return true;
		}

		public virtual bool InRange(Vector3 position)
		{
			return true;
		}

		public virtual void ClampToRange(ref Vector3 position)
		{

		}

		public virtual bool InBattleRange()
		{
			if(this.user != null)
			{
				if(this.target != null && this.target.Count > 0)
				{
					for(int i = 0; i < this.target.Count; i++)
					{
						if(Battle.BattleRange.InRange(this.user.GameObject, this.target[i].GameObject))
						{
							return true;
						}
					}
				}
				if(this.outOfRange != null && this.outOfRange.Count > 0)
				{
					for(int i = 0; i < this.outOfRange.Count; i++)
					{
						if(Battle.BattleRange.InRange(this.user.GameObject, this.outOfRange[i].GameObject))
						{
							return true;
						}
					}
				}
			}
			return false;
		}


		/*
		============================================================================
		Move AI functions
		============================================================================
		*/
		public virtual void MoveAITick()
		{
			if(this.moveToTarget &&
				this.user.Object.MoveAI != null &&
				ORK.Battle.CanUseMoveAI(this.user))
			{
				this.UpdateTargets();
				if(this.InRange() &&
					this.user.Object.MoveAI.ReachedActionTarget())
				{
					this.user.Object.MoveAI.Stop();
					this.moveToTarget = false;
				}
			}
		}


		/*
		============================================================================
		Action performing functions
		============================================================================
		*/
		protected virtual void PlayNextSchematic()
		{
			KeyValuePair<BattleAnimation, Schematic> next = this.schematics[0];
			if(this.activeSchematic != null)
			{
				next.Value.SetInitialCameraPosition(this.activeSchematic.InitialCamParent,
					this.activeSchematic.InitialCamPosition, this.activeSchematic.InitialCamRotation,
					this.activeSchematic.InitialFieldOfView);
			}
			else if(this.rayTargetSet &&
				this.rayObject == null)
			{
				this.rayObjectCreated = true;
				this.rayObject = new GameObject("_RaycastTargetPosition");
				this.rayObject.transform.position = this.rayPoint;
			}
			this.activeAnimation = next.Key;
			this.activeSchematic = next.Value;
			this.activeSchematic.Variables = this.Variables;
			this.activeSchematic.SelectedData = this.SelectedData;
			this.schematics.RemoveAt(0);

			if(DamageDealerAutoActivationType.None != this.activeAnimation.autoDamageDealers)
			{
				this.AutoActivateUserDamageDealers(true);
			}
			if(this.activeAnimation.blockMoveAI &&
				this.user.Object.MoveAI != null)
			{
				this.user.Object.MoveAI.Blocked = true;
			}
			if(this.isStopped &&
				this.activeSchematic != null)
			{
				this.activeSchematic.Stop();
			}
			if(this.rayObject != null)
			{
				if(this.target == null || this.target.Count == 0)
				{
					this.activeSchematic.PlaySchematic(this, this, this.user, this.rayObject,
						false, MachineUpdateType.Update, Maki.Control.InputID);
				}
				else
				{
					List<object> tmpTarget = new List<object>();
					tmpTarget.Add(this.rayObject);
					tmpTarget.AddRange(this.target);
					this.activeSchematic.PlaySchematic(this, this, this.user, tmpTarget,
						false, MachineUpdateType.Update, Maki.Control.InputID);
				}
			}
			else
			{
				this.activeSchematic.PlaySchematic(this, this, this.user, this.target,
					false, MachineUpdateType.Update, Maki.Control.InputID);
			}
		}

		public virtual bool IgnoreCanUse
		{
			get { return this.ignoreCanUse; }
			set { this.ignoreCanUse = value; }
		}

		public virtual bool CanUse()
		{
			return this.ignoreCanUse || this.user != null;
		}

		public virtual void ActionAdded()
		{

		}

		// setup action stuff, show info, get schematics
		protected abstract void ActionStartSetup();

		public virtual void PerformAction()
		{
			// add control blocks
			ORK.Battle.DoAllActionsBlock(1);
			if(ORK.Game.PlayerHandler.IsPlayer(this.user))
			{
				ORK.Battle.DoPlayerActionsBlock(1);
			}
			ORK.Battle.AllowPlayerTurnControl(-1, this.user, AllowTurnControl.WhileInAction);

			ORK.Battle.Actions.AddActive(this);
			this.PerformCheckTargets();
			this.CheckActionAffiliation();

			if(this.CanUse())
			{
				// check target aggression
				if(this.target != null && this.target.Count > 0)
				{
					for(int i = 0; i < this.target.Count; i++)
					{
						if(this.target[i] != null && this.user.IsEnemy(this.target[i]))
						{
							ORK.Access.Combatant.CheckAggressive(this.target[i], AggressionType.OnAction, this.user);
							ORK.Access.Combatant.SetAttackedBy(this.target[i], this.user, true);
						}
					}
				}

				// base setup
				if(this.IsType(ActionType.Ability) ||
					this.IsType(ActionType.Attack) ||
					this.IsType(ActionType.Item))
				{
					this.user.Battle.SetLastTargets(this.target);
				}
				this.user.Actions.Current = this;
				this.user.Actions.ActionState = CombatantActionState.InAction;

				if(!this.blockBattleCamera &&
					!ORK.BattleCamera.IsNone &&
					this.user.GameObject != null &&
					!ORK.BattleCamera.latestUserActionBlock.IsBlocked(this))
				{
					ORK.BattleCamera.SetLatestUser(this.user.GameObject.transform, this.user.GameObject.transform);
				}
				this.schematics = new List<KeyValuePair<BattleAnimation, Schematic>>();
				this.ActionStartSetup();
				this.user.Status.Effects.CheckAction(this, true);

				// start schematic
				if(this.schematics.Count > 0)
				{
					this.user.Shortcuts.Active = this.Shortcut;
					this.ShowTooltip();
					this.PlayNextSchematic();
				}
				else
				{
					if(this.target != null && this.target.Count > 0)
					{
						this.Calculate(this.target, 1, true, null, null);
					}
					this.SchematicFinished(null);
				}
			}
			else
			{
				this.SchematicFinished(null);
			}
		}

		public virtual void CalculateSimple(float damageFactor)
		{
			this.Calculate(this.target != null ? this.target : new List<Combatant>(), damageFactor, true, null, null);
		}

		public abstract void Calculate(List<Combatant> ts, float damageFactor, bool animate, GameObject flyingTextTargetObject, ActionCalculationFinished notify);

		protected abstract void ActionEndSetup();

		public virtual void SchematicFinished(Schematic schematic)
		{
			if(this.activeAnimation != null)
			{
				if(DamageDealerAutoActivationType.None != this.activeAnimation.autoDamageDealers)
				{
					this.AutoActivateUserDamageDealers(false);
				}
				if(this.activeAnimation.blockMoveAI &&
					this.user.Object.MoveAI != null)
				{
					this.user.Object.MoveAI.Blocked = false;
				}
			}

			// get next schematic
			if(this.schematics != null && this.schematics.Count > 0)
			{
				this.PlayNextSchematic();
			}
			// end action if no sub actions are running
			else
			{
				this.activeAnimation = null;
				this.activeSchematic = null;

				if(this.subAction == null || this.subAction.Count == 0)
				{
					// remove control blocks
					ORK.Battle.DoAllActionsBlock(-1);
					if(ORK.Game.PlayerHandler.IsPlayer(this.user))
					{
						ORK.Battle.DoPlayerActionsBlock(-1);
					}
					ORK.Battle.AllowPlayerTurnControl(1, this.user, AllowTurnControl.WhileInAction);

					if(this.rayObject != null &&
						this.rayObjectCreated)
					{
						UnityWrapper.Destroy(this.rayObject);
					}

					if(this.endPhaseFlag)
					{
						ORK.Battle.System.settings.ClearCurrentFaction();
					}

					if(this.user != null)
					{
						this.ActionEndSetup();

						if(this.gridPath != null)
						{
							if(this.user.Status.IsDead)
							{
								this.gridPath.Clear();
							}
							else
							{
								this.gridPath.End();
							}
							this.gridPath = null;
						}

						this.user.Status.Effects.CheckAction(this, false);

						this.user.Actions.CheckActionCombos(this);

						this.user.Shortcuts.Active = null;
						this.RemoveTooltip();

						if(!this.user.Status.IsDead &&
							!this.autoAttackFlag &&
							ORK.Battle.System != null)
						{
							ORK.Battle.System.settings.EndCombatantAction(this);
						}

						if(!ORK.Battle.IsRealTime())
						{
							for(int i = 0; i < this.counter.Count; i++)
							{
								if(this.counter[i] != null &&
									this.counter[i].Actions.ActionState == CombatantActionState.Available)
								{
									BaseAction counterAction = new AbilityAction(
										this.counter[i], this.counter[i].Abilities.GetCounterAttack());
									counterAction.SetTarget(this.user);
									ORK.Battle.Actions.UnshiftAccess(counterAction);
								}
							}
						}

						if(this.user.Actions.Current == this)
						{
							this.user.Actions.Current = null;
						}
						this.user.Actions.ActionState = CombatantActionState.EndingAction;

						if(this.endTurnFlag ||
							((ORK.Battle.IsActiveTime() || ORK.Battle.IsRealTime()) &&
								!this.IsType(ActionType.CounterAttack) &&
								this.user.Battle.CanEndTurn))
						{
							this.user.Battle.EndTurn(this.TurnEndCallback);
						}
						else
						{
							this.TurnEndCallback();
						}
					}
					else
					{
						ORK.Battle.Actions.RemoveActive(this);
						ORK.Battle.CheckBattleEnd();
						if(this.finishedCallback != null)
						{
							this.finishedCallback(this);
						}
						else
						{
							ORK.Battle.Actions.Finished(this);
						}
					}
				}
			}
		}

		protected virtual void TurnEndCallback()
		{
			this.user.Actions.ActionState = CombatantActionState.Available;

			bool noActionsLeft = true;
			if(!this.IsType(ActionType.CounterAttack))
			{
				noActionsLeft = !this.user.Actions.DequeueAction();
			}

			if(noActionsLeft &&
				!this.IsType(ActionType.Death) &&
				ORK.Battle.CanUseMoveAI(this.user))
			{
				this.user.Object.MoveAI.ActionFinished(this.target);
			}

			ORK.Battle.Actions.RemoveActive(this);
			ORK.Battle.CheckBattleEnd();
			if(this.finishedCallback != null)
			{
				this.finishedCallback(this);
			}
			else
			{
				ORK.Battle.Actions.Finished(this);
			}
		}

		public virtual void StopAction()
		{
			if(this.activeSchematic != null)
			{
				this.isStopped = true;
				this.activeSchematic.Stop();

				if(this.subAction != null)
				{
					for(int i = 0; i < this.subAction.Count; i++)
					{
						this.subAction[i].StopAction();
					}
				}
			}
		}

		public virtual void ClearSchematics()
		{
			if(this.schematics != null &&
				this.schematics.Count > 0)
			{
				this.schematics.Clear();
			}
		}


		/*
		============================================================================
		Damage dealer functions
		============================================================================
		*/
		public virtual void AutoActivateUserDamageDealers(bool activate)
		{

		}

		public virtual void ActivateUserDamageDealers(bool activate)
		{

		}

		public virtual bool CheckDamageDealer(DamageDealer dealer, bool useTags)
		{
			return false;
		}

		public virtual string[] GetActivationTags()
		{
			return new string[0];
		}

		public virtual DamageDealerActivation GetDamageDealerActivation()
		{
			return null;
		}


		/*
		============================================================================
		Sub action functions
		============================================================================
		*/
		public virtual void AddSubAction(BaseAction action, bool shareVariables, bool shareSelectedData)
		{
			if(this.subAction == null)
			{
				this.subAction = new List<BaseAction>();
			}

			if(shareVariables)
			{
				action.Variables = this.Variables;
			}
			if(shareSelectedData)
			{
				action.SelectedData = this.SelectedData;
			}
			action.finishedCallback = this.SubActionFinished;
			this.subAction.Add(action);
			action.PerformAction();
		}

		public virtual void SubActionFinished(BaseAction action)
		{
			if(this.subAction != null &&
				this.subAction.Contains(action))
			{
				this.subAction.Remove(action);

				if(action.subActionFinishedCallback != null)
				{
					action.subActionFinishedCallback(action);
				}

				if(this.subAction.Count == 0 &&
					(this.schematics == null || this.schematics.Count == 0) &&
					(this.activeSchematic == null || !this.activeSchematic.Executing))
				{
					this.SchematicFinished(null);
				}
			}
		}


		/*
		============================================================================
		Tooltip functions
		============================================================================
		*/
		public virtual void ShowTooltip()
		{
			IShortcut shortcut = this.Shortcut;
			if(shortcut != null)
			{
				if(user.IsPlayerControlled())
				{
					if(ORK.UISettings.tooltip.playerActionTooltip &&
						(!ORK.UISettings.tooltip.noCounterTooltips ||
							!this.IsType(ActionType.CounterAttack)))
					{
						Maki.UI.Tooltip.ForceTooltip(shortcut, -1, false, false);
						this.tooltipDisplayed = true;
					}
				}
				else if(user.IsEnemy(ORK.Game.ActiveGroup.Leader))
				{
					if(ORK.UISettings.tooltip.enemyActionTooltip)
					{
						Maki.UI.Tooltip.ForceTooltip(shortcut, -1, false, false);
						this.tooltipDisplayed = true;
					}
				}
				else if(ORK.UISettings.tooltip.allyActionTooltip)
				{
					Maki.UI.Tooltip.ForceTooltip(shortcut, -1, false, false);
					this.tooltipDisplayed = true;
				}
			}
		}

		public virtual void RemoveTooltip()
		{
			if(this.tooltipDisplayed)
			{
				Maki.UI.Tooltip.RemoveForceTooltip(this.Shortcut);
			}
		}
	}
}
