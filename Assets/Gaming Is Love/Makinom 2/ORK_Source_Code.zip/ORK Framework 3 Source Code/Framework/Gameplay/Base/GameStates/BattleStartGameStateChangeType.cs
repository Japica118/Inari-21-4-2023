﻿
using UnityEngine;
using GamingIsLove.Makinom;
using System.Collections.Generic;

namespace GamingIsLove.ORKFramework
{
	[EditorSettingInfo("Battle Start", "When a battle starts.")]
	public class BattleStartGameStateChangeType : BaseGameStateChangeType
	{
		public BattleStartGameStateChangeType()
		{

		}

		public override void Register(Notify notify)
		{
			ORK.Control.BattleStart += notify;
		}
	}
}
