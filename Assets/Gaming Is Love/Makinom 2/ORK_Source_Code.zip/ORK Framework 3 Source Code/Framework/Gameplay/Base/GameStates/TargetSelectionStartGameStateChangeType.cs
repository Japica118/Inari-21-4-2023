﻿
using UnityEngine;
using GamingIsLove.Makinom;
using System.Collections.Generic;

namespace GamingIsLove.ORKFramework
{
	[EditorSettingInfo("Target Selection Start", "When player group member starts selecting targets.")]
	public class TargetSelectionStartGameStateChangeType : BaseGameStateChangeType
	{
		public TargetSelectionStartGameStateChangeType()
		{

		}

		public override void Register(Notify notify)
		{
			ORK.Battle.TargetSelectionStart += notify;
		}
	}
}
