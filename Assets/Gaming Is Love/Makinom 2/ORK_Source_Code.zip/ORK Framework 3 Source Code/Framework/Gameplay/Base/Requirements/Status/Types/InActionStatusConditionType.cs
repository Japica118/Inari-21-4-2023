﻿
using UnityEngine;
using System.Collections.Generic;
using GamingIsLove.Makinom;

namespace GamingIsLove.ORKFramework.Conditions
{
	[EditorSettingInfo("In Action", "The combatant must or mustn't be in action (e.g. performing an ability).")]
	public class InActionStatusConditionType : BaseStatusConditionType
	{
		[EditorHelp("Is In Action", "The combatant must be in action (e.g. performing an ability).\n" +
			"If disabled, the combatant mustn't be in action.", "")]
		public bool isInAction = true;

		public InActionStatusConditionType()
		{

		}

		public override string ToString()
		{
			return this.isInAction ? "in action" : "not in action";
		}


		/*
		============================================================================
		Check functions
		============================================================================
		*/
		public override bool Check(Combatant combatant)
		{
			return (combatant.Actions.ActionState != CombatantActionState.Available) == this.isInAction;
		}


		/*
		============================================================================
		Status change register functions
		============================================================================
		*/
		public override void Register(Combatant combatant, IStatusChanged notify)
		{
			combatant.Actions.ActionStateChanged += notify.CombatantActionStateChanged;
		}

		public override void Unregister(Combatant combatant, IStatusChanged notify)
		{
			combatant.Actions.ActionStateChanged -= notify.CombatantActionStateChanged;
		}

		public override void Register(Combatant combatant, Notify notify)
		{
			combatant.Actions.ActionStateChangedSimple += notify;
		}

		public override void Unregister(Combatant combatant, Notify notify)
		{
			combatant.Actions.ActionStateChangedSimple -= notify;
		}
	}
}
