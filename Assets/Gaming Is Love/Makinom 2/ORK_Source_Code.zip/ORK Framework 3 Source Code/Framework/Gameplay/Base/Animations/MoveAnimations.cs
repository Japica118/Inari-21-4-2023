﻿
using UnityEngine;
using GamingIsLove.Makinom;
using GamingIsLove.ORKFramework.Animations;
using System.Collections.Generic;

namespace GamingIsLove.ORKFramework
{
	public class MoveAnimations : BaseData
	{
		[EditorHelp("Walk Type", "Select the animation type used for the walk animation " +
			"(i.e. when the combatant is walking (walk speed setting of the combatant).", "")]
		public AssetSelection<AnimationTypeAsset> walk = new AssetSelection<AnimationTypeAsset>();

		[EditorHelp("Run Type", "Select the animation type used for the run animation " +
			"(i.e. when the combatant is running (run speed setting of the combatant).", "")]
		public AssetSelection<AnimationTypeAsset> run = new AssetSelection<AnimationTypeAsset>();

		[EditorHelp("Sprint Type", "Select the animation type used for the sprint animation " +
			"(i.e. when the combatant is sprinting (sprint speed setting of the combatant).", "")]
		public AssetSelection<AnimationTypeAsset> sprint = new AssetSelection<AnimationTypeAsset>();

		public MoveAnimations()
		{

		}

		public void Stop(Combatant combatant)
		{
			combatant.Animations.Stop(this.walk);
			combatant.Animations.Stop(this.run);
			combatant.Animations.Stop(this.sprint);
		}
	}
}
