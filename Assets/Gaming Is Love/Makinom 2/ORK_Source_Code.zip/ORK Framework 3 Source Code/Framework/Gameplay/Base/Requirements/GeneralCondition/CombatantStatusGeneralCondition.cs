﻿
using UnityEngine;
using GamingIsLove.Makinom;
using System.Collections.Generic;

namespace GamingIsLove.ORKFramework
{
	[EditorSettingInfo("Combatant Status", "Check status conditions of a combatant.")]
	public class CombatantStatusGeneralCondition<T> : BaseGeneralCondition<T> where T : IObjectSelection, new()
	{
		public T combatant = new T();

		[EditorSeparator]
		public StatusConditionSettings conditions = new StatusConditionSettings();

		public CombatantStatusGeneralCondition()
		{

		}

		public override bool Check(IDataCall call)
		{
			Combatant combatant = this.combatant.GetCombatant(call);
			return combatant != null && this.conditions.Check(combatant);
		}

		public override void Register(IDataCall call, Notify notify, ref List<VariableHandler> unregisterHandlers)
		{
			Combatant combatant = this.combatant.GetCombatant(call);
			if(combatant != null)
			{
				this.conditions.RegisterStatusChanges(combatant, notify);
			}
		}

		public override void Unregister(IDataCall call, Notify notify)
		{
			Combatant combatant = this.combatant.GetCombatant(call);
			if(combatant != null)
			{
				this.conditions.UnregisterStatusChanges(combatant, notify);
			}
		}
	}
}
