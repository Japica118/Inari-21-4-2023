﻿
using UnityEngine;
using System.Collections.Generic;
using GamingIsLove.Makinom;

namespace GamingIsLove.ORKFramework.Conditions
{
	[EditorSettingInfo("Is Casting", "The combatant must or mustn't be casting an action.")]
	public class IsCastingStatusConditionType : BaseStatusConditionType
	{
		[EditorHelp("Is Casting", "The combatant must be casting an action.\n" +
			"If disabled, the combatant mustn't be casting an action.", "")]
		public bool isCasting = true;

		public IsCastingStatusConditionType()
		{

		}

		public override string ToString()
		{
			return this.isCasting ? "is casting" : "not casting";
		}


		/*
		============================================================================
		Check functions
		============================================================================
		*/
		public override bool Check(Combatant combatant)
		{
			return combatant.Actions.IsCasting == this.isCasting;
		}


		/*
		============================================================================
		Status change register functions
		============================================================================
		*/
		public override void Register(Combatant combatant, IStatusChanged notify)
		{
			combatant.Actions.CastingStateChanged += notify.CombatantCastingStateChanged;
		}

		public override void Unregister(Combatant combatant, IStatusChanged notify)
		{
			combatant.Actions.CastingStateChanged -= notify.CombatantCastingStateChanged;
		}

		public override void Register(Combatant combatant, Notify notify)
		{
			combatant.Actions.CastingStateChangedSimple += notify;
		}

		public override void Unregister(Combatant combatant, Notify notify)
		{
			combatant.Actions.CastingStateChangedSimple -= notify;
		}
	}
}
