﻿
using UnityEngine;
using GamingIsLove.Makinom;
using System.Collections.Generic;

namespace GamingIsLove.ORKFramework
{
	public abstract class BaseCombatantHighlightType : BaseTypeData
	{
		/*
		============================================================================
		Highlight functions
		============================================================================
		*/
		public virtual void Highlight(Combatant combatant)
		{

		}

		public virtual void Highlight(Combatant user, Combatant target, IShortcut shortcut)
		{
			this.Highlight(target);
		}

		public virtual void StopHighlight(Combatant combatant)
		{

		}
	}
}
