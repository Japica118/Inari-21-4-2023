﻿
using UnityEngine;
using System.Collections.Generic;
using GamingIsLove.Makinom;

namespace GamingIsLove.ORKFramework.Conditions
{
	[EditorSettingInfo("Active Player Group", "The combatant must or mustn't be in the active player group (i.e. player controlled).")]
	public class ActivePlayerGroupStatusConditionType : BaseStatusConditionType
	{
		[EditorHelp("In Active Player Group", "The combatant must be in the active player group.\n" +
			"If disabled, the combatant mustn't be in the active player group.", "")]
		public bool inActivePlayerGroup = true;

		public ActivePlayerGroupStatusConditionType()
		{

		}

		public override string ToString()
		{
			return this.inActivePlayerGroup ? "Active Player Group" : "Not Active Player Group";
		}


		/*
		============================================================================
		Check functions
		============================================================================
		*/
		public override bool Check(Combatant combatant)
		{
			return combatant.IsPlayerControlled() == this.inActivePlayerGroup;
		}


		/*
		============================================================================
		Status change register functions
		============================================================================
		*/
		public override void Register(Combatant combatant, IStatusChanged notify)
		{
			combatant.GroupChanged += notify.CombatantGroupChanged;
		}

		public override void Unregister(Combatant combatant, IStatusChanged notify)
		{
			combatant.GroupChanged -= notify.CombatantGroupChanged;
		}

		public override void Register(Combatant combatant, Notify notify)
		{
			combatant.GroupChangedSimple += notify;
		}

		public override void Unregister(Combatant combatant, Notify notify)
		{
			combatant.GroupChangedSimple -= notify;
		}
	}
}
