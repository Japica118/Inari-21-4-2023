
using UnityEngine;
using GamingIsLove.Makinom;

namespace GamingIsLove.ORKFramework
{
	public class GameStatistic : BaseData, ISaveData
	{
		// enemies
		[EditorHelp("Total Killed", "The sum of all killed enemies will be logged.", "")]
		[EditorTitleLabel("Enemy Statistics")]
		public bool logKilledEnemies = false;

		[EditorHelp("Single Killed", "The number of killed enemies will be logged separated by enemy.", "")]
		public bool logSingleEnemies = false;


		// items
		[EditorHelp("Total Used", "The sum of all used items will be logged.", "")]
		[EditorSeparator]
		[EditorTitleLabel("Item Statistics")]
		public bool logUsedItems = false;

		[EditorHelp("Single Used", "The number of used items will be logged, separated by item.", "")]
		public bool logSingleItems = false;

		[EditorHelp("Total Created", "The sum of all created items (using crafting recipes) will be logged.", "")]
		public bool logCreatedItems = false;

		[EditorHelp("Single Created", "The number of created items (using crafting recipes) will be logged, separated by item.", "")]
		public bool logSingleCreated = false;

		[EditorHelp("Total Battle Gains", "The sum of all items collected as battle gains will be logged.", "")]
		public bool logTotalBattleGains = false;

		[EditorHelp("Single Battle Gains", "The number of items collected as battle gains will be logged, separated by item.", "")]
		public bool logSingleBattleGains = false;


		// battles
		[EditorHelp("Total Battles", "The sum of all battles will be logged.", "")]
		[EditorSeparator]
		[EditorTitleLabel("Battle Statistics")]
		public bool logBattles = false;

		[EditorHelp("Won Battles", "The sum of battles won by the party will be logged.", "")]
		public bool logWonBattles = false;

		[EditorHelp("Lost Battles", "The sum of battles lost by the party will be logged.", "")]
		public bool logLostBattles = false;

		[EditorHelp("Escaped Battles", "The sum of battles where the party escaped will be logged.", "")]
		public bool logEscapedBattles = false;


		// custom
		[EditorHelp("Custom", "Custom statistics will be logged.\n" +
			"Custom statistics can be added by using schematics.", "")]
		[EditorSeparator]
		[EditorTitleLabel("Custom Statistics")]
		public bool logCustom = false;


		// ingame
		// enemies
		private int killedEnemies = 0;
		private int[] singleEnemies = new int[0];

		// items
		private int usedItems = 0;
		private int[] singleItems = new int[0];
		private int createdItems = 0;
		private int[] singleCreatedItems = new int[0];
		private int[] singleCreatedEquipment = new int[0];
		private int[] singleCreatedAIBehaviours = new int[0];
		private int[] singleCreatedAIRulesets = new int[0];
		private int[] singleCreatedCraftingRecipes = new int[0];
		private int gainedItems = 0;
		private int[] singleGainedItems = new int[0];
		private int[] singleGainedEquipment = new int[0];
		private int[] singleGainedAIBehaviours = new int[0];
		private int[] singleGainedAIRulesets = new int[0];
		private int[] singleGainedCraftingRecipes = new int[0];

		// battles
		private int battles = 0;
		private int wonBattles = 0;
		private int lostBattles = 0;
		private int escapedBattles = 0;

		// custom
		private int[] custom = new int[0];

		public GameStatistic()
		{

		}

		public void Clear()
		{
			if(this.logKilledEnemies)
			{
				this.killedEnemies = 0;
			}
			if(this.logSingleEnemies)
			{
				this.singleEnemies = new int[ORK.Combatants.Count];
			}
			if(this.logUsedItems)
			{
				this.usedItems = 0;
			}
			if(this.logSingleItems)
			{
				this.singleItems = new int[ORK.Items.Count];
			}
			if(this.logCreatedItems)
			{
				this.createdItems = 0;
			}
			if(this.logSingleCreated)
			{
				this.singleCreatedItems = new int[ORK.Items.Count];
				this.singleCreatedEquipment = new int[ORK.Equipment.Count];
				this.singleCreatedAIBehaviours = new int[ORK.AIBehaviours.Count];
				this.singleCreatedAIRulesets = new int[ORK.AIRulesets.Count];
				this.singleCreatedCraftingRecipes = new int[ORK.CraftingRecipes.Count];
			}
			if(this.logTotalBattleGains)
			{
				this.gainedItems = 0;
			}
			if(this.logSingleBattleGains)
			{
				this.singleGainedItems = new int[ORK.Items.Count];
				this.singleGainedEquipment = new int[ORK.Equipment.Count];
				this.singleGainedAIBehaviours = new int[ORK.AIBehaviours.Count];
				this.singleGainedAIRulesets = new int[ORK.AIRulesets.Count];
				this.singleGainedCraftingRecipes = new int[ORK.CraftingRecipes.Count];
			}
			if(this.logBattles)
			{
				this.battles = 0;
			}
			if(this.logWonBattles)
			{
				this.wonBattles = 0;
			}
			if(this.logLostBattles)
			{
				this.lostBattles = 0;
			}
			if(this.logEscapedBattles)
			{
				this.escapedBattles = 0;
			}
			if(this.logCustom)
			{
				this.custom = new int[0];
			}
		}


		/*
		============================================================================
		Type functions
		============================================================================
		*/
		public void Clear(StatisticType type, int index)
		{
			if(StatisticType.TotalKilled == type)
			{
				this.killedEnemies = 0;
			}
			else if(StatisticType.SingleKilled == type)
			{
				if(index >= 0 && index < this.singleEnemies.Length)
				{
					this.singleEnemies[index] = 0;
				}
			}
			else if(StatisticType.TotalUsed == type)
			{
				this.usedItems = 0;
			}
			else if(StatisticType.SingleUsed == type)
			{
				if(index >= 0 && index < this.singleItems.Length)
				{
					this.singleItems[index] = 0;
				}
			}
			else if(StatisticType.TotalCreated == type)
			{
				this.createdItems = 0;
			}
			else if(StatisticType.SingleCreatedItem == type)
			{
				if(index >= 0 && index < this.singleCreatedItems.Length)
				{
					this.singleCreatedItems[index] = 0;
				}
			}
			else if(StatisticType.SingleCreatedEquipment == type)
			{
				if(index >= 0 && index < this.singleCreatedEquipment.Length)
				{
					this.singleCreatedEquipment[index] = 0;
				}
			}
			else if(StatisticType.SingleCreatedAIBehaviour == type)
			{
				if(index >= 0 && index < this.singleCreatedAIBehaviours.Length)
				{
					this.singleCreatedAIBehaviours[index] = 0;
				}
			}
			else if(StatisticType.SingleCreatedAIRuleset == type)
			{
				if(index >= 0 && index < this.singleCreatedAIRulesets.Length)
				{
					this.singleCreatedAIRulesets[index] = 0;
				}
			}
			else if(StatisticType.SingleCreatedCraftingRecipes == type)
			{
				if(index >= 0 && index < this.singleCreatedCraftingRecipes.Length)
				{
					this.singleCreatedCraftingRecipes[index] = 0;
				}
			}
			else if(StatisticType.TotalGained == type)
			{
				this.gainedItems = 0;
			}
			else if(StatisticType.SingleGainedItem == type)
			{
				if(index >= 0 && index < this.singleGainedItems.Length)
				{
					this.singleGainedItems[index] = 0;
				}
			}
			else if(StatisticType.SingleGainedEquipment == type)
			{
				if(index >= 0 && index < this.singleGainedEquipment.Length)
				{
					this.singleGainedEquipment[index] = 0;
				}
			}
			else if(StatisticType.SingleGainedAIBehaviour == type)
			{
				if(index >= 0 && index < this.singleGainedAIBehaviours.Length)
				{
					this.singleGainedAIBehaviours[index] = 0;
				}
			}
			else if(StatisticType.SingleGainedAIRuleset == type)
			{
				if(index >= 0 && index < this.singleGainedAIRulesets.Length)
				{
					this.singleGainedAIRulesets[index] = 0;
				}
			}
			else if(StatisticType.SingleGainedCraftingRecipes == type)
			{
				if(index >= 0 && index < this.singleGainedCraftingRecipes.Length)
				{
					this.singleGainedCraftingRecipes[index] = 0;
				}
			}
			else if(StatisticType.TotalBattles == type)
			{
				this.battles = 0;
			}
			else if(StatisticType.WonBattles == type)
			{
				this.wonBattles = 0;
			}
			else if(StatisticType.LostBattles == type)
			{
				this.lostBattles = 0;
			}
			else if(StatisticType.EscapedBattles == type)
			{
				this.escapedBattles = 0;
			}
			else if(StatisticType.Custom == type)
			{
				if(index >= 0 && index < this.custom.Length)
				{
					this.custom[index] = 0;
				}
			}
		}

		public int Get(StatisticType type, int index)
		{
			if(StatisticType.TotalKilled == type)
			{
				return this.killedEnemies;
			}
			else if(StatisticType.SingleKilled == type)
			{
				if(index >= 0 && index < this.singleEnemies.Length)
				{
					return this.singleEnemies[index];
				}
			}
			else if(StatisticType.TotalUsed == type)
			{
				return this.usedItems;
			}
			else if(StatisticType.SingleUsed == type)
			{
				if(index >= 0 && index < this.singleItems.Length)
				{
					return this.singleItems[index];
				}
			}
			else if(StatisticType.TotalCreated == type)
			{
				return this.createdItems;
			}
			else if(StatisticType.SingleCreatedItem == type)
			{
				if(index >= 0 && index < this.singleCreatedItems.Length)
				{
					return this.singleCreatedItems[index];
				}
			}
			else if(StatisticType.SingleCreatedEquipment == type)
			{
				if(index >= 0 && index < this.singleCreatedEquipment.Length)
				{
					return this.singleCreatedEquipment[index];
				}
			}
			else if(StatisticType.SingleCreatedAIBehaviour == type)
			{
				if(index >= 0 && index < this.singleCreatedAIBehaviours.Length)
				{
					return this.singleCreatedAIBehaviours[index];
				}
			}
			else if(StatisticType.SingleCreatedAIRuleset == type)
			{
				if(index >= 0 && index < this.singleCreatedAIRulesets.Length)
				{
					return this.singleCreatedAIRulesets[index];
				}
			}
			else if(StatisticType.SingleCreatedCraftingRecipes == type)
			{
				if(index >= 0 && index < this.singleCreatedCraftingRecipes.Length)
				{
					return this.singleCreatedCraftingRecipes[index];
				}
			}
			else if(StatisticType.TotalGained == type)
			{
				return this.gainedItems;
			}
			else if(StatisticType.SingleGainedItem == type)
			{
				if(index >= 0 && index < this.singleGainedItems.Length)
				{
					return this.singleGainedItems[index];
				}
			}
			else if(StatisticType.SingleGainedEquipment == type)
			{
				if(index >= 0 && index < this.singleGainedEquipment.Length)
				{
					return this.singleGainedEquipment[index];
				}
			}
			else if(StatisticType.SingleGainedAIBehaviour == type)
			{
				if(index >= 0 && index < this.singleGainedAIBehaviours.Length)
				{
					return this.singleGainedAIBehaviours[index];
				}
			}
			else if(StatisticType.SingleGainedAIRuleset == type)
			{
				if(index >= 0 && index < this.singleGainedAIRulesets.Length)
				{
					return this.singleGainedAIRulesets[index];
				}
			}
			else if(StatisticType.SingleGainedCraftingRecipes == type)
			{
				if(index >= 0 && index < this.singleGainedCraftingRecipes.Length)
				{
					return this.singleGainedCraftingRecipes[index];
				}
			}
			else if(StatisticType.TotalBattles == type)
			{
				return this.battles;
			}
			else if(StatisticType.WonBattles == type)
			{
				return this.wonBattles;
			}
			else if(StatisticType.LostBattles == type)
			{
				return this.lostBattles;
			}
			else if(StatisticType.EscapedBattles == type)
			{
				return this.escapedBattles;
			}
			else if(StatisticType.Custom == type)
			{
				if(index >= 0 && index < this.custom.Length)
				{
					return this.custom[index];
				}
			}
			return 0;
		}


		/*
		============================================================================
		Text functions
		============================================================================
		*/
		public void GetStatisticText(UIText contentText)
		{
			if(contentText.Contains(ORKTextCode.Statistic))
			{
				// enemies
				contentText.Replace(ORKTextCode.Statistic_KilledTotal,
					ORK.TextDisplaySettings.numberFormatting.FormatInt(this.GetKilledEnemies()));

				string replaceString = TextHelper.NextSpecialString(ref contentText.text, ORKTextCode.Statistic_KilledEnemy, 0);
				while(replaceString != "")
				{
					contentText.Replace(ORKTextCode.Statistic_KilledEnemy + replaceString + TextCode.CloseTag,
						ORK.Combatants.Get(replaceString).GetTextCode(10));
					replaceString = TextHelper.NextSpecialString(ref contentText.text, ORKTextCode.Statistic_KilledEnemy, 0);
				}

				// items
				contentText.Replace(ORKTextCode.Statistic_UsedTotal,
					ORK.TextDisplaySettings.numberFormatting.itemQuantityFormat.FormatInt(this.GetUsedItems()));

				replaceString = TextHelper.NextSpecialString(ref contentText.text, ORKTextCode.Statistic_UsedItem, 0);
				while(replaceString != "")
				{
					contentText.Replace(ORKTextCode.Statistic_UsedItem + replaceString + TextCode.CloseTag,
						ORK.Items.Get(replaceString).GetTextCode(11));
					replaceString = TextHelper.NextSpecialString(ref contentText.text, ORKTextCode.Statistic_UsedItem, 0);
				}

				// created items
				contentText.Replace(ORKTextCode.Statistic_CreatedTotal,
					ORK.TextDisplaySettings.numberFormatting.itemQuantityFormat.FormatInt(this.GetCreatedItems()));

				replaceString = TextHelper.NextSpecialString(ref contentText.text, ORKTextCode.Statistic_CreatedItem, 0);
				while(replaceString != "")
				{
					contentText.Replace(ORKTextCode.Statistic_CreatedItem + replaceString + TextCode.CloseTag,
						ORK.Items.Get(replaceString).GetTextCode(12));
					replaceString = TextHelper.NextSpecialString(ref contentText.text, ORKTextCode.Statistic_CreatedItem, 0);
				}

				replaceString = TextHelper.NextSpecialString(ref contentText.text, ORKTextCode.Statistic_CreatedEquipment, 0);
				while(replaceString != "")
				{
					contentText.Replace(ORKTextCode.Statistic_CreatedEquipment + replaceString + TextCode.CloseTag,
						ORK.Equipment.Get(replaceString).GetTextCode(12));
					replaceString = TextHelper.NextSpecialString(ref contentText.text, ORKTextCode.Statistic_CreatedEquipment, 0);
				}

				replaceString = TextHelper.NextSpecialString(ref contentText.text, ORKTextCode.Statistic_CreatedAIBehaviour, 0);
				while(replaceString != "")
				{
					contentText.Replace(ORKTextCode.Statistic_CreatedAIBehaviour + replaceString + TextCode.CloseTag,
						ORK.AIBehaviours.Get(replaceString).GetTextCode(12));
					replaceString = TextHelper.NextSpecialString(ref contentText.text, ORKTextCode.Statistic_CreatedAIBehaviour, 0);
				}

				replaceString = TextHelper.NextSpecialString(ref contentText.text, ORKTextCode.Statistic_CreatedAIRuleset, 0);
				while(replaceString != "")
				{
					contentText.Replace(ORKTextCode.Statistic_CreatedAIRuleset + replaceString + TextCode.CloseTag,
						ORK.AIRulesets.Get(replaceString).GetTextCode(12));
					replaceString = TextHelper.NextSpecialString(ref contentText.text, ORKTextCode.Statistic_CreatedAIRuleset, 0);
				}

				replaceString = TextHelper.NextSpecialString(ref contentText.text, ORKTextCode.Statistic_CreatedCraftingRecipe, 0);
				while(replaceString != "")
				{
					contentText.Replace(ORKTextCode.Statistic_CreatedCraftingRecipe + replaceString + TextCode.CloseTag,
						ORK.CraftingRecipes.Get(replaceString).GetTextCode(11));
					replaceString = TextHelper.NextSpecialString(ref contentText.text, ORKTextCode.Statistic_CreatedCraftingRecipe, 0);
				}

				// gained items
				contentText.Replace(ORKTextCode.Statistic_GainedTotal,
					ORK.TextDisplaySettings.numberFormatting.itemQuantityFormat.FormatInt(this.GetGainedItems()));

				replaceString = TextHelper.NextSpecialString(ref contentText.text, ORKTextCode.Statistic_GainedItem, 0);
				while(replaceString != "")
				{
					contentText.Replace(ORKTextCode.Statistic_GainedItem + replaceString + TextCode.CloseTag,
						ORK.Items.Get(replaceString).GetTextCode(13));
					replaceString = TextHelper.NextSpecialString(ref contentText.text, ORKTextCode.Statistic_GainedItem, 0);
				}

				replaceString = TextHelper.NextSpecialString(ref contentText.text, ORKTextCode.Statistic_GainedEquipment, 0);
				while(replaceString != "")
				{
					contentText.Replace(ORKTextCode.Statistic_GainedEquipment + replaceString + TextCode.CloseTag,
						ORK.Equipment.Get(replaceString).GetTextCode(13));
					replaceString = TextHelper.NextSpecialString(ref contentText.text, ORKTextCode.Statistic_GainedEquipment, 0);
				}

				replaceString = TextHelper.NextSpecialString(ref contentText.text, ORKTextCode.Statistic_GainedAIBehaviour, 0);
				while(replaceString != "")
				{
					contentText.Replace(ORKTextCode.Statistic_GainedAIBehaviour + replaceString + TextCode.CloseTag,
						ORK.AIBehaviours.Get(replaceString).GetTextCode(13));
					replaceString = TextHelper.NextSpecialString(ref contentText.text, ORKTextCode.Statistic_GainedAIBehaviour, 0);
				}

				replaceString = TextHelper.NextSpecialString(ref contentText.text, ORKTextCode.Statistic_GainedAIRuleset, 0);
				while(replaceString != "")
				{
					contentText.Replace(ORKTextCode.Statistic_GainedAIRuleset + replaceString + TextCode.CloseTag,
						ORK.AIRulesets.Get(replaceString).GetTextCode(13));
					replaceString = TextHelper.NextSpecialString(ref contentText.text, ORKTextCode.Statistic_GainedAIRuleset, 0);
				}

				replaceString = TextHelper.NextSpecialString(ref contentText.text, ORKTextCode.Statistic_GainedCraftingRecipe, 0);
				while(replaceString != "")
				{
					contentText.Replace(ORKTextCode.Statistic_GainedCraftingRecipe + replaceString + TextCode.CloseTag,
						ORK.CraftingRecipes.Get(replaceString).GetTextCode(12));
					replaceString = TextHelper.NextSpecialString(ref contentText.text, ORKTextCode.Statistic_GainedCraftingRecipe, 0);
				}

				// battles
				contentText.Replace(ORKTextCode.Statistic_BattlesTotal,
					ORK.TextDisplaySettings.numberFormatting.FormatInt(this.GetBattles()));
				contentText.Replace(ORKTextCode.Statistic_BattlesWon,
					ORK.TextDisplaySettings.numberFormatting.FormatInt(this.GetWonBattles()));
				contentText.Replace(ORKTextCode.Statistic_BattlesLost,
					ORK.TextDisplaySettings.numberFormatting.FormatInt(this.GetLostBattles()));
				contentText.Replace(ORKTextCode.Statistic_BattlesEscaped,
					ORK.TextDisplaySettings.numberFormatting.FormatInt(this.GetEscapedBattles()));

				// custom
				int replace = TextHelper.NextSpecial(ref contentText.text, ORKTextCode.Statistic_Custom, 0);
				while(replace != -2)
				{
					contentText.Replace(ORKTextCode.Statistic_Custom + replace + TextCode.CloseTag,
						ORK.TextDisplaySettings.numberFormatting.FormatInt(this.GetCustom(replace)));
					replace = TextHelper.NextSpecial(ref contentText.text, ORKTextCode.Statistic_Custom, 0);
				}
			}
		}


		/*
		============================================================================
		Combatant functions
		============================================================================
		*/
		public void EnemyKilled(int id)
		{
			if(this.logKilledEnemies)
			{
				this.killedEnemies++;
			}
			if(this.logSingleEnemies &&
				id >= 0 &&
				id < this.singleEnemies.Length)
			{
				this.singleEnemies[id]++;
			}
		}

		public int GetKilledEnemies()
		{
			return this.killedEnemies;
		}

		public int GetKilledEnemy(int id)
		{
			if(id >= 0 &&
				id < this.singleEnemies.Length)
			{
				return this.singleEnemies[id];
			}
			else
			{
				return 0;
			}
		}


		/*
		============================================================================
		Item functions
		============================================================================
		*/
		public void ItemUsed(int id)
		{
			if(this.logUsedItems)
			{
				this.usedItems++;
			}
			if(this.logSingleItems &&
				id >= 0 &&
				id < this.singleItems.Length)
			{
				this.singleItems[id]++;
			}
		}

		public int GetUsedItems()
		{
			return this.usedItems;
		}

		public int GetUsedItem(int id)
		{
			if(id >= 0 &&
				id < this.singleItems.Length)
			{
				return this.singleItems[id];
			}
			else
			{
				return 0;
			}
		}


		/*
		============================================================================
		Created item functions
		============================================================================
		*/
		public void ItemCreated(IShortcut shortcut)
		{
			if(this.logCreatedItems)
			{
				this.createdItems += shortcut.Quantity;
			}
			if(this.logSingleCreated)
			{
				if(shortcut is ItemShortcut)
				{
					this.singleCreatedItems[shortcut.ID] += shortcut.Quantity;
				}
				else if(shortcut is EquipShortcut)
				{
					this.singleCreatedEquipment[shortcut.ID] += shortcut.Quantity;
				}
				else if(shortcut is AIBehaviourShortcut)
				{
					this.singleCreatedAIBehaviours[shortcut.ID] += shortcut.Quantity;
				}
				else if(shortcut is AIRulesetShortcut)
				{
					this.singleCreatedAIRulesets[shortcut.ID] += shortcut.Quantity;
				}
				else if(shortcut is CraftingRecipeShortcut)
				{
					this.singleCreatedCraftingRecipes[shortcut.ID] += shortcut.Quantity;
				}
			}
		}

		public int GetCreatedItems()
		{
			return this.createdItems;
		}

		public int GetCreatedItem(int id)
		{
			if(id >= 0 &&
				id < this.singleCreatedItems.Length)
			{
				return this.singleCreatedItems[id];
			}
			else
			{
				return 0;
			}
		}

		public int GetCreatedEquipment(int id)
		{
			if(id >= 0 &&
				id < this.singleCreatedEquipment.Length)
			{
				return this.singleCreatedEquipment[id];
			}
			else
			{
				return 0;
			}
		}

		public int GetCreatedAIBehaviour(int id)
		{
			if(id >= 0 &&
				id < this.singleCreatedAIBehaviours.Length)
			{
				return this.singleCreatedAIBehaviours[id];
			}
			else
			{
				return 0;
			}
		}

		public int GetCreatedAIRuleset(int id)
		{
			if(id >= 0 &&
				id < this.singleCreatedAIRulesets.Length)
			{
				return this.singleCreatedAIRulesets[id];
			}
			else
			{
				return 0;
			}
		}

		public int GetCreatedCraftingRecipes(int id)
		{
			if(id >= 0 &&
				id < this.singleCreatedCraftingRecipes.Length)
			{
				return this.singleCreatedCraftingRecipes[id];
			}
			else
			{
				return 0;
			}
		}


		/*
		============================================================================
		Gained item functions
		============================================================================
		*/
		public void ItemGained(IShortcut shortcut)
		{
			if(this.logTotalBattleGains)
			{
				this.gainedItems += shortcut.Quantity;
			}
			if(this.logSingleBattleGains)
			{
				if(shortcut is ItemShortcut)
				{
					this.singleGainedItems[shortcut.ID] += shortcut.Quantity;
				}
				else if(shortcut is EquipShortcut)
				{
					this.singleGainedEquipment[shortcut.ID] += shortcut.Quantity;
				}
				else if(shortcut is AIBehaviourShortcut)
				{
					this.singleGainedAIBehaviours[shortcut.ID] += shortcut.Quantity;
				}
				else if(shortcut is AIRulesetShortcut)
				{
					this.singleGainedAIRulesets[shortcut.ID] += shortcut.Quantity;
				}
				else if(shortcut is CraftingRecipeShortcut)
				{
					this.singleGainedCraftingRecipes[shortcut.ID] += shortcut.Quantity;
				}
			}
		}

		public int GetGainedItems()
		{
			return this.gainedItems;
		}

		public int GetGainedItem(int id)
		{
			if(id >= 0 &&
				id < this.singleGainedItems.Length)
			{
				return this.singleGainedItems[id];
			}
			else
			{
				return 0;
			}
		}

		public int GetGainedEquipment(int id)
		{
			if(id >= 0 &&
				id < this.singleGainedEquipment.Length)
			{
				return this.singleGainedEquipment[id];
			}
			else
			{
				return 0;
			}
		}

		public int GetGainedAIBehaviour(int id)
		{
			if(id >= 0 &&
				id < this.singleGainedAIBehaviours.Length)
			{
				return this.singleGainedAIBehaviours[id];
			}
			else
			{
				return 0;
			}
		}

		public int GetGainedAIRuleset(int id)
		{
			if(id >= 0 &&
				id < this.singleGainedAIRulesets.Length)
			{
				return this.singleGainedAIRulesets[id];
			}
			else
			{
				return 0;
			}
		}

		public int GetGainedCraftingRecipes(int id)
		{
			if(id >= 0 &&
				id < this.singleGainedCraftingRecipes.Length)
			{
				return this.singleGainedCraftingRecipes[id];
			}
			else
			{
				return 0;
			}
		}


		/*
		============================================================================
		Battle functions
		============================================================================
		*/
		public void BattleStarted()
		{
			if(this.logBattles)
			{
				this.battles++;
			}
		}

		public void BattleWon()
		{
			if(this.logWonBattles)
			{
				this.wonBattles++;
			}
		}

		public void BattleLost()
		{
			if(this.logLostBattles)
			{
				this.lostBattles++;
			}
		}

		public void BattleEscaped()
		{
			if(this.logEscapedBattles)
			{
				this.escapedBattles++;
			}
		}

		public int GetBattles()
		{
			return this.battles;
		}

		public int GetWonBattles()
		{
			return this.wonBattles;
		}

		public int GetLostBattles()
		{
			return this.lostBattles;
		}

		public int GetEscapedBattles()
		{
			return this.escapedBattles;
		}


		/*
		============================================================================
		Custom functions
		============================================================================
		*/
		public void CustomChanged(int index, int add)
		{
			if(this.logCustom && index >= 0)
			{
				if(index >= this.custom.Length)
				{
					int[] tmp = this.custom;
					this.custom = new int[index + 1];
					System.Array.Copy(tmp, this.custom, tmp.Length);
				}
				this.custom[index] += add;
			}
		}

		public int GetCustom(int index)
		{
			if(index >= 0 && index < this.custom.Length)
			{
				return this.custom[index];
			}
			return 0;
		}


		/*
		============================================================================
		Save game functions
		============================================================================
		*/
		public DataObject SaveGame()
		{
			DataObject data = new DataObject();

			// enemies
			data.Set("killedEnemies", this.killedEnemies);
			data.Set("singleEnemies", this.singleEnemies);

			// items
			data.Set("usedItems", this.usedItems);
			data.Set("singleItems", this.singleItems);
			// crafted
			data.Set("createdItems", this.createdItems);
			data.Set("singleCreatedItems", this.singleCreatedItems);
			data.Set("singleCreatedEquipment", this.singleCreatedEquipment);
			data.Set("singleCreatedAIBehaviours", this.singleCreatedAIBehaviours);
			data.Set("singleCreatedAIRulesets", this.singleCreatedAIRulesets);
			data.Set("singleCreatedCraftingRecipes", this.singleCreatedCraftingRecipes);
			// gained
			data.Set("gainedItems", this.gainedItems);
			data.Set("singleGainedItems", this.singleGainedItems);
			data.Set("singleGainedEquipment", this.singleGainedEquipment);
			data.Set("singleGainedAIBehaviours", this.singleGainedAIBehaviours);
			data.Set("singleGainedAIRulesets", this.singleGainedAIRulesets);
			data.Set("singleGainedCraftingRecipes", this.singleGainedCraftingRecipes);

			// battles
			data.Set("battles", this.battles);
			data.Set("wonBattles", this.wonBattles);
			data.Set("lostBattles", this.lostBattles);
			data.Set("escapedBattles", this.escapedBattles);

			// custom
			data.Set("custom", this.custom);

			return data;
		}

		public void LoadGame(DataObject data)
		{
			this.Clear();
			if(data != null)
			{
				// enemies
				data.Get("killedEnemies", ref this.killedEnemies);
				data.Get("singleEnemies", out this.singleEnemies);

				// items
				int[] tmp = null;
				data.Get("usedItems", ref this.usedItems);
				this.LoadArray(data, "singleItems", tmp, this.singleItems);
				// crafted
				data.Get("createdItems", ref this.createdItems);
				this.LoadArray(data, "singleCreatedItems", tmp, this.singleCreatedItems);
				this.LoadArray(data, "singleCreatedEquipment", tmp, this.singleCreatedEquipment);
				this.LoadArray(data, "singleCreatedAIBehaviours", tmp, this.singleCreatedAIBehaviours);
				this.LoadArray(data, "singleCreatedAIRulesets", tmp, this.singleCreatedAIRulesets);
				this.LoadArray(data, "singleCreatedCraftingRecipes", tmp, this.singleCreatedCraftingRecipes);
				// gained
				data.Get("gainedItems", ref this.gainedItems);
				this.LoadArray(data, "singleGainedItems", tmp, this.singleGainedItems);
				this.LoadArray(data, "singleGainedEquipment", tmp, this.singleGainedEquipment);
				this.LoadArray(data, "singleGainedAIBehaviours", tmp, this.singleGainedAIBehaviours);
				this.LoadArray(data, "singleGainedAIRulesets", tmp, this.singleGainedAIRulesets);
				this.LoadArray(data, "singleGainedCraftingRecipes", tmp, this.singleGainedCraftingRecipes);

				// battles
				data.Get("battles", ref this.battles);
				data.Get("wonBattles", ref this.wonBattles);
				data.Get("lostBattles", ref this.lostBattles);
				data.Get("escapedBattles", ref this.escapedBattles);

				// custom
				data.Get("custom", out this.custom);
			}
		}

		private void LoadArray(DataObject data, string name, int[] source, int[] destination)
		{
			if(destination != null)
			{
				source = null;
				data.Get(name, out source);
				if(source != null)
				{
					System.Array.Copy(source, destination, Mathf.Min(source.Length, destination.Length));
				}
			}
		}
	}
}
