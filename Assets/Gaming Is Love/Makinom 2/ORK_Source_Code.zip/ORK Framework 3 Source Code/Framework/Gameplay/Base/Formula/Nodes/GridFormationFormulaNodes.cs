﻿
using UnityEngine;
using GamingIsLove.ORKFramework;
using System.Collections.Generic;

namespace GamingIsLove.Makinom.Formulas.Nodes
{
	[EditorHelp("In Grid Formation", "Checks if a combatant's group currently is in any or a defined grid formation, " +
		"or checks if a combatant is part of a formation.\n" +
		"If the check is valid, 'Success' will be executed, otherwise 'Failed'.\n" +
		"Only used in grid battles.", "")]
	[NodeInfo("Grid Formation")]
	public class InGridFormationNode : BaseFormulaCheckNode
	{
		public FormulaStatusOrigin origin = new FormulaStatusOrigin();

		[EditorHelp("Check Combatant", "Checks if a combatant is part of a formation.", "")]
		[EditorSeparator]
		public bool checkCombatant = false;


		// formation
		[EditorHelp("Any Formation", "Checks if the combatant's group is in any grid formation.", "")]
		[EditorCondition("checkCombatant", false)]
		public bool anyFormation = true;

		[EditorHelp("Grid Formation", "Select the grid formation that will be used.", "")]
		[EditorCondition("anyFormation", false)]
		[EditorEndCondition(2)]
		public AssetSelection<BattleGridFormationAsset> formation = new AssetSelection<BattleGridFormationAsset>();

		public InGridFormationNode()
		{

		}

		public override int Calculate(FormulaCall call)
		{
			Combatant combatant = this.origin.GetCombatant(call);

			if(combatant != null)
			{
				if(this.checkCombatant)
				{
					if(combatant.Group.InGridFormation &&
						combatant.Group.GridFormation.IsInFormation(combatant))
					{
						return this.next;
					}
				}
				else if(combatant.Group.InGridFormation &&
					(this.anyFormation ||
						(this.formation.StoredAsset != null &&
							combatant.Group.GridFormation.IsFormation(this.formation.StoredAsset.Settings))))
				{
					return this.next;
				}
			}

			return this.nextFail;
		}


		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.origin.ToString() + (this.checkCombatant ? ": In Formation" :
				(this.anyFormation ? ": Any" : ": " + this.formation.ToString()));
		}

		public override Color EditorColor
		{
			get { return Maki.EditorSettings.gameObjectNodeColor; }
		}
	}

	[EditorHelp("Is Grid Formation Leader", "Checks if a combatant is the leader of a grid formation.\n" +
		"If the check is valid, 'Success' will be executed, otherwise 'Failed'.\n" +
		"Only used in grid battles.", "")]
	[NodeInfo("Grid Formation")]
	public class IsGridFormationLeaderNode : BaseFormulaCheckNode
	{
		public FormulaStatusOrigin origin = new FormulaStatusOrigin();

		public IsGridFormationLeaderNode()
		{

		}

		public override int Calculate(FormulaCall call)
		{
			Combatant combatant = this.origin.GetCombatant(call);

			if(combatant != null &&
				combatant.Group.InGridFormation &&
				combatant.Group.GridFormation.Leader == combatant)
			{
				return this.next;
			}
			else
			{
				return this.nextFail;
			}
		}


		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.origin.ToString();
		}

		public override Color EditorColor
		{
			get { return Maki.EditorSettings.gameObjectNodeColor; }
		}
	}

	[EditorHelp("In Grid Formation Position", "Checks if a combatant is on the assigned grid formation position cell.\n" +
		"The formation leader is always in formation position.\n" +
		"If the check is valid, 'Success' will be executed, otherwise 'Failed'.\n" +
		"Only used in grid battles.", "")]
	[NodeInfo("Grid Formation")]
	public class InGridFormationPositionNode : BaseFormulaCheckNode
	{
		public FormulaStatusOrigin origin = new FormulaStatusOrigin();

		public InGridFormationPositionNode()
		{

		}

		public override int Calculate(FormulaCall call)
		{
			Combatant combatant = this.origin.GetCombatant(call);

			if(combatant != null &&
				combatant.Group.InGridFormation &&
				combatant.Group.GridFormation.IsInPosition(combatant))
			{
				return this.next;
			}
			else
			{
				return this.nextFail;
			}
		}


		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.origin.ToString();
		}

		public override Color EditorColor
		{
			get { return Maki.EditorSettings.gameObjectNodeColor; }
		}
	}

	[EditorHelp("Grid Formation Finished", "Checks if all combatants reached their grid formation position.\n" +
		"If the check is valid, 'Success' will be executed, otherwise 'Failed'.\n" +
		"Only used in grid battles.", "")]
	[NodeInfo("Grid Formation")]
	public class GridFormationFinishedNode : BaseFormulaCheckNode
	{
		public FormulaStatusOrigin origin = new FormulaStatusOrigin();


		// settings
		[EditorHelp("Only Filled Positions", "Only positions that have a combatant assigned will be checked.\n" +
			"If disabled, an empty position will result in failure.", "")]
		[EditorSeparator]
		public bool onlyFilled = true;

		[EditorHelp("Check Rotation", "Checks if the combatant's rotation matches the rotation defined by the position " +
			"(e.g. matching the leader's rotatin).\n" +
			"If disabled, rotations are ignored.", "")]
		public bool checkRotation = false;

		[EditorHelp("Check Grid Distance", "Only positions where the combatant is " +
			"a defined grid distance away from the cell will be checked.\n" +
			"If the combatant is farther away, the position will be ignored.", "")]
		public bool checkGridDistance = false;

		[EditorSeparator]
		[EditorTitleLabel("Distance")]
		[EditorCondition("checkGridDistance", true)]
		[EditorEndCondition]
		[EditorAutoInit]
		public FloatValue<FormulaObjectSelection> distance;

		public GridFormationFinishedNode()
		{

		}

		public override int Calculate(FormulaCall call)
		{
			Combatant combatant = this.origin.GetCombatant(call);

			if(combatant != null &&
				combatant.Group.InGridFormation &&
				combatant.Group.GridFormation.PositionsFilled(this.onlyFilled, this.checkRotation,
					(int)(this.checkGridDistance ? this.distance.GetValue(call) : -1)))
			{
				return this.next;
			}
			else
			{
				return this.nextFail;
			}
		}


		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.origin.ToString();
		}

		public override Color EditorColor
		{
			get { return Maki.EditorSettings.gameObjectNodeColor; }
		}
	}

	[EditorHelp("Grid Formation Possible", "Checks if a combatant group's formation is possible " +
		"or a defined grid formation is possible at a combatant's cell.\n" +
		"A formation isn't possible if one of the position cells is blocked or invalid (outside the grid).\n" +
		"If the check is valid, 'Success' will be executed, otherwise 'Failed'.\n" +
		"Only used in grid battles.", "")]
	[NodeInfo("Grid Formation")]
	public class GridFormationPossibleNode : BaseFormulaCheckNode
	{
		public FormulaStatusOrigin origin = new FormulaStatusOrigin();


		// settings
		[EditorHelp("Use Current Formation", "Uses the combatant group's current formation for the check.\n" +
			"The check fails if the combatant's group isn't in formation.\n"+
			"If disabled, a defined grid formation is used.", "")]
		[EditorSeparator]
		public bool useCurrentFormation = true;

		[EditorHelp("Grid Formation", "Select the grid formation that will be used.", "")]
		[EditorCondition("useCurrentFormation", false)]
		[EditorEndCondition]
		public AssetSelection<BattleGridFormationAsset> formation = new AssetSelection<BattleGridFormationAsset>();

		public GridFormationPossibleNode()
		{

		}

		public override int Calculate(FormulaCall call)
		{
			Combatant combatant = this.origin.GetCombatant(call);

			if(combatant != null)
			{
				if(this.useCurrentFormation)
				{
					if(combatant.Group.InGridFormation &&
						combatant.Group.GridFormation.IsFormationPossible())
					{
						return this.next;
					}
				}
				else if(this.formation.StoredAsset != null &&
					this.formation.StoredAsset.Settings.IsFormationPossible(combatant))
				{
					return this.next;
				}
			}

			return this.nextFail;
		}


		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.origin.ToString() + (this.useCurrentFormation ?
				": Current" : ": " + this.formation.ToString());
		}

		public override Color EditorColor
		{
			get { return Maki.EditorSettings.gameObjectNodeColor; }
		}
	}
}
