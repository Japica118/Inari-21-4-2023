﻿
using UnityEngine;
using System.Collections.Generic;
using GamingIsLove.Makinom;

namespace GamingIsLove.ORKFramework.Conditions
{
	[EditorSettingInfo("Is Researching", "The combatant must or mustn't be researching a research item.")]
	public class IsResearchingStatusConditionType : BaseStatusConditionType
	{
		[EditorHelp("Is Researching", "The combatant must be researching.\n" +
			"If disabled, the combatant mustn't be researching.", "")]
		public bool isResearching = true;

		public IsResearchingStatusConditionType()
		{

		}

		public override string ToString()
		{
			return this.isResearching ? "is researching" : "not researching";
		}


		/*
		============================================================================
		Check functions
		============================================================================
		*/
		public override bool Check(Combatant combatant)
		{
			return (combatant.Research.InResearch > 0) == this.isResearching;
		}


		/*
		============================================================================
		Status change register functions
		============================================================================
		*/
		public override void Register(Combatant combatant, IStatusChanged notify)
		{
			combatant.Research.Changed += notify.CombatantResearchChanged;
		}

		public override void Unregister(Combatant combatant, IStatusChanged notify)
		{
			combatant.Research.Changed -= notify.CombatantResearchChanged;
		}

		public override void Register(Combatant combatant, Notify notify)
		{
			combatant.Research.ChangedSimple += notify;
		}

		public override void Unregister(Combatant combatant, Notify notify)
		{
			combatant.Research.ChangedSimple -= notify;
		}
	}
}
