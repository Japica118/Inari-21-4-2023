﻿
using UnityEngine;
using GamingIsLove.Makinom;
using System.Collections.Generic;

namespace GamingIsLove.ORKFramework
{
	public class CombatantHighlightType : BaseData
	{
		[EditorHelp("Highlight Type", "Select the type of this combatant highlight:", "")]
		[EditorInfo(settingBaseType = typeof(BaseCombatantHighlightType), settingAutoSetup = "settings")]
		public string type = typeof(PrefabCombatantHighlightType).ToString();

		public BaseCombatantHighlightType settings = new PrefabCombatantHighlightType();

		public CombatantHighlightType()
		{

		}

		public override void EditorAutoSetup(string fieldName)
		{
			if("settings" == fieldName)
			{
				if(!this.settings.IsType(this.type))
				{
					DataObject data = this.settings.GetData();
					object tmpSettings = ReflectionTypeHandler.Instance.CreateInstance(
						this.type, typeof(BaseCombatantHighlightType));
					if(tmpSettings is BaseCombatantHighlightType)
					{
						this.settings = (BaseCombatantHighlightType)tmpSettings;
						this.settings.SetData(data);
					}
					else
					{
						this.settings = new PrefabCombatantHighlightType();
						this.settings.SetData(data);
						this.type = this.settings.GetType().ToString();
					}
				}
			}
		}
	}
}
