﻿
using UnityEngine;
using System.Collections.Generic;
using GamingIsLove.Makinom;

namespace GamingIsLove.ORKFramework.Conditions
{
	[EditorSettingInfo("Defence Modifier", "The combatant must have the selected defence modifier ID, or compares a defence modifier's attribute to a defined value.")]
	public class DefenceModifierStatusConditionType : BaseStatusConditionType
	{
		public DefenceModifierAttributeSelection selection = new DefenceModifierAttributeSelection();

		[EditorHelp("Check Value", "Check the current value of the selected defence modifier attribute.\n" +
			"If disabled, the combatant's current defence modifier ID is checked.", "")]
		[EditorSeparator]
		public bool checkValue = false;

		[EditorHelp("Used Value", "Select which value will be used:\n" +
			"- Current Value: The current value of the attribute.\n" +
			"- Base Value: The base value of the attribute (without bonuses).\n" +
			"- Min Value: The minimum value of the attribute.\n" +
			"- Max Value: The maximum value of the attribute.\n" +
			"- Start Value: The start value of the attribute (i.e. the attribute's initial value).\n" +
			"- Preview Value: The preview value, displaying changes when an equipment would be equipped.", "")]
		[EditorCondition("checkValue", true)]
		public ModifierGetValue getValue = ModifierGetValue.CurrentValue;

		[EditorEndCondition]
		public ValueCheck<GameObjectSelection> check = new ValueCheck<GameObjectSelection>();

		public DefenceModifierStatusConditionType()
		{

		}

		public override string ToString()
		{
			return this.selection.ToString() + (this.checkValue ? (" " + this.getValue + " " + this.check.ToString()) : "");
		}


		/*
		============================================================================
		Check functions
		============================================================================
		*/
		public override bool Check(Combatant combatant)
		{
			if(this.checkValue)
			{
				return this.check.Check(
					this.selection.GetValue(combatant, this.getValue),
					combatant.Call);
			}
			else
			{
				return this.selection.Is(combatant);
			}
		}

		public override bool CheckPreview(Combatant combatant)
		{
			if(this.checkValue)
			{
				return this.check.Check(
					this.selection.GetValue(combatant, ModifierGetValue.PreviewValue),
					combatant.Call);
			}
			else
			{
				return this.selection.Is(combatant);
			}
		}

		public override bool CheckBestiary(Combatant combatant)
		{
			if(combatant.Bestiary != null)
			{
				if(this.checkValue)
				{
					if(combatant.Bestiary.IsComplete ||
						this.selection.CheckBestiary(combatant))
					{
						return this.check.Check(
							this.selection.GetValue(combatant, this.getValue),
							combatant.Call);
					}
				}
				else if(combatant.Bestiary.IsComplete ||
					this.selection.CheckBestiaryID(combatant))
				{
					return this.selection.Is(combatant);
				}
			}
			return false;
		}


		/*
		============================================================================
		Status change register functions
		============================================================================
		*/
		public override void Register(Combatant combatant, IStatusChanged notify)
		{
			if(this.selection.modifier.StoredAsset != null)
			{
				if(this.checkValue)
				{
					combatant.Status.GetDefenceModifier(this.selection.modifier.StoredAsset.Settings).Changed += notify.DefenceModifierChanged;
				}
				else
				{
					combatant.Status.GetDefenceModifierID(this.selection.modifier.StoredAsset.Settings).Changed += notify.DefenceModifierIDChanged;
				}
			}
		}

		public override void Unregister(Combatant combatant, IStatusChanged notify)
		{
			if(this.selection.modifier.StoredAsset != null)
			{
				if(this.checkValue)
				{
					combatant.Status.GetDefenceModifier(this.selection.modifier.StoredAsset.Settings).Changed -= notify.DefenceModifierChanged;
				}
				else
				{
					combatant.Status.GetDefenceModifierID(this.selection.modifier.StoredAsset.Settings).Changed -= notify.DefenceModifierIDChanged;
				}
			}
		}

		public override void Register(Combatant combatant, Notify notify)
		{
			if(this.selection.modifier.StoredAsset != null)
			{
				if(this.checkValue)
				{
					combatant.Status.GetDefenceModifier(this.selection.modifier.StoredAsset.Settings).SimpleChanged += notify;
				}
				else
				{
					combatant.Status.GetDefenceModifierID(this.selection.modifier.StoredAsset.Settings).SimpleChanged += notify;
				}
			}
		}

		public override void Unregister(Combatant combatant, Notify notify)
		{
			if(this.selection.modifier.StoredAsset != null)
			{
				if(this.checkValue)
				{
					combatant.Status.GetDefenceModifier(this.selection.modifier.StoredAsset.Settings).SimpleChanged -= notify;
				}
				else
				{
					combatant.Status.GetDefenceModifierID(this.selection.modifier.StoredAsset.Settings).SimpleChanged -= notify;
				}
			}
		}
	}
}
