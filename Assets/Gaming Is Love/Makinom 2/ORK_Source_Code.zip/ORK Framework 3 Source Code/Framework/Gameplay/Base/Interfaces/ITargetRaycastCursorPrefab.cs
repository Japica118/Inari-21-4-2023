﻿
using UnityEngine;
using GamingIsLove.Makinom;
using System.Collections.Generic;

namespace GamingIsLove.ORKFramework
{
	public interface ITargetRaycastCursorPrefab
	{
		void StartSelection(Combatant user, BaseAction action);

		void StopSelection();
	}
}
