﻿
using UnityEngine;
using System.Collections.Generic;
using GamingIsLove.Makinom;

namespace GamingIsLove.ORKFramework
{
	public class ORKTooltipSettings : BaseData
	{
		[EditorHelp("Preview Tooltip", "Tooltips are displayed for the current preview source (e.g. an equipment or ability).\n" +
			"Actual tooltips (e.g. hovering the cursor over a choice or shortcut) will take precedence over preview tooltips.", "")]
		public bool previewTooltip = false;


		// action tooltips
		[EditorHelp("Player Action Tooltip", "Tooltips are displayed for the current action of a player combatant.", "")]
		[EditorSeparator]
		[EditorTitleLabel("Action Tooltips")]
		public bool playerActionTooltip = false;

		[EditorHelp("Ally Action Tooltip", "Tooltips are displayed for the current action of an allied combatant.", "")]
		public bool allyActionTooltip = false;

		[EditorHelp("Enemy Action Tooltip", "Tooltips are displayed for the current action of an enemy combatant.", "")]
		public bool enemyActionTooltip = false;

		[EditorHelp("No Counter Tooltips", "Counter attacks don't display action tooltips.", "")]
		[EditorCondition("playerActionTooltip", true)]
		[EditorCondition("allyActionTooltip", true)]
		[EditorCondition("enemyActionTooltip", true)]
		[EditorEndCondition]
		public bool noCounterTooltips = false;

		public ORKTooltipSettings()
		{

		}
	}
}
