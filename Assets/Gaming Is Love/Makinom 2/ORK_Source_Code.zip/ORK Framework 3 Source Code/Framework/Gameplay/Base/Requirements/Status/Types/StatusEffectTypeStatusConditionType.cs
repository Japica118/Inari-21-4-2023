﻿
using UnityEngine;
using System.Collections.Generic;
using GamingIsLove.Makinom;

namespace GamingIsLove.ORKFramework.Conditions
{
	[EditorSettingInfo("Status Effect Type", "A status effect of the selected status effect type must or mustn't be applied.")]
	public class StatusEffectTypeStatusConditionType : BaseStatusConditionType
	{
		[EditorHelp("Status Effect Type", "Select the status effect type that will be used.", "")]
		public AssetSelection<StatusEffectTypeAsset> effectType = new AssetSelection<StatusEffectTypeAsset>();

		[EditorHelp("Is Applied", "A status effect of the selected status effect type must be applied.\n" +
			"If disabled, an effect mustn't be applied.", "")]
		public bool isApplied = false;

		[EditorHelp("Check Count", "Check the number of applied status effects of the selected type.", "")]
		[EditorCondition("isApplied", true)]
		public bool checkCount = false;

		[EditorCondition("checkCount", true)]
		[EditorEndCondition(2)]
		[EditorAutoInit]
		public ValueCheck<GameObjectSelection> check;

		public StatusEffectTypeStatusConditionType()
		{

		}

		public override string ToString()
		{
			return this.effectType.ToString() + (this.isApplied ?
				" applied" + (this.checkCount ? " count " + this.check.ToString() : "") :
				" not applied");
		}


		/*
		============================================================================
		Check functions
		============================================================================
		*/
		public override bool Check(Combatant combatant)
		{
			if(this.isApplied &&
				this.checkCount)
			{
				return this.check.Check(combatant.Status.Effects.GetTypeAppliedCount(this.effectType), combatant.Call);
			}
			else
			{
				return this.isApplied == combatant.Status.Effects.IsTypeApplied(this.effectType);
			}
		}


		/*
		============================================================================
		Status change register functions
		============================================================================
		*/
		public override void Register(Combatant combatant, IStatusChanged notify)
		{
			combatant.Status.Effects.Added += notify.StatusEffectChanged;
			combatant.Status.Effects.Removed += notify.StatusEffectChanged;
		}

		public override void Unregister(Combatant combatant, IStatusChanged notify)
		{
			combatant.Status.Effects.Added -= notify.StatusEffectChanged;
			combatant.Status.Effects.Removed -= notify.StatusEffectChanged;
		}

		public override void Register(Combatant combatant, Notify notify)
		{
			combatant.Status.Effects.Changed += notify;
		}

		public override void Unregister(Combatant combatant, Notify notify)
		{
			combatant.Status.Effects.Changed -= notify;
		}
	}
}
