﻿
using UnityEngine;
using System.Collections.Generic;
using GamingIsLove.Makinom;

namespace GamingIsLove.ORKFramework.Conditions
{
	[EditorSettingInfo("In Battle", "The combatant must or mustn't be in battle.")]
	public class InBattleStatusConditionType : BaseStatusConditionType
	{
		[EditorHelp("Is In Battle", "The combatant must be in battle.\n" +
			"If disabled, the combatant mustn't be in battle.", "")]
		public bool isInBattle = true;

		public InBattleStatusConditionType()
		{

		}

		public override string ToString()
		{
			return this.isInBattle ? "in battle" : "not in battle";
		}


		/*
		============================================================================
		Check functions
		============================================================================
		*/
		public override bool Check(Combatant combatant)
		{
			return combatant.Battle.InBattle == this.isInBattle;
		}


		/*
		============================================================================
		Status change register functions
		============================================================================
		*/
		public override void Register(Combatant combatant, IStatusChanged notify)
		{
			combatant.Battle.BattleStateChanged += notify.CombatantBattleStateChanged;
		}

		public override void Unregister(Combatant combatant, IStatusChanged notify)
		{
			combatant.Battle.BattleStateChanged -= notify.CombatantBattleStateChanged;
		}

		public override void Register(Combatant combatant, Notify notify)
		{
			combatant.Battle.BattleStateChangedSimple += notify;
		}

		public override void Unregister(Combatant combatant, Notify notify)
		{
			combatant.Battle.BattleStateChangedSimple -= notify;
		}
	}
}
