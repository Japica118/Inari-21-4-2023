﻿
using UnityEngine;
using System.Collections.Generic;
using GamingIsLove.Makinom;

namespace GamingIsLove.ORKFramework
{
	public enum SelectCombatantType { Combatant, GroupTarget, IndividualTarget, LastTarget, AttackedBy, KilledBy, Linked };

	public class SelectCombatantSettings<T> : BaseData where T : IObjectSelection, new()
	{
		[EditorHelp("Combatant Origin", "Select if the combatant itself or e.g. the combatant's last target is used:\n" +
			"- Combatant: Uses the combatant itself.\n" +
			"- Group Target: Uses the combatant's group targets.\n" +
			"- Individual Target: Uses the combatant's individual targets.\n" +
			"- Last Target: Uses the last target(s) of the combatant.\n" +
			"- Attacked By: Uses the combatants the combatant was attacked by.\n" +
			"- Killed By: Uses the combatant that previously killed the combatant.\n" +
			"- Linked: Uses combatants that where linked to the combatant.", "")]
		public SelectCombatantType origin = SelectCombatantType.Combatant;


		// group/individual target
		[EditorHelp("Target Index", "The index of the group/individual target.\n" +
			"Set to -1 to use all available group/individual targets.", "")]
		[EditorLimit(-1, false)]
		[EditorCondition("origin", SelectCombatantType.GroupTarget)]
		[EditorCondition("origin", SelectCombatantType.IndividualTarget)]
		[EditorEndCondition]
		public int targetIndex = -1;


		// linked
		[EditorHelp("Linked Key", "The key used for the combatant link.")]
		[EditorCondition("origin", SelectCombatantType.Linked)]
		[EditorEndCondition]
		[EditorAutoInit]
		public StringValue<T> linkedKey;

		public SelectCombatantSettings()
		{

		}

		public void Get(IDataCall call, Combatant combatant, List<Combatant> list)
		{
			if(combatant != null)
			{
				if(SelectCombatantType.Combatant == this.origin)
				{
					if(!list.Contains(combatant))
					{
						list.Add(combatant);
					}
				}
				else if(SelectCombatantType.GroupTarget == this.origin)
				{
					this.GetSelectedTargets(combatant.Group.SelectedTargets, list);
				}
				else if(SelectCombatantType.IndividualTarget == this.origin)
				{
					this.GetSelectedTargets(combatant.SelectedTargets, list);
				}
				else if(SelectCombatantType.LastTarget == this.origin)
				{
					for(int i = 0; i < combatant.Battle.LastTargets.Count; i++)
					{
						if(list[i] != null &&
							!list.Contains(combatant.Battle.LastTargets[i]))
						{
							list.Add(combatant.Battle.LastTargets[i]);
						}
					}
				}
				else if(SelectCombatantType.AttackedBy == this.origin)
				{
					for(int i = 0; i < combatant.Battle.AttackedBy.Count; i++)
					{
						if(list[i] != null &&
							!list.Contains(combatant.Battle.AttackedBy[i]))
						{
							list.Add(combatant.Battle.AttackedBy[i]);
						}
					}
				}
				else if(SelectCombatantType.KilledBy == this.origin)
				{
					if(combatant.Battle.KilledBy != null &&
						!list.Contains(combatant.Battle.KilledBy))
					{
						list.Add(combatant.Battle.KilledBy);
					}
				}
				else if(SelectCombatantType.Linked == this.origin)
				{
					List<Combatant> linked = combatant.Battle.CombatantLinks.Get(this.linkedKey.GetValue(call));
					if(linked != null)
					{
						for(int i = 0; i < linked.Count; i++)
						{
							if(linked[i] != null &&
								!list.Contains(linked[i]))
							{
								list.Add(linked[i]);
							}
						}
					}
				}
			}
		}

		private void GetSelectedTargets(SelectedTargets selectedTargets, List<Combatant> list)
		{
			if(this.targetIndex == -1)
			{
				for(int i = 0; i < selectedTargets.Count; i++)
				{
					if(selectedTargets[i] != null &&
						!list.Contains(selectedTargets[i]))
					{
						list.Add(selectedTargets[i]);
					}
				}
			}
			else if(this.targetIndex >= 0 &&
				this.targetIndex < selectedTargets.Count &&
				selectedTargets[this.targetIndex] != null &&
				!list.Contains(selectedTargets[this.targetIndex]))
			{
				list.Add(selectedTargets[this.targetIndex]);
			}
		}

		public override string ToString()
		{
			return this.origin.ToString();
		}
	}
}
