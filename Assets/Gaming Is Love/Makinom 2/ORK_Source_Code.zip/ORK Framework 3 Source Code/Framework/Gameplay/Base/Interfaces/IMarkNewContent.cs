﻿
using UnityEngine;
using System.Collections.Generic;
using GamingIsLove.Makinom;

namespace GamingIsLove.ORKFramework
{
	public interface IMarkNewContent
	{
		void UnmarkNewContent(object value);

		bool IsNewContent
		{
			get;
			set;
		}
	}
}
