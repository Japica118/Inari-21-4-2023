﻿
using UnityEngine;
using System.Collections.Generic;
using GamingIsLove.Makinom;

namespace GamingIsLove.ORKFramework.Conditions
{
	[EditorSettingInfo("Class Equipped", "A defined class must or mustn't be equipped on a class slot.")]
	public class ClassEquippedStatusConditionType : BaseStatusConditionType
	{
		[EditorHelp("Class", "Select the class that will be used.", "")]
		public AssetSelection<ClassAsset> checkClass = new AssetSelection<ClassAsset>();

		[EditorHelp("Is Equipped", "The class must be equipped on the combatant (on a class slot).\n" +
			"If disabled, the class mustn't be equipped.", "")]
		public bool isEquipped = true;

		[EditorHelp("Check Class Slot", "Check if the class is equipped on a defined class slot.\n" +
			"If disabled, checks if the class is equipped on any slot.", "")]
		public bool checkClassSlot = false;

		[EditorHelp("Class Slot", "Select the class slot that will be check.", "")]
		[EditorCondition("checkClassSlot", true)]
		[EditorEndCondition]
		public AssetSelection<ClassSlotAsset> classSlot = new AssetSelection<ClassSlotAsset>();

		public ClassEquippedStatusConditionType()
		{

		}

		public override string ToString()
		{
			return this.checkClass.ToString() + (this.isEquipped ? " is equipped" : " not equipped") +
				(this.checkClassSlot ? " on " + this.classSlot.ToString() : "");
		}


		/*
		============================================================================
		Check functions
		============================================================================
		*/
		public override bool Check(Combatant combatant)
		{
			return this.checkClass.StoredAsset != null &&
				combatant.Class.IsEquipped(
					this.checkClassSlot && this.classSlot.StoredAsset != null ?
						this.classSlot.StoredAsset.Settings : null,
					this.checkClass.StoredAsset.Settings) == this.isEquipped;
		}


		/*
		============================================================================
		Status change register functions
		============================================================================
		*/
		public override void Register(Combatant combatant, IStatusChanged notify)
		{
			combatant.Class.SlotsChanged += notify.ClassSlotsChanged;
		}

		public override void Unregister(Combatant combatant, IStatusChanged notify)
		{
			combatant.Class.SlotsChanged -= notify.ClassSlotsChanged;
		}

		public override void Register(Combatant combatant, Notify notify)
		{
			combatant.Class.SlotsChangedSimple += notify;
		}

		public override void Unregister(Combatant combatant, Notify notify)
		{
			combatant.Class.SlotsChangedSimple -= notify;
		}
	}
}
