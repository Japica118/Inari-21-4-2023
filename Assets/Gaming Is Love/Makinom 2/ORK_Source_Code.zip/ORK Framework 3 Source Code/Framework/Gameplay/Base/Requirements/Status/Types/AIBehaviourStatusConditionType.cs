﻿
using UnityEngine;
using System.Collections.Generic;
using GamingIsLove.Makinom;
using GamingIsLove.ORKFramework.AI;

namespace GamingIsLove.ORKFramework.Conditions
{
	[EditorSettingInfo("AI Behaviour", "A defined AI behaviour must or mustn't be equipped on an AI behaviour slot.")]
	public class AIBehaviourStatusConditionType : BaseStatusConditionType
	{
		[EditorHelp("AI Behaviour", "Select the AI behaviour that will be used.", "")]
		public AssetSelection<AIBehaviourAsset> behaviour = new AssetSelection<AIBehaviourAsset>();

		[EditorHelp("Is Equipped", "The AI behaviour must be equipped in one of the combatant's AI slots.\n" +
			"If disabled, the AI behaviour mustn't be equipped.", "")]
		public bool isEquipped = true;

		public AIBehaviourStatusConditionType()
		{

		}

		public override string ToString()
		{
			return this.behaviour.ToString() + (this.isEquipped ? " is equipped" : " not equipped");
		}


		/*
		============================================================================
		Check functions
		============================================================================
		*/
		public override bool Check(Combatant combatant)
		{
			return this.behaviour.StoredAsset != null &&
				combatant.AI.IsAIBehaviourEquipped(this.behaviour.StoredAsset.Settings) == this.isEquipped;
		}


		/*
		============================================================================
		Status change register functions
		============================================================================
		*/
		public override void Register(Combatant combatant, IStatusChanged notify)
		{
			combatant.AI.Changed += notify.CombatantAIChanged;
		}

		public override void Unregister(Combatant combatant, IStatusChanged notify)
		{
			combatant.AI.Changed -= notify.CombatantAIChanged;
		}

		public override void Register(Combatant combatant, Notify notify)
		{
			combatant.AI.SimpleChanged += notify;
		}

		public override void Unregister(Combatant combatant, Notify notify)
		{
			combatant.AI.SimpleChanged -= notify;
		}
	}
}
