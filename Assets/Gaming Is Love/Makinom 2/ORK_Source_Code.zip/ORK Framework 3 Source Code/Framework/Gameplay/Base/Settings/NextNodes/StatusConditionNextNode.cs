
using UnityEngine;
using System.Collections.Generic;
using GamingIsLove.Makinom;

namespace GamingIsLove.ORKFramework
{
	public class StatusConditionNextNode : StatusCondition
	{
		[EditorHide]
		public int next = -1;
		
		public StatusConditionNextNode()
		{
			
		}
	}
}
