﻿
using UnityEngine;
using System.Collections.Generic;
using GamingIsLove.Makinom;

namespace GamingIsLove.ORKFramework
{
	public class ItemConditionalPrefab : BaseData
	{
		public ItemPrefab prefab = new ItemPrefab();


		// variable conditions
		[EditorSeparator]
		[EditorTitleLabel("Variable Conditions")]
		[EditorLabel("The item's variables are available as 'Local' origin.")]
		public VariableCondition<GameObjectSelection> condition = new VariableCondition<GameObjectSelection>();

		public ItemConditionalPrefab()
		{

		}


		/*
		============================================================================
		Check functions
		============================================================================
		*/
		public virtual bool Check(IVariableSource variableSource)
		{
			return this.CheckVariables(variableSource);
		}

		public virtual bool CheckVariables(IVariableSource variableSource)
		{
			if(this.condition.Has)
			{
				return this.condition.CheckVariables(
					new DataCall(ORK.Game.ActiveGroup.Leader,
						variableSource != null && variableSource.HasVariables ? variableSource.Variables : null, null));
			}
			return true;
		}
	}
}
