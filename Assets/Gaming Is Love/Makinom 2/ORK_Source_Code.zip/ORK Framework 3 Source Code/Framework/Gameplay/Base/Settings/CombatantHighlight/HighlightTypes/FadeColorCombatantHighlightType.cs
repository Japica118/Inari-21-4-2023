﻿
using UnityEngine;
using GamingIsLove.Makinom;
using System.Collections.Generic;

namespace GamingIsLove.ORKFramework
{
	[EditorSettingInfo("Fade Color", "Change the color of the combatant's prefab.")]
	public class FadeColorCombatantHighlightType : BaseCombatantHighlightType
	{
		[EditorHelp("Fade Color", "Select if and how the combatant's color will be changed:\n" +
			"- None: No fading.\n" +
			"- Stop: The color stops fading.\n" +
			"- Fade: The color is faded to the value.\n" +
			"- Flash: The color is flashed, i.e. half of the time it'll fade to the color, half ot the time it will fade back.\n" +
			"- Blink: The color starts blinking.", "")]
		public FadeType gameObjectFadeType = FadeType.None;

		[EditorHelp("Fade Children", "All child game objects of the combatant will fade.\n" +
			"If disabled, only the root object of the combatant will fade.", "")]
		[EditorCondition("gameObjectFadeType", FadeType.None)]
		[EditorElseCondition]
		public bool fadeChildren = true;


		// color settings
		[EditorAutoInit]
		[EditorSeparator]
		public PropertyFadeColorSettings gameObjectFade;

		[EditorSeparator]
		[EditorTitleLabel("End Highlight Fade")]
		[EditorCondition("gameObjectFadeType", FadeType.Fade)]
		[EditorEndCondition(2)]
		[EditorAutoInit]
		public PropertyFadeColorSettings gameObjectFadeEnd;

		public FadeColorCombatantHighlightType()
		{

		}


		/*
		============================================================================
		Highlight functions
		============================================================================
		*/
		public override void Highlight(Combatant combatant)
		{
			if(combatant.GameObject != null &&
				FadeType.None != this.gameObjectFadeType &&
				this.gameObjectFade != null)
			{
				this.gameObjectFade.StartFade(this.gameObjectFadeType, combatant,
					this.fadeChildren, Maki.Game.GetUnscaledDeltaTime);
			}
		}

		public override void StopHighlight(Combatant combatant)
		{
			if(combatant.GameObject != null)
			{
				if(FadeType.Fade == this.gameObjectFadeType)
				{
					if(this.gameObjectFadeEnd != null)
					{
						this.gameObjectFadeEnd.StartFade(this.gameObjectFadeType, combatant,
							this.fadeChildren, Maki.Game.GetUnscaledDeltaTime);
					}
				}
				else if(FadeType.None != this.gameObjectFadeType &&
					this.gameObjectFade != null)
				{
					this.gameObjectFade.StopFade(combatant, this.fadeChildren, true);
				}
			}
		}
	}
}
