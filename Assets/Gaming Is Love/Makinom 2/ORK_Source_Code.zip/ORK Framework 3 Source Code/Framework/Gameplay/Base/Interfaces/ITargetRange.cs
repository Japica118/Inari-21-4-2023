﻿
using UnityEngine;
using System.Collections.Generic;
using GamingIsLove.Makinom;

namespace GamingIsLove.ORKFramework
{
	public interface ITargetRange
	{
		/*
		============================================================================
		Target range functions
		============================================================================
		*/
		bool IsNoneTarget();

		bool IsSingleTarget();

		bool IsGroupTarget();

		void ToggleTargetRange();

		bool CanToggleTargetRange();
	}
}
