﻿
using UnityEngine;
using System.Collections.Generic;
using GamingIsLove.Makinom;

namespace GamingIsLove.ORKFramework
{
	public class SearchCombatantSettings : BaseData
	{
		// search settings
		[EditorHelp("Add Player Group", "Include members of the player group.", "")]
		[EditorTitleLabel("Search Settings")]
		public bool addPlayerGroup = true;

		[EditorHelp("Is Enemy", "Select if the combatants are enemies of the user:\n" +
			"- Yes: The combatants are enemies.\n" +
			"- No: The combatants are allies.\n" +
			"- Ignore: Ignores the faction standings.", "")]
		public Consider isEnemy = Consider.Ignore;

		[EditorHelp("Is Dead", "Select if the combatants are dead:\n" +
			"- Yes: The combatants are dead.\n" +
			"- No: The combatants are alive.\n" +
			"- Ignore: Ignores the death state.", "")]
		public Consider isDead = Consider.Ignore;

		[EditorHelp("In Battle", "Select if the combatants are in battle:\n" +
			"- Yes: The combatants are in battle.\n" +
			"- No: The combatants are not in battle.\n" +
			"- Ignore: Ignores the battle state.", "")]
		public Consider inBattle = Consider.Ignore;


		// status conditions
		[EditorSeparator]
		[EditorTitleLabel("Status Conditions")]
		public StatusConditionSettings statusConditions = new StatusConditionSettings();

		public SearchCombatantSettings()
		{

		}


		/*
		============================================================================
		Search functions
		============================================================================
		*/
		public virtual List<Combatant> Search(Combatant user, IRange range)
		{
			return ORK.Game.Combatants.Get(user, this.addPlayerGroup, range,
				this.isEnemy, this.isDead, this.inBattle, this.CheckConditions);
		}

		public virtual List<Combatant> Search(Vector3 position, Combatant user, IRange range)
		{
			return ORK.Game.Combatants.Get(position, user, this.addPlayerGroup, range,
				this.isEnemy, this.isDead, this.inBattle, this.CheckConditions);
		}


		/*
		============================================================================
		Check functions
		============================================================================
		*/
		public virtual bool CheckConditions(Combatant user, Combatant target)
		{
			return this.statusConditions.Check(target);
		}
	}
}
