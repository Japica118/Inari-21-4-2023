﻿
using UnityEngine;
using GamingIsLove.Makinom;
using System.Collections.Generic;

namespace GamingIsLove.ORKFramework
{
	[EditorSettingInfo("Fade HUD Color", "Change the color of the combatant's HUDs.")]
	public class FadeHUDColorCombatantHighlightType : BaseCombatantHighlightType
	{
		[EditorHelp("Fade HUD", "Select if and how the combatant's HUDs color will be changed:\n" +
			"- None: No fading.\n" +
			"- Stop: The color stops fading.\n" +
			"- Fade: The color is faded to the value.\n" +
			"- Flash: The color is flashed, i.e. half of the time it'll fade to the color, half ot the time it will fade back.\n" +
			"- Blink: The color starts blinking.", "")]
		public FadeType hudFadeType = FadeType.None;

		[EditorCondition("hudFadeType", FadeType.None)]
		[EditorElseCondition]
		[EditorAutoInit]
		public FadeColorSettings hudFade;

		[EditorSeparator]
		[EditorTitleLabel("End Selection Fade")]
		[EditorCondition("hudFadeType", FadeType.Fade)]
		[EditorEndCondition(2)]
		[EditorAutoInit]
		public FadeColorSettings hudFadeEnd;

		public FadeHUDColorCombatantHighlightType()
		{

		}


		/*
		============================================================================
		Highlight functions
		============================================================================
		*/
		public override void Highlight(Combatant combatant)
		{
			if(FadeType.None != this.hudFadeType &&
				this.hudFade != null)
			{
				combatant.UI.StartFade(this.hudFadeType, this.hudFade);
			}
		}

		public override void StopHighlight(Combatant combatant)
		{
			if(FadeType.Fade == this.hudFadeType &&
				this.hudFadeEnd != null)
			{
				combatant.UI.StartFade(this.hudFadeType, this.hudFadeEnd);
			}
			else if(FadeType.None != this.hudFadeType)
			{
				combatant.UI.StopFade(this.hudFade);
			}
		}
	}
}
