
using UnityEngine;
using System.Collections.Generic;
using GamingIsLove.Makinom;
using GamingIsLove.ORKFramework.AI;

namespace GamingIsLove.ORKFramework
{
	public class StatisticSelection<T> : BaseData where T : IObjectSelection, new()
	{
		[EditorHelp("Statistic", "Select the statistic value that will be used.", "")]
		public StatisticType type = StatisticType.TotalKilled;

		[EditorHelp("Combatant", "Select the combatant that will be used.", "")]
		[EditorCondition("type", StatisticType.SingleKilled)]
		[EditorEndCondition]
		public AssetSelection<CombatantAsset> combatant = new AssetSelection<CombatantAsset>();

		[EditorHelp("Item", "Select the item that will be used.", "")]
		[EditorCondition("type", StatisticType.SingleUsed)]
		[EditorCondition("type", StatisticType.SingleCreatedItem)]
		[EditorCondition("type", StatisticType.SingleGainedItem)]
		[EditorEndCondition]
		public AssetSelection<ItemAsset> item = new AssetSelection<ItemAsset>();

		[EditorHelp("Equipment", "Select the equipment that will be used.", "")]
		[EditorCondition("type", StatisticType.SingleCreatedEquipment)]
		[EditorCondition("type", StatisticType.SingleGainedEquipment)]
		[EditorEndCondition]
		public AssetSelection<EquipmentAsset> equipment = new AssetSelection<EquipmentAsset>();

		[EditorHelp("AI Behaviour", "Select the AI behaviour that will be used.", "")]
		[EditorCondition("type", StatisticType.SingleCreatedAIBehaviour)]
		[EditorCondition("type", StatisticType.SingleGainedAIBehaviour)]
		[EditorEndCondition]
		public AssetSelection<AIBehaviourAsset> aiBehaviour = new AssetSelection<AIBehaviourAsset>();

		[EditorHelp("AI Ruleset", "Select the AI ruleset that will be used.", "")]
		[EditorCondition("type", StatisticType.SingleCreatedAIRuleset)]
		[EditorCondition("type", StatisticType.SingleGainedAIRuleset)]
		[EditorEndCondition]
		public AssetSelection<AIRulesetAsset> aiRuleset = new AssetSelection<AIRulesetAsset>();

		[EditorHelp("Crafting Recipe", "Select the crafting recipe that will be used.", "")]
		[EditorCondition("type", StatisticType.SingleCreatedCraftingRecipes)]
		[EditorCondition("type", StatisticType.SingleGainedCraftingRecipes)]
		[EditorEndCondition]
		public AssetSelection<CraftingRecipeAsset> recipe = new AssetSelection<CraftingRecipeAsset>();

		[EditorSeparator]
		[EditorHelp("Statistic Index", "The index of the custom statistic.\n" +
			"Has to be 0 or above.")]
		[EditorLabel("Only indexes of 0 and above are available.")]
		[EditorCondition("type", StatisticType.Custom)]
		[EditorEndCondition]
		[EditorAutoInit]
		public FloatValue<T> customIndex;

		public StatisticSelection()
		{

		}


		/*
		============================================================================
		Statistic functions
		============================================================================
		*/
		public void Clear(IDataCall call)
		{
			if(StatisticType.SingleKilled == this.type)
			{
				if(this.combatant.StoredAsset != null)
				{
					ORK.Statistic.Clear(this.type, this.combatant.StoredAsset.Settings.ID);
				}
			}
			else if(StatisticType.SingleUsed == this.type ||
				StatisticType.SingleCreatedItem == this.type ||
				StatisticType.SingleGainedItem == this.type)
			{
				if(this.item.StoredAsset != null)
				{
					ORK.Statistic.Clear(this.type, this.item.StoredAsset.Settings.ID);
				}
			}
			else if(StatisticType.SingleCreatedEquipment == this.type ||
				StatisticType.SingleGainedEquipment == this.type)
			{
				if(this.equipment.StoredAsset != null)
				{
					ORK.Statistic.Clear(this.type, this.equipment.StoredAsset.Settings.ID);
				}
			}
			else if(StatisticType.SingleCreatedAIBehaviour == this.type ||
				StatisticType.SingleGainedAIBehaviour == this.type)
			{
				if(this.aiBehaviour.StoredAsset != null)
				{
					ORK.Statistic.Clear(this.type, this.aiBehaviour.StoredAsset.Settings.ID);
				}
			}
			else if(StatisticType.SingleCreatedAIRuleset == this.type ||
				StatisticType.SingleGainedAIRuleset == this.type)
			{
				if(this.aiRuleset.StoredAsset != null)
				{
					ORK.Statistic.Clear(this.type, this.aiRuleset.StoredAsset.Settings.ID);
				}
			}
			else if(StatisticType.SingleCreatedCraftingRecipes == this.type ||
				StatisticType.SingleGainedCraftingRecipes == this.type)
			{
				if(this.recipe.StoredAsset != null)
				{
					ORK.Statistic.Clear(this.type, this.recipe.StoredAsset.Settings.ID);
				}
			}
			else if(StatisticType.Custom == this.type)
			{
				ORK.Statistic.Clear(this.type, (int)this.customIndex.GetValue(call));
			}
			else
			{
				ORK.Statistic.Clear(this.type, -1);
			}
		}

		public int Get(IDataCall call)
		{
			if(StatisticType.SingleKilled == this.type)
			{
				if(this.combatant.StoredAsset != null)
				{
					return ORK.Statistic.Get(this.type, this.combatant.StoredAsset.Settings.ID);
				}
			}
			else if(StatisticType.SingleUsed == this.type ||
				StatisticType.SingleCreatedItem == this.type ||
				StatisticType.SingleGainedItem == this.type)
			{
				if(this.item.StoredAsset != null)
				{
					return ORK.Statistic.Get(this.type, this.item.StoredAsset.Settings.ID);
				}
			}
			else if(StatisticType.SingleCreatedEquipment == this.type ||
				StatisticType.SingleGainedEquipment == this.type)
			{
				if(this.equipment.StoredAsset != null)
				{
					return ORK.Statistic.Get(this.type, this.equipment.StoredAsset.Settings.ID);
				}
			}
			else if(StatisticType.SingleCreatedAIBehaviour == this.type ||
				StatisticType.SingleGainedAIBehaviour == this.type)
			{
				if(this.aiBehaviour.StoredAsset != null)
				{
					return ORK.Statistic.Get(this.type, this.aiBehaviour.StoredAsset.Settings.ID);
				}
			}
			else if(StatisticType.SingleCreatedAIRuleset == this.type ||
				StatisticType.SingleGainedAIRuleset == this.type)
			{
				if(this.aiRuleset.StoredAsset != null)
				{
					return ORK.Statistic.Get(this.type, this.aiRuleset.StoredAsset.Settings.ID);
				}
			}
			else if(StatisticType.SingleCreatedCraftingRecipes == this.type ||
				StatisticType.SingleGainedCraftingRecipes == this.type)
			{
				if(this.recipe.StoredAsset != null)
				{
					return ORK.Statistic.Get(this.type, this.recipe.StoredAsset.Settings.ID);
				}
			}
			else if(StatisticType.Custom == this.type)
			{
				return ORK.Statistic.Get(this.type, (int)this.customIndex.GetValue(call));
			}
			else
			{
				return ORK.Statistic.Get(this.type, -1);
			}
			return 0;
		}


		/*
		============================================================================
		Editor functions
		============================================================================
		*/
		public override string ToString()
		{
			if(StatisticType.SingleKilled == this.type)
			{
				return this.type.ToString() + " " + this.combatant.ToString();
			}
			else if(StatisticType.SingleUsed == this.type ||
				StatisticType.SingleCreatedItem == this.type ||
				StatisticType.SingleGainedItem == this.type)
			{
				return this.type.ToString() + " " + this.item.ToString();
			}
			else if(StatisticType.SingleCreatedEquipment == this.type ||
				StatisticType.SingleGainedEquipment == this.type)
			{
				return this.type.ToString() + " " + this.equipment.ToString();
			}
			else if(StatisticType.SingleCreatedAIBehaviour == this.type ||
				StatisticType.SingleGainedAIBehaviour == this.type)
			{
				return this.type.ToString() + " " + this.aiBehaviour.ToString();
			}
			else if(StatisticType.SingleCreatedAIRuleset == this.type ||
				StatisticType.SingleGainedAIRuleset == this.type)
			{
				return this.type.ToString() + " " + this.aiRuleset.ToString();
			}
			else if(StatisticType.SingleCreatedCraftingRecipes == this.type ||
				StatisticType.SingleGainedCraftingRecipes == this.type)
			{
				return this.type.ToString() + " " + this.recipe.ToString();
			}
			return this.type.ToString();
		}
	}
}
