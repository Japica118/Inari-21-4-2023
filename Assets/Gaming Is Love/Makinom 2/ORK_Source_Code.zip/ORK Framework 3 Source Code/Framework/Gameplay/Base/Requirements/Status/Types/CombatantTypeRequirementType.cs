﻿
using UnityEngine;
using System.Collections.Generic;
using GamingIsLove.Makinom;

namespace GamingIsLove.ORKFramework.Conditions
{
	[EditorSettingInfo("Combatant Type", "The combatant must or mustn't be of the selected combatant type.")]
	public class CombatantTypeStatusConditionType : BaseStatusConditionType
	{
		[EditorHelp("Combatant Type", "Select the combatant type that will be used.", "")]
		public AssetSelection<CombatantTypeAsset> combatantType = new AssetSelection<CombatantTypeAsset>();

		[EditorHelp("Use Sub-Types", "The sub-types of the defined combatant type will also be checked.", "")]
		[EditorIndent]
		public bool useSubTypes = false;

		[EditorHelp("Is Combatant Type", "The combatant must be the selected combatant type.\n" +
			"If disabled, the combatant mustn't be the selected combatant type.", "")]
		public bool isCombatantType = true;

		public CombatantTypeStatusConditionType()
		{

		}

		public override string ToString()
		{
			return (this.isCombatantType ? "is " : "not ") + this.combatantType.ToString();
		}


		/*
		============================================================================
		Check functions
		============================================================================
		*/
		public override bool Check(Combatant combatant)
		{
			return this.combatantType.StoredAsset != null &&
				(this.isCombatantType == (this.combatantType.Is(combatant.CombatantType) ||
					(this.useSubTypes &&
						combatant.CombatantType != null &&
						combatant.CombatantType.IsSubTypeOf(this.combatantType.StoredAsset.Settings))));
		}


		/*
		============================================================================
		Status change register functions
		============================================================================
		*/
		public override void Register(Combatant combatant, IStatusChanged notify)
		{

		}

		public override void Unregister(Combatant combatant, IStatusChanged notify)
		{

		}
		public override void Register(Combatant combatant, Notify notify)
		{

		}

		public override void Unregister(Combatant combatant, Notify notify)
		{

		}
	}
}
