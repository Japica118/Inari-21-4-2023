﻿
using UnityEngine;
using System.Collections.Generic;
using GamingIsLove.Makinom;

namespace GamingIsLove.ORKFramework.Conditions
{
	[EditorSettingInfo("Turn State", "The combatant's turn state must or mustn't match a defined state.")]
	public class TurnStateStatusConditionType : BaseStatusConditionType
	{
		[EditorHelp("Turn State", "Select the turn state that will be checked for:\n" +
			"- Before Turn: The combatant is waiting to perform a new turn.\n" +
			"- In Turn: The combatant is currently performing the turn.\n" +
			"- After Turn: The combatant ended the turn.", "")]
		public CombatantTurnState turnState = CombatantTurnState.AfterTurn;

		[EditorHelp("Is Valid", "The combatant's turn state must be valid (i.e. match the defined state).\n" +
			"If disabled, the combatant's turn state mustn't be valid (i.e. not match the defined state).", "")]
		public bool isTurnStateValid = true;

		public TurnStateStatusConditionType()
		{

		}

		public override string ToString()
		{
			return (this.isTurnStateValid ? "is " : "not ") + this.turnState;
		}


		/*
		============================================================================
		Check functions
		============================================================================
		*/
		public override bool Check(Combatant combatant)
		{
			return (combatant.Battle.TurnState == this.turnState) == this.isTurnStateValid;
		}


		/*
		============================================================================
		Status change register functions
		============================================================================
		*/
		public override void Register(Combatant combatant, IStatusChanged notify)
		{
			combatant.Battle.TurnStateChanged += notify.CombatantTurnStateChanged;
		}

		public override void Unregister(Combatant combatant, IStatusChanged notify)
		{
			combatant.Battle.TurnStateChanged -= notify.CombatantTurnStateChanged;
		}

		public override void Register(Combatant combatant, Notify notify)
		{
			combatant.Battle.TurnStateChangedSimple += notify;
		}

		public override void Unregister(Combatant combatant, Notify notify)
		{
			combatant.Battle.TurnStateChangedSimple -= notify;
		}
	}
}
