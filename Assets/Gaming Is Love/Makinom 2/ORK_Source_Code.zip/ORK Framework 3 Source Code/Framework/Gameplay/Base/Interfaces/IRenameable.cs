﻿
using UnityEngine;
using System.Collections.Generic;
using GamingIsLove.Makinom;

namespace GamingIsLove.ORKFramework
{
	public interface IRenameable
	{
		string RenameableName
		{
			get;
			set;
		}

		string RenameableDescription
		{
			get;
			set;
		}
	}
}
