﻿
using UnityEngine;
using System.Collections.Generic;
using GamingIsLove.Makinom;

namespace GamingIsLove.ORKFramework.Conditions
{
	[EditorSettingInfo("Research Item", "The state of a defined research item will be checked.\n" +
		"Can also check the research count of the research item.")]
	public class ResearchItemStatusConditionType : BaseStatusConditionType
	{
		[EditorHelp("Research Tree", "Select the research tree that will be used.")]
		public AssetSelection<ResearchTreeAsset> researchTree = new AssetSelection<ResearchTreeAsset>();

		[EditorHelp("Research Item", "Select the research item that will be used.")]
		[EditorInfo("researchTree")]
		public int researchItem = 0;

		[EditorHelp("Check Research Count", "Check how often the research item has been researched.\n" +
			"If disabled, the state of the research item will be checked.", "")]
		public bool checkResearchCount = false;

		[EditorCondition("checkResearchCount", true)]
		public ValueCheck<GameObjectSelection> check = new ValueCheck<GameObjectSelection>();

		[EditorHelp("Research Item State", "Select the state that will be checked for:\n" +
			"- Unresearched: The research item hasn't yet been researched.\n" +
			"- In Research: The research item is currently in research.\n" +
			"- Researched: The research item has been researched (at least once).\n" +
			"- Complete: The research item has been fully researched (i.e. reached the limit).", "")]
		[EditorElseCondition]
		[EditorEndCondition]
		public ResearchItemState researchItemState = ResearchItemState.Unresearched;

		public ResearchItemStatusConditionType()
		{

		}

		public override string ToString()
		{
			return this.researchTree.ToString() +
				(this.researchTree.StoredAsset != null ?
					" " + this.researchTree.StoredAsset.Settings.GetEditorSubDataName(this.researchItem) + " " :
					" ? ") +
				(this.checkResearchCount ? "research count " + this.check.ToString() : this.researchItemState.ToString());
		}


		/*
		============================================================================
		Check functions
		============================================================================
		*/
		public override bool Check(Combatant combatant)
		{
			if(this.researchTree.StoredAsset != null)
			{
				return this.checkResearchCount ?
					combatant.Research.CheckItemResearchCount(
						this.researchTree.StoredAsset.Settings,
						this.researchItem, this.check) :
					combatant.Research.CheckItemState(
						this.researchTree.StoredAsset.Settings,
						this.researchItem, this.researchItemState);
			}
			return false;
		}


		/*
		============================================================================
		Status change register functions
		============================================================================
		*/
		public override void Register(Combatant combatant, IStatusChanged notify)
		{
			combatant.Research.Changed += notify.CombatantResearchChanged;
		}

		public override void Unregister(Combatant combatant, IStatusChanged notify)
		{
			combatant.Research.Changed -= notify.CombatantResearchChanged;
		}

		public override void Register(Combatant combatant, Notify notify)
		{
			combatant.Research.ChangedSimple += notify;
		}

		public override void Unregister(Combatant combatant, Notify notify)
		{
			combatant.Research.ChangedSimple -= notify;
		}
	}
}
