
using UnityEngine;
using GamingIsLove.ORKFramework;
using GamingIsLove.ORKFramework.Components;
using System.Collections.Generic;
using GamingIsLove.Makinom;

namespace GamingIsLove.ORKFramework.AI
{
	public class MoveAIAsset : MakinomGenericAsset<MoveAISetting>
	{
		public MoveAIAsset()
		{

		}

		public override string DataName
		{
			get { return "Move AI"; }
		}
	}

	public class MoveAISetting : BaseIndexData
	{
		[EditorHelp("Name", "The name of the AI movement.", "")]
		[EditorFoldout("Base Settings", "Set the name and base settings of the move AI.", "")]
		[EditorWidth(true)]
		public string name = "";

		[EditorHelp("Use Mode", "Select the use mode of this move AI:\n" +
			"- Auto: Automatically uses the different behaviours (e.g. hunting, fleeing).\n" +
			"- Idle: Forces idle mode, only following waypoints (if used).\n" +
			"- Hunt: Forces hunting.\n" +
			"- Flee: Forces fleeing.\n" +
			"- Caution: Forces caution.\n" +
			"- Protect: Forces protecting group members.", "")]
		[EditorLabel("The move AI only defines the target/position to move to and the movement speed, the actual movement is handled by the combatant's movement component.\n" +
			"The default movement component is set up in 'Combatants > Combatants > General Settings', each combatant can optionally override the default component.")]
		public MoveAIUseMode useMode = MoveAIUseMode.Auto;

		public HorizontalPlaneOverride horizontalPlane = new HorizontalPlaneOverride();

		// action allowed
		[EditorHelp("Allow During Actions", "The move AI can be used while the combatant is performing an action.\n" +
			"Casting an action controls if the combatant's move AI is allowed via it's 'Move While Casting' setting (in the cast time settings).")]
		[EditorSeparator]
		public bool allowDuringActions = false;


		// move range
		[EditorHelp("Use Move Range", "The combatant will only move within a range of its start position " +
			"(i.e. the position it has been spawned at).\n" +
			"When leaving the move range, the combatant will return to its start position.\n" +
			"If disabled, there is no limit to the move range.\n" +
			"The move range overrules other ranges (e.g. the hunting range).", "")]
		[EditorFoldout("Move Range", "Optionally limit the area the a combatant can move in.\n" +
			"The move range can also be overruled by 'Move AI Range' components defined in 'Combatant Spawner' and 'Add Combatant' components.")]
		public bool useMoveRange = false;

		[EditorEndFoldout]
		[EditorCondition("useMoveRange", true)]
		[EditorEndCondition]
		[EditorAutoInit]
		public RangeValue moveRange;

		// auto stop
		[EditorHelp("Use Auto Stop", "The combatant will automatically stop when not moving for a defined amount of time.\n" +
			"Use this when the combatant seems to get stuck, e.g. due to the position not being reachable.", "")]
		[EditorFoldout("Auto Stop Settings", "Optionally stop automatically when not moving for a defined amount of time.")]
		public bool autoStop = true;

		[EditorHelp("Stop Distance", "The distance in world units to the last movement position, " +
			"being below this distance will start the stop time.", "")]
		[EditorCondition("autoStop", true)]
		public float stopDistance = 0.1f;

		[EditorHelp("Stop Time (s)", "The time in seconds until the combatant will stop, unless the combatant continues moving again (i.e. distance increases)", "")]
		public float stopTime = 0.5f;

		[EditorHelp("Clear Target", "Clear the target the combatant was following or hunting when auto stopping.", "")]
		[EditorEndFoldout]
		[EditorEndCondition]
		public bool stopClear = false;


		// speed settings
		[EditorFoldout("Speed Settings", "Define the move speed for the different modes of the move AI (i.e. following, hunting, fleeing).", "")]
		[EditorTitleLabel("Follow Speed")]
		public MoveSpeed<GameObjectSelection> followSpeed = new MoveSpeed<GameObjectSelection>(MoveSpeedType.Run, 5);

		[EditorSeparator]
		[EditorTitleLabel("Give Way Speed")]
		public MoveSpeed<GameObjectSelection> giveWaySpeed = new MoveSpeed<GameObjectSelection>(MoveSpeedType.Walk, 5);

		[EditorSeparator]
		[EditorTitleLabel("Hunting Speed")]
		public MoveSpeed<GameObjectSelection> huntingSpeed = new MoveSpeed<GameObjectSelection>(MoveSpeedType.Run, 5);

		[EditorSeparator]
		[EditorTitleLabel("Flee Speed")]
		public MoveSpeed<GameObjectSelection> fleeSpeed = new MoveSpeed<GameObjectSelection>(MoveSpeedType.Run, 5);

		[EditorSeparator]
		[EditorTitleLabel("Protection Speed")]
		public MoveSpeed<GameObjectSelection> protectionSpeed = new MoveSpeed<GameObjectSelection>(MoveSpeedType.Run, 5);

		[EditorSeparator]
		[EditorTitleLabel("Waypoint Speed")]
		public MoveSpeed<GameObjectSelection> waypointSpeed = new MoveSpeed<GameObjectSelection>(MoveSpeedType.Run, 5);

		[EditorSeparator]
		[EditorTitleLabel("Point Of Interest Speed")]
		[EditorEndFoldout(2)]
		public MoveSpeed<GameObjectSelection> pointOfInterestSpeed = new MoveSpeed<GameObjectSelection>(MoveSpeedType.Run, 5);


		// waypoint settings
		[EditorHelp("Start in Waypoint Mode", "The combatant will start following waypoints when spawned.\n" +
			"If disabled, the combatant will first use an idle schematic (if used) before switching to waypoint mode.")]
		[EditorFoldout("Waypoint Settings", "The combatant can follow defined waypoints or randomly patrol in the scene.\n" +
			"To follow waypoints, you have to add the waypoints to the combatant's settings in the scene (inspector).\n" +
			"Uses the 'Waypoint Speed' to move.\n" +
			"Randomly patroling or following defined waypoints is only done if the combatant isn't " +
			"following someone (e.g. the leader or an enemy).", "")]
		public bool startInWaypointMode = true;

		[EditorHelp("Stop Distance", "The distance in world units the combatant will stop before reaching a waypoint.", "")]
		[EditorLimit(0.0f, false)]
		public float waypointStopDistance = 0.1f;

		[EditorHelp("No Combatant Radius", "The combatant radius setting of the combatants will " +
			"be ignored when calculating the distance to a waypoint.", "")]
		public bool waypointIgnoreRadius = false;

		[EditorHelp("Reset Time (s)", "The time in seconds before the combatant switches to the " +
			"next waypoint when not reaching the current one.\n" +
			"The combatant needs to stand still for the time to start.", "")]
		public float waypointResetTime = 1;

		// random patrol
		[EditorHelp("Enable Random Patrol", "The combatant will randomly patrol in the scene.\n" +
			"The random patrol can be overridden by waypoints added to a spawned combatant (e.g. in their inspector in the scene).\n" +
			"The random patrol area can be limited using a 'Move AI Range' and 'No Random Patrol' components.", "")]
		[EditorSeparator]
		public bool randomPatrol = false;

		[EditorHelp("Patrol Radius", "The radius around the original spawn point used to patrol.\n" +
			"If in a group, the group leader will be the center of the area.", "")]
		[EditorCondition("randomPatrol", true)]
		public float patrolRadius = 20.0f;

		[EditorHelp("From Current Position", "The patrol radius is used from the current position of the combatant.\n" +
			"If disabled, the patrol radius is used from the original start position of the combatant.", "")]
		public bool patrolFromCurrent = false;

		// patrol raycast
		[EditorHelp("Use Raycast", "Use a raycast to check if a 'No Random Patrol' game object was hit.\n" +
			"Otherwise will only check if a position is within a 'No Random Patrol' area.", "")]
		public bool patrolUseRaycast = false;

		[EditorHelp("Raycast Distance", "The distance the raycast will check to find 'No Random Patrol' game objects.", "")]
		[EditorLimit(0.0f, false)]
		[EditorCondition("patrolUseRaycast", true)]
		public float raycastDistance = 100.0f;

		[EditorHelp("Raycast Height Offset", "Offset added to the raycast's position on the height axis (depending on the horizontal plane, either Y or Z).", "")]
		[EditorLimit(0.0f, false)]
		public float raycastHeightOffset = 50.0f;

		[EditorHelp("Layer Mask", "Select the layers the raycast will check.", "")]
		[EditorEndCondition(2)]
		public LayerMask layerMask = -1;

		// points of interest
		[EditorHelp("Use Points Of Interest", "The combatant can detect 'Point Of Interest' components in the scene while being in waypoint mode.\n" +
			"The combatant will move to a detected point of interest and start it's schematic, " +
			"using the combatant as 'Machine Object' actor and the POI as 'Starting Object'.", "")]
		[EditorFoldout("Points Of Interest", "The combatant can optionally detect points of interest while in waypoing mode.\n" +
			"Detection is handled by the 'Enemy Detection' settings and detects POIs with matching tags - " +
			"if no detection tag is added here, the combatant can detect all POIs.\n" +
			"Points of interest can be added to game objects in a scene using a 'Point Of Interest' component. " +
			"The combatant will move to a detected POI and perform the schematic set up on it, " +
			"using the combatant as 'Machine Object' actor and the POI as 'Starting Object'.", "")]
		public bool usePointsOfInterest = true;

		[EditorHelp("Detection Tag", "Can detect points of interest with a matching tag.", "")]
		[EditorEndFoldout]
		[EditorWidth(300)]
		[EditorArray("Add Detection Tag", "Add a point of interest detection tag.\n" +
			"The combatant can detect all points of interest if no tag is added.", "",
			"Remove", "Removes this tag", "", isHorizontal = true)]
		[EditorCondition("usePointsOfInterest", true)]
		[EditorEndCondition]
		public string[] pointOfInterestTag = new string[0];


		// idle schematics
		[EditorHelp("Enable Idle", "Use schematics to animate an idle combatant in between waypoints.\n" +
			"If disabled, the combatant won't use idle schematics and won't stop between waypoints.", "")]
		[EditorFoldout("Idle Settings", "Define how the combatant acts while standing still, e.g. while waiting at a waypoint.", "")]
		public bool useIdle = false;

		[EditorHelp("Random", "A random idle schematic will be used.\n" +
			"If disabled, the idle schematics will be used in sequence.", "")]
		[EditorCondition("useIdle", true)]
		public bool idleRandom = false;

		[EditorEndFoldout(2)]
		[EditorArray("Add Idle Schematic", "Adds an idle schematic setting.", "",
			"Remove", "Removes this idle schematic.", "",
			isMove = true, isCopy = true,
			foldout = true, foldoutText = new string[] {
				"Idle Schematic", "Idle schematics are used to animate (or do other things) a combatant while standing still.\n" +
				"If the chance fails, no other schematic will be selected instead.", ""
			})]
		[EditorAutoInit]
		[EditorEndCondition]
		public MoveAIIdle[] idleSchematic;


		// follow leader
		[EditorHelp("Follow Leader", "The combatant will follow the group leader if outside a defined range to the leader.", "")]
		[EditorFoldout("Group Settings", "Define if the combatant will follow its group leader.", "")]
		public bool followLeader = false;

		[EditorHelp("Next In Line", "The combatant will follow the next combatant in line (battle group index).\n" +
			"Use this to prevent everyone from following the leader and move in a line instead.\n" +
			"'Auto Respawn' and 'Give Way' range checks will still use the actual group's leader.", "")]
		[EditorIndent]
		[EditorCondition("followLeader", true)]
		public bool followNextInLine = false;

		[EditorHelp("Stop Hunting", "The combatant won't hunt if following its group leader.\n" +
			"Only the leader of a group will hunt (if all group members have this option enabled).\n" +
			"If disabled, the combatant will still hunt, even while following its leader.", "")]
		public bool leaderStopHunt = true;

		[EditorHelp("No Waypoints", "The combatant won't follow waypoints or randomly patrol if following its group leader.\n" +
			"Only the leader of a group will follow waypoints (if all group members have this option enabled).\n" +
			"If disabled, the combatant will still follow waypoints, even while following its leader " +
			"(when not outside the follow range).", "")]
		public bool leaderNoWaypoint = true;

		[EditorHelp("Use Leader Position", "Use the leader's position for following (or the next in line's position).\n" +
			"If disabled, uses the in-range position (based on the follow range).")]
		public bool followLeaderPosition = false;

		[EditorFoldout("Follow Range", "The combatant will follow his leader when being outside this range.", "")]
		[EditorEndFoldout]
		public RangeValue followLeaderRange = new RangeValue(5, 0.5f);

		// give way
		[EditorHelp("Give Way", "The combatant will move out of the way of its leader when inside a defined range to the leader.", "")]
		[EditorFoldout("Give Way", "The combatant can move out of the way of its leader when inside a defined range to the leader.", "")]
		public bool giveWay = false;

		[EditorEndFoldout]
		[EditorCondition("giveWay", true)]
		[EditorEndCondition]
		public RangeValue giveWayRange = new RangeValue(1, 0.5f);

		// auto respawn
		[EditorHelp("Auto Respawn", "The combatant will automatically respawn near its leader when outside a defined range to the leader.", "")]
		[EditorFoldout("Auto Respawn", "The combatant can automatically respawn near its leader when outside a defined range to the leader.", "")]
		public bool autoRespawn = false;

		[EditorEndFoldout]
		[EditorCondition("autoRespawn", true)]
		[EditorEndCondition(2)]
		public RangeValue autoRespawnRange = new RangeValue(50);

		// leader priority
		[EditorHelp("Prioritise Leader", "Following the leader takes priority over other movement when outside a defined range.\n" +
			"If disabled, the combatant will continue movement toward his current target ignoring the leader.", "")]
		[EditorFoldout("Prioritise Leader", "Following the leader can take priority over other movement when outside a defined range.", "")]
		public bool leaderPriority = false;

		[EditorEndFoldout(2)]
		[EditorCondition("leaderPriority", true)]
		[EditorEndCondition]
		public RangeValue leaderPriorityRange = new RangeValue(10, 0.5f);


		// enemy detection
		// base range
		[EditorHelp("Use Detection", "Use enemy detection - this is needed for hunting and fleeing.\n" +
			"If disabled, the combatant can't hunt or flee from enemy combatants.", "")]
		[EditorFoldout("Enemy Detection", "Define how enemies are detected.\n" +
			"Only detected enemy combatants can be hunted or fled from.", "")]
		public bool useDetection = false;

		[EditorHelp("Use Group Detection", "Combatants detected by the user's group members will also be used.", "")]
		[EditorCondition("useDetection", true)]
		public bool useGroupDetection = false;

		[EditorHelp("Detect Only Leader", "Only enemy group leaders will be detected.\n" +
			"If disabled, all ememy group members can be detected.", "")]
		public bool detectOnlyLeader = false;

		[EditorHelp("Detect On Aggression", "Detect combatants that made the combatant aggressive.\n" +
			"The combatants will be hunted.", "")]
		public bool detectOnAggression = false;

		[EditorHelp("Detect On Damage", "Detect combatants that damage the combatant.\n" +
			"The combatants will be hunted.", "")]
		public bool detectOnDamage = false;

		[EditorHelp("Use Attack Allies", "Allies will also be detected as targets when a status value " +
			"with 'Attack Allies' enabled is applied to the combatant.", "")]
		public bool detectAttackAllies = false;

		[EditorHelp("Timeout (s)", "The time in seconds between two detection checks.\n" +
			"Set to 0 to check every Update call.", "")]
		[EditorLimit(0.0f, false)]
		public float detectionTimeout = 1;

		// group/individual targets
		[EditorHelp("Detect Group Targets", "Automatically add group targets of the combatant to the detected targets.", "")]
		[EditorSeparator]
		public bool detectGroupTargets = false;

		[EditorHelp("Group Target Index", "The index of the group target.\n" +
			"Set to -1 to use all available group targets.", "")]
		[EditorLimit(-1, false)]
		[EditorIndent]
		[EditorCondition("detectGroupTargets", true)]
		public int groupTargetIndex = -1;

		[EditorHelp("Only In Range", "Only use group targets within detection range.", "")]
		[EditorIndent]
		[EditorEndCondition]
		public bool groupTargetInRange = false;

		[EditorHelp("Detect Individual Targets", "Automatically add individual targets of the combatant to the detected targets.", "")]
		public bool detectIndividualTargets = false;

		[EditorHelp("Individual Target Index", "The index of the individual target.\n" +
			"Set to -1 to use all available individual targets.", "")]
		[EditorLimit(-1, false)]
		[EditorIndent]
		[EditorCondition("detectIndividualTargets", true)]
		public int individualTargetIndex = -1;

		[EditorHelp("Only In Range", "Only use individual targets within detection range.", "")]
		[EditorIndent]
		[EditorEndCondition]
		public bool individualTargetInRange = false;

		[EditorHelp("No Detection", "If a group/individual target is used, the combatant will not check for " +
			"any further detected targets and only use the group/individual targets.", "")]
		[EditorCondition("detectGroupTargets", true)]
		[EditorCondition("detectIndividualTargets", true)]
		[EditorEndCondition]
		public bool selectedTargetNoDetection = false;

		// detection range
		[EditorSeparator]
		[EditorTitleLabel("Base Detection Range")]
		public RangeValue detectionRange = new RangeValue(20, 0.5f);

		[EditorHelp("Needed", "Select if all or just one move detection must detect the target.", "")]
		[EditorSeparator]
		[EditorTitleLabel("Move Detections")]
		public Needed detectionNeeded = Needed.One;

		[EditorArray("Add Detection", "Adds a move detection setting.\n" +
			"You can use multiple move detections to detect enemy movement.", "",
			"Remove", "Removes this move detection setting.", "", isMove = true, isCopy = true,
			foldout = true, foldoutText = new string[] { "Move Detection", "Move detections determine how an enemy combatant will be detected.", "" })]
		[EditorEndCondition]
		[EditorAutoInit]
		public MoveDetection[] detection;

		// target check intervalls
		[EditorFoldout("Target Position Check", "If the move AI has a target (e.g. hunting another combatant, following its leader), " +
			"the position of the target will be checked frequently and forwarded to the component handling the movement.\n" +
			"You can define several intervals based on different distances, " +
			"the combatant will move to the position of the last check.\n" +
			"The interval between two checks should decrease as the combatant gets nearer to the target.", "")]
		[EditorEndFoldout(2)]
		public MoveAITargetPositionCheck targetPositionCheck = new MoveAITargetPositionCheck();


		// hunting settings
		[EditorFoldout("Hunting Settings", "This settings determine if and how a combatant reacts to enemy combatants.", "")]
		[EditorEndFoldout]
		[EditorCondition("useDetection", true)]
		public MoveAIHunting hunting = new MoveAIHunting();


		// flee settings
		[EditorFoldout("Flee Settings", "The combatant can optionally flee from enemy combatants if a defined level difference occurs.", "")]
		[EditorEndFoldout]
		public MoveAIFlee flee = new MoveAIFlee();


		// cautious settings
		[EditorFoldout("Caution Settings", "The combatant can be cautious, staying within a defined range to the target " +
			"and fleeing when getting too close.", "")]
		[EditorEndFoldout]
		public MoveAICaution caution = new MoveAICaution();


		// cautious settings
		[EditorFoldout("Protection Settings", "The combatant can protect members of its own group.\n" +
			"The combatant will move between a detected target (enemy) and a member of its group.", "")]
		[EditorEndFoldout]
		[EditorEndCondition]
		public MoveAIProtection protection = new MoveAIProtection();


		// ingame
		protected AxisBool ignoreHeightInstance;

		public MoveAISetting()
		{

		}

		public MoveAISetting(string name) : base(name)
		{
			this.name = name;
		}

		public override string EditorName
		{
			get { return this.name; }
			set { this.name = value; }
		}

		public virtual AxisBool IgnoreHeight
		{
			get
			{
				if(this.ignoreHeightInstance == null)
				{
					this.ignoreHeightInstance = AxisBool.CreateIgnoreHeight(this.horizontalPlane);
				}
				return this.ignoreHeightInstance;
			}
		}


		/*
		============================================================================
		Idle functions
		============================================================================
		*/
		public MakinomSchematicAsset GetIdleSchematic(Combatant combatant, ref int lastIndex)
		{
			if(this.useIdle && this.idleSchematic != null && this.idleSchematic.Length > 0)
			{
				if(this.idleRandom)
				{
					return this.idleSchematic[UnityWrapper.Range(0, this.idleSchematic.Length)].GetSchematic(combatant);
				}
				else
				{
					lastIndex++;
					if(lastIndex < 0 || lastIndex >= this.idleSchematic.Length)
					{
						lastIndex = 0;
					}
					return this.idleSchematic[lastIndex].GetSchematic(combatant);
				}
			}
			return null;
		}


		/*
		============================================================================
		Detection functions
		============================================================================
		*/
		public bool IsDetectionEnabled()
		{
			return this.useDetection && this.detection != null && this.detection.Length > 0 &&
				(this.hunting.enabled || this.flee.enabled || this.caution.enabled || this.protection.enabled);
		}

		public void DetectTargets(Combatant combatant, ref List<Combatant> targets, ref List<Combatant> detectable)
		{
			if(this.useDetection)
			{
				detectable.Clear();
				if(this.detectGroupTargets)
				{
					if(this.groupTargetIndex == -1)
					{
						for(int i = 0; i < combatant.Group.SelectedTargets.Count; i++)
						{
							if(combatant.Group.SelectedTargets[i] != null &&
								!targets.Contains(combatant.Group.SelectedTargets[i]) &&
								!MoveAIHidingAreaComponent.IsHidden(combatant.Group.SelectedTargets[i]) &&
								(!this.groupTargetInRange ||
									this.detectionRange.InRange(combatant.GameObject, combatant.Group.SelectedTargets[i].GameObject)))
							{
								targets.Add(combatant.Group.SelectedTargets[i]);
							}
						}
					}
					else if(this.groupTargetIndex >= 0 &&
						this.groupTargetIndex < combatant.Group.SelectedTargets.Count &&
						combatant.Group.SelectedTargets[this.groupTargetIndex] != null &&
						!targets.Contains(combatant.Group.SelectedTargets[this.groupTargetIndex]) &&
						!MoveAIHidingAreaComponent.IsHidden(combatant.Group.SelectedTargets[this.groupTargetIndex]) &&
						(!this.groupTargetInRange ||
							this.detectionRange.InRange(combatant.GameObject, combatant.Group.SelectedTargets[this.groupTargetIndex].GameObject)))
					{
						targets.Add(combatant.Group.SelectedTargets[this.groupTargetIndex]);
					}
				}
				if(this.detectIndividualTargets)
				{
					if(this.individualTargetIndex == -1)
					{
						for(int i = 0; i < combatant.SelectedTargets.Count; i++)
						{
							if(combatant.SelectedTargets[i] != null &&
								!targets.Contains(combatant.SelectedTargets[i]) &&
								!MoveAIHidingAreaComponent.IsHidden(combatant.SelectedTargets[i]) &&
								(!this.individualTargetInRange ||
									this.detectionRange.InRange(combatant.GameObject, combatant.SelectedTargets[i].GameObject)))
							{
								targets.Add(combatant.SelectedTargets[i]);
							}
						}
					}
					else if(this.individualTargetIndex >= 0 &&
						this.individualTargetIndex < combatant.SelectedTargets.Count &&
						combatant.SelectedTargets[this.individualTargetIndex] != null &&
						!targets.Contains(combatant.SelectedTargets[this.individualTargetIndex]) &&
						!MoveAIHidingAreaComponent.IsHidden(combatant.SelectedTargets[this.individualTargetIndex]) &&
						(!this.individualTargetInRange ||
							this.detectionRange.InRange(combatant.GameObject, combatant.SelectedTargets[this.individualTargetIndex].GameObject)))
					{
						targets.Add(combatant.SelectedTargets[this.individualTargetIndex]);
					}
				}

				if(!this.selectedTargetNoDetection ||
					targets.Count == 0)
				{
					ORK.Game.Combatants.Get(ref detectable, combatant, true, this.detectionRange,
						this.detectAttackAllies && combatant.Status.Effects.AttackAllies ?
							Consider.Ignore : Consider.Yes,
						Consider.No, Consider.Ignore, null);

					for(int i = 0; i < detectable.Count; i++)
					{
						if(detectable[i] != null &&
							!detectable[i].Status.IsDead &&
							!targets.Contains(detectable[i]) &&
							!MoveAIHidingAreaComponent.IsHidden(detectable[i]) &&
							(!this.detectOnlyLeader || detectable[i].IsLeader) &&
							this.Detect(combatant, detectable[i]))
						{
							targets.Add(detectable[i]);
						}
					}
				}
			}
		}

		public void UseGroupDetection(Combatant combatant, ref List<Combatant> targets, ref List<Combatant> detectable)
		{
			if(this.useGroupDetection)
			{
				List<Combatant> members = combatant.Group.GetGroup();
				for(int i = 0; i < members.Count; i++)
				{
					if(members[i] != combatant &&
						members[i].Object.MoveAI != null)
					{
						members[i].Object.MoveAI.settings.DetectTargets(members[i], ref targets, ref detectable);
					}
				}
			}
		}

		public bool Detect(Combatant combatant, Combatant target)
		{
			if(this.detection != null)
			{
				for(int i = 0; i < this.detection.Length; i++)
				{
					if(this.detection[i].DetectedCombatant(combatant, target))
					{
						if(Needed.One == this.detectionNeeded)
						{
							return true;
						}
					}
					else if(Needed.All == this.detectionNeeded)
					{
						return false;
					}
				}
				if(Needed.All == this.detectionNeeded)
				{
					return true;
				}
			}
			return false;
		}

		public bool IsSelectedTarget(Combatant combatant, Combatant target)
		{
			if(this.detectGroupTargets)
			{
				if(this.groupTargetIndex == -1)
				{
					for(int i = 0; i < combatant.Group.SelectedTargets.Count; i++)
					{
						if(combatant.Group.SelectedTargets[i] == target &&
							(!this.groupTargetInRange ||
								this.detectionRange.InRange(combatant.GameObject, combatant.Group.SelectedTargets[i].GameObject)))
						{
							return true;
						}
					}
				}
				else if(this.groupTargetIndex >= 0 &&
					this.groupTargetIndex < combatant.Group.SelectedTargets.Count &&
					combatant.Group.SelectedTargets[this.groupTargetIndex] == target &&
					(!this.groupTargetInRange ||
						this.detectionRange.InRange(combatant.GameObject, combatant.Group.SelectedTargets[this.groupTargetIndex].GameObject)))
				{
					return true;
				}
			}
			if(this.detectIndividualTargets)
			{
				if(this.individualTargetIndex == -1)
				{
					for(int i = 0; i < combatant.SelectedTargets.Count; i++)
					{
						if(combatant.SelectedTargets[i] == target &&
							(!this.individualTargetInRange ||
								this.detectionRange.InRange(combatant.GameObject, combatant.SelectedTargets[i].GameObject)))
						{
							return true;
						}
					}
				}
				else if(this.individualTargetIndex >= 0 &&
					this.individualTargetIndex < combatant.SelectedTargets.Count &&
					combatant.SelectedTargets[this.individualTargetIndex] == target &&
					(!this.individualTargetInRange ||
						this.detectionRange.InRange(combatant.GameObject, combatant.SelectedTargets[this.individualTargetIndex].GameObject)))
				{
					return true;
				}
			}
			return false;
		}

		public PointOfInterest GetNearestPointOfInterest(Combatant combatant, ref List<PointOfInterest> pointsOfInterest, ref HashSet<PointOfInterest> visited)
		{
			PointOfInterest poi = null;
			if(this.useDetection &&
				this.usePointsOfInterest)
			{
				float distance = Mathf.Infinity;
				pointsOfInterest.Clear();
				ORK.Game.Scene.GetPointsOfInterest(combatant, this.detectionRange, ref pointsOfInterest);

				for(int i = 0; i < pointsOfInterest.Count; i++)
				{
					if(pointsOfInterest[i] != null &&
						!visited.Contains(pointsOfInterest[i]) &&
						pointsOfInterest[i].settings.CheckTag(this.pointOfInterestTag) &&
						this.DetectPOI(combatant, pointsOfInterest[i].gameObject))
					{
						float tmpDistance = VectorHelper.Distance(combatant.GameObject.transform.position,
							pointsOfInterest[i].transform.position, this.IgnoreHeight);
						if(tmpDistance < distance)
						{
							tmpDistance = distance;
							poi = pointsOfInterest[i];
						}
					}
				}
			}
			return poi;
		}

		public bool DetectPOI(Combatant combatant, GameObject target)
		{
			if(this.detection != null)
			{
				for(int i = 0; i < this.detection.Length; i++)
				{
					if(this.detection[i].DetectedPOI(combatant, target))
					{
						if(Needed.One == this.detectionNeeded)
						{
							return true;
						}
					}
					else if(Needed.All == this.detectionNeeded)
					{
						return false;
					}
				}
				if(Needed.All == this.detectionNeeded)
				{
					return true;
				}
			}
			return false;
		}


		/*
		============================================================================
		Component functions
		============================================================================
		*/
		public MoveAIComponent AddAIMover(Combatant combatant)
		{
			MoveAIComponent comp = combatant.GameObject.GetComponent<MoveAIComponent>();
			if(comp == null)
			{
				comp = combatant.GameObject.AddComponent<MoveAIComponent>();
				comp.Combatant = combatant;
				comp.settings = this;
				comp.originalSettings = this;
				comp.UseMode = this.useMode;
				if(this.startInWaypointMode)
				{
					comp.mode = MoveAIMode.Waypoint;
				}
			}
			else
			{
				comp.settings = this;
				comp.Combatant = combatant;
			}
			return comp;
		}
	}
}
