
using UnityEngine;
using GamingIsLove.ORKFramework;
using System.Collections.Generic;
using GamingIsLove.Makinom;

namespace GamingIsLove.ORKFramework.AI
{
	public class MoveTargetCheck : BaseData
	{
		[EditorHelp("Interval (s)", "The time between two target checks.\n" +
			"Set to 0 if the target's position should be checked every frame.", "")]
		[EditorLimit(0.0f, false)]
		public float interval = 0.5f;
		
		[EditorHelp("Minimum Distance", "The minimum distance to the target in world space " +
			"to use this target check's interval.\n", "")]
		[EditorLimit(0.0f, false)]
		public float distance = 10;
		
		public MoveTargetCheck()
		{
			
		}
		
		public MoveTargetCheck(float interval, float distance)
		{
			this.interval = interval;
			this.distance = distance;
		}
	}
}
