﻿
using UnityEngine;
using GamingIsLove.ORKFramework;
using GamingIsLove.ORKFramework.Components;
using System.Collections.Generic;
using GamingIsLove.Makinom;

namespace GamingIsLove.ORKFramework.AI
{
	public class MoveAIChange : BaseData
	{
		// change move AI
		[EditorHelp("Change Move AI", "Change the used move AI.", "")]
		public bool changeMoveAI = false;

		[EditorHelp("Move AI", "Select the move AI that will be used.", "")]
		[EditorCondition("changeMoveAI", true)]
		[EditorEndCondition]
		[EditorAutoInit]
		public AssetSelection<MoveAIAsset> move;


		// change use mode
		[EditorHelp("Change Use Mode", "Change the use mode of the move AI.", "")]
		[EditorSeparator]
		public bool changeUseMode = false;

		[EditorHelp("Use Mode", "Select the use mode of the move AI:\n" +
			"- Auto: Automatically uses the different behaviours (e.g. hunting, fleeing).\n" +
			"- Idle: Forces idle mode, only following waypoints (if used).\n" +
			"- Hunt: Forces hunting.\n" +
			"- Flee: Forces fleeing.\n" +
			"- Caution: Forces caution.\n" +
			"- Protect: Forces protecting group members.", "")]
		[EditorCondition("changeUseMode", true)]
		[EditorEndCondition]
		public MoveAIUseMode useMode = MoveAIUseMode.Auto;

		public MoveAIChange()
		{

		}

		public bool Change(Combatant combatant)
		{
			bool changed = false;

			if(combatant != null &&
				combatant.Object.MoveAI != null)
			{
				if(this.changeMoveAI && 
					this.move.StoredAsset != null)
				{
					combatant.Object.MoveAI.ChangeMoveAI(this.move.StoredAsset.Settings);
					changed = true;
				}

				if(this.changeUseMode)
				{
					combatant.Object.MoveAI.UseMode = this.useMode;
					changed = true;
				}
			}
			return changed;
		}
	}
}
